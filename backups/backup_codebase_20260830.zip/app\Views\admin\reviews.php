<?php
require_once __DIR__ . '/../../../admin/includes/header.php';
?>

<style>
.star-rating { display: flex; gap: 4px; flex-direction: row-reverse; justify-content: flex-end; }
.star-rating input { display: none; }
.star-rating label { font-size: 28px; color: var(--border-color); cursor: pointer; transition: all var(--transition); }
.star-rating label:hover, .star-rating label:hover ~ label, .star-rating input:checked ~ label { color: #f59e0b; transform: scale(1.1); }
.stars { color: #f59e0b; font-size: 16px; letter-spacing: 2px; }
.review-msg { max-width: 320px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--text-muted); font-size: 13px; }
.reviewer-name { font-weight: 600; color: var(--text-main); font-size: 14px; }
</style>

<div class="saas-page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-star" style="color: #f59e0b;"></i> Reviews Management</h1>
        <p class="page-subtitle">Moderate customer reviews, star ratings, and testimonials shown on the website.</p>
    </div>
    <div class="header-actions">
        <button class="btn btn-primary" onclick="openModal()"><i class="fas fa-plus"></i> Add Review</button>
    </div>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?= $message_type ?>">
        <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i> 
        <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<div class="content-card">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th style="width: 60px;">ID</th>
                    <th>Reviewer</th>
                    <th>Rating</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reviews as $review): ?>
                <tr>
                    <td style="color: var(--text-muted);">#<?= $review['id'] ?></td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <div style="width: 36px; height: 36px; border-radius: 50%; background: color-mix(in srgb, var(--primary) 15%, transparent); display: flex; align-items: center; justify-content: center; color: var(--primary); font-weight: 600; font-size: 14px;">
                                <?= strtoupper(substr($review['name'] ?? '?', 0, 1)) ?>
                            </div>
                            <div>
                                <div class="reviewer-name"><?= htmlspecialchars($review['name']) ?></div>
                                <?php if (!empty($review['email'])): ?>
                                    <div style="font-size: 12px; color: var(--text-muted);"><a href="mailto:<?= htmlspecialchars($review['email']) ?>" style="color: inherit; text-decoration: none;"><?= htmlspecialchars($review['email']) ?></a></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td><span class="stars"><?= str_repeat('★', $review['star_rating']) . str_repeat('☆', 5 - $review['star_rating']) ?></span></td>
                    <td class="review-msg" title="<?= htmlspecialchars($review['message']) ?>"><?= htmlspecialchars($review['message']) ?></td>
                    <td style="color: var(--text-muted); font-size: 13px;"><?= date('M d, Y', strtotime($review['created_at'])) ?></td>
                    <td style="text-align: right;">
                        <div style="display: flex; gap: 8px; justify-content: flex-end;">
                            <button class="btn btn-sm" onclick="editReview(<?= htmlspecialchars(json_encode($review)) ?>)" style="background: var(--bg-main); color: var(--text-main); border: 1px solid var(--border-color);" title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this review permanently?')">
                                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $review['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-delete" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                
                <?php if (empty($reviews)): ?>
                <tr>
                    <td colspan="6" style="text-align:center; padding:80px 20px; background: var(--bg-card); border-bottom: none;">
                        <div style="width: 64px; height: 64px; background: var(--bg-main); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
                            <i class="fas fa-star" style="font-size: 24px; color: var(--text-muted);"></i>
                        </div>
                        <h3 style="font-size: 18px; color: var(--text-main); margin-bottom: 8px;">No reviews found</h3>
                        <p style="color: var(--text-muted); font-size: 15px; margin-bottom: 24px;">Start adding customer testimonials to build trust.</p>
                        <button class="btn btn-primary" onclick="openModal()"><i class="fas fa-plus"></i> Add First Review</button>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal" id="reviewModal">
    <div class="modal-content" style="max-width: 540px;">
        <div class="modal-header">
            <h3 class="modal-title"><i class="fas fa-star"></i> <span id="modalTitle">Add New Review</span></h3>
            <button type="button" class="modal-close" onclick="closeModal()" aria-label="Close modal">&times;</button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="reviewId">
                <div class="form-group">
                    <label for="reviewName"><i class="fas fa-user"></i> Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" id="reviewName" class="form-control" placeholder="e.g. Rahul Verma" required>
                </div>
                <div class="form-group">
                    <label for="reviewEmail"><i class="fas fa-envelope"></i> Email Address</label>
                    <input type="email" name="email" id="reviewEmail" class="form-control" placeholder="e.g. rahul@example.com">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-star"></i> Star Rating <span class="text-danger">*</span></label>
                    <div class="star-rating">
                        <input type="radio" name="star_rating" id="star5" value="5"><label for="star5">★</label>
                        <input type="radio" name="star_rating" id="star4" value="4"><label for="star4">★</label>
                        <input type="radio" name="star_rating" id="star3" value="3"><label for="star3">★</label>
                        <input type="radio" name="star_rating" id="star2" value="2"><label for="star2">★</label>
                        <input type="radio" name="star_rating" id="star1" value="1"><label for="star1">★</label>
                    </div>
                </div>
                <div class="form-group">
                    <label for="reviewMessage"><i class="fas fa-comment"></i> Review Message <span class="text-danger">*</span></label>
                    <textarea name="message" id="reviewMessage" class="form-control" rows="4" placeholder="Client review comments..." required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()"><i class="fas fa-times"></i> Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Review</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() { document.getElementById('modalTitle').textContent = 'Add New Review'; document.getElementById('formAction').value = 'create'; document.getElementById('reviewId').value = ''; document.getElementById('reviewName').value = ''; document.getElementById('reviewEmail').value = ''; document.getElementById('reviewMessage').value = ''; document.querySelectorAll('.star-rating input').forEach(i => i.checked = false); document.getElementById('reviewModal').classList.add('active'); }
function editReview(r) { document.getElementById('modalTitle').textContent = 'Edit Review'; document.getElementById('formAction').value = 'update'; document.getElementById('reviewId').value = r.id; document.getElementById('reviewName').value = r.name; document.getElementById('reviewEmail').value = r.email || ''; document.getElementById('reviewMessage').value = r.message; document.querySelector(`input[name="star_rating"][value="${r.star_rating}"]`).checked = true; document.getElementById('reviewModal').classList.add('active'); }
function closeModal() { document.getElementById('reviewModal').classList.remove('active'); }
window.onclick = function(e) { if (e.target === document.getElementById('reviewModal')) closeModal(); }
</script>

<?php require_once __DIR__ . '/../../../admin/includes/footer.php'; ?>