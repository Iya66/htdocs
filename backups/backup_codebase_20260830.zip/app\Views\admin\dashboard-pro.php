<?php
/**
 * Ultimate Admin Dashboard
 * Modern SaaS design with GIF icons, animations, glass morphism
 */

// ─── Data from controller ─────────────────────────────────────────
// $leads_count, $services_count, $reviews_count
// $why_us_count, $recent_leads, $new_leads, $projects_count
// $uploads_count, $staff_count
// $chart_dates, $chart_counts, $service_labels, $service_counts
// $lead_status_counts, $recent_activity, $active_projects
// $today_activity — provided by dashboard.php controller

$total_uploads = $uploads_count ?? 0;

// Stat cards definition
$stats = [
 [
 'icon' => 'fa-users',
 'label' => 'Total Leads',
 'value' => number_format($leads_count),
 'trend' => $new_leads > 0 ? '+' . $new_leads . ' new' : '0 new',
 'trend_dir' => 'up',
 'color' => 'blue',
 'gif' => 'leads.gif',
 ],
 [
 'icon' => 'fa-cube',
 'label' => 'Services',
 'value' => number_format($services_count),
 'trend' => 'Active',
 'trend_dir' => 'up',
 'color' => 'green',
 'gif' => 'services.gif',
 ],
 [
 'icon' => 'fa-star',
 'label' => 'Reviews',
 'value' => number_format($reviews_count),
 'trend' => 'Approved',
 'trend_dir' => 'up',
 'color' => 'purple',
 'gif' => 'reviews.gif',
 ],
 [
 'icon' => 'fa-folder-open',
 'label' => 'Projects',
 'value' => number_format((int)$projects_count),
 'trend' => (is_array($active_projects) ? count($active_projects) : (int)$active_projects) . ' active',
 'trend_dir' => 'up',
 'color' => 'orange',
 'gif' => 'projects.gif',
 ],
 [
 'icon' => 'fa-shield-alt',
 'label' => 'Staff',
 'value' => number_format($staff_count),
 'trend' => 'Active',
 'trend_dir' => 'up',
 'color' => 'blue',
 'gif' => null,
 ],
];

$current_hour = date('H');
$greeting = $current_hour < 12 ? 'Good morning' : ($current_hour < 17 ? 'Good afternoon' : 'Good evening');
$current_date = date('l, F j, Y');
?>

<!-- ═══════════════════════════════════════════════════════════════
 WELCOME HERO BANNER
 ═══════════════════════════════════════════════════════════════ -->
<div class="hero-banner">
 <div class="hero-content">
 <div class="hero-text">
 <div class="hero-greeting"><?= $greeting ?>, <?= htmlspecialchars($admin_name) ?></div>
 <h1 class="hero-title">Dashboard Overview</h1>
 <p class="hero-date"><i class="far fa-calendar-alt"></i> <?= $current_date ?></p>
 </div>
 <div class="hero-actions">
 <a href="<?= $base_path ?>leads.php?action=new" class="hero-btn hero-btn-primary">
 <i class="fas fa-plus"></i> New Lead
 </a>
 <a href="<?= $base_path ?>reports.php" class="hero-btn hero-btn-secondary">
 <i class="fas fa-chart-bar"></i> Reports
 </a>
 </div>
 </div>
 <!-- Decorative gradient orbs -->
 <div class="hero-orb hero-orb-1"></div>
 <div class="hero-orb hero-orb-2"></div>
</div>

<!-- ═══════════════════════════════════════════════════════════════
 STATS GRID
 ═══════════════════════════════════════════════════════════════ -->
<div class="stats-grid">

 <?php foreach ($stats as $idx => $stat): ?>
 <div class="stat-card" style="animation-delay: <?= $idx * 0.06 ?>s;">
 <div class="stat-card-glow" style="background: <?php
 $glow_map = ['blue' => 'var(--primary-soft)', 'green' => 'var(--success-soft)', 'orange' => 'var(--warning-soft)', 'purple' => 'var(--accent-soft)', 'red' => 'var(--danger-soft)'];
 echo $glow_map[$stat['color']] ?? 'var(--primary-soft)';
 ?>;"></div>
 <div class="stat-card-body">
 <div class="stat-icon-wrap">
 <div class="stat-icon stat-icon-<?= $stat['color'] ?>">
 <?php
 $lcons_path = __DIR__ . '/../../../files/lcons/' . $stat['gif'];
 if ($stat['gif'] && file_exists($lcons_path)):
 ?>
 <img src="<?= $base_path ?>../files/lcons/<?= $stat['gif'] ?>"
 alt="<?= htmlspecialchars($stat['label']) ?>"
 class="stat-gif">
 <?php else: ?>
 <i class="fas <?= $stat['icon'] ?>"></i>
 <?php endif; ?>
 </div>
 <span class="stat-trend stat-trend-<?= $stat['trend_dir'] ?>">
 <i class="fas fa-arrow-<?= $stat['trend_dir'] ?>"></i>
 <?= htmlspecialchars($stat['trend']) ?>
 </span>
 </div>
 <div class="stat-value"><?= $stat['value'] ?></div>
 <div class="stat-label"><?= htmlspecialchars($stat['label']) ?></div>
 </div>
 <div class="stat-card-bar"></div>
 </div>
 <?php endforeach; ?>

</div>

<!-- ═══════════════════════════════════════════════════════════════
 MAIN CONTENT GRID
 ═══════════════════════════════════════════════════════════════ -->
<div class="dashboard-grid">

 <!-- ─── Recent Leads Table ─────────────────────────────────── -->
 <div class="dash-card dash-card-leads">
 <div class="dash-card-header">
 <div class="dash-card-title-group">
 <div class="dash-card-icon dash-card-icon-primary">
 <img src="<?= $base_path ?>../files/lcons/leads.gif" alt="Leads" class="dash-card-gif">
 </div>
 <div>
 <h2 class="dash-card-title">Recent Leads</h2>
 <p class="dash-card-subtitle"><?= number_format($leads_count) ?> total &middot; <?= number_format($new_leads) ?> new</p>
 </div>
 </div>
 <a href="<?= $base_path ?>leads.php" class="dash-card-link">
 View All <i class="fas fa-arrow-right"></i>
 </a>
 </div>

 <div class="dash-card-body">
 <?php if (empty($recent_leads)): ?>
 <div class="empty-state">
 <div class="empty-icon">
 <img src="<?= $base_path ?>../files/lcons/leads.gif" alt="No leads" class="empty-gif">
 </div>
 <h3 class="empty-title">No leads yet</h3>
 <p class="empty-text">Your leads will appear here once visitors start reaching out.</p>
 <a href="<?= $base_path ?>leads.php?action=new" class="btn btn-primary btn-sm">
 <i class="fas fa-plus"></i> Add Your First Lead
 </a>
 </div>
 <?php else: ?>
 <div class="table-wrap">
 <table class="dash-table">
 <thead>
 <tr>
 <th>Name</th>
 <th>Service</th>
 <th>Status</th>
 <th>Date</th>
 <th></th>
 </tr>
 </thead>
 <tbody>
 <?php foreach ($recent_leads as $lead): ?>
 <?php
 $status_badge = 'badge-neutral';
 $status_label = ucfirst($lead['status'] ?? 'New');
 if (($lead['status'] ?? '') === 'new') $status_badge = 'badge-info';
 elseif (($lead['status'] ?? '') === 'contacted') $status_badge = 'badge-warning';
 elseif (($lead['status'] ?? '') === 'confirmed') $status_badge = 'badge-success';
 elseif (($lead['status'] ?? '') === 'lose') $status_badge = 'badge-danger';
 ?>
 <tr>
 <td>
 <div class="lead-name">
 <div class="lead-avatar"><?= strtoupper(substr($lead['name'] ?? '?', 0, 1)) ?></div>
 <div>
 <div class="lead-name-text"><?= htmlspecialchars($lead['name']) ?></div>
 <div class="lead-email"><?= htmlspecialchars($lead['email'] ?? '') ?></div>
 </div>
 </div>
 </td>
 <td>
 <?php if (!empty($lead['service'])): ?>
 <span class="badge-sm badge-neutral"><?= htmlspecialchars($lead['service']) ?></span>
 <?php else: ?>
 <span class="text-muted">—</span>
 <?php endif; ?>
 </td>
 <td><span class="badge-sm <?= $status_badge ?>"><?= $status_label ?></span></td>
 <td class="text-muted text-sm"><?= date('M j, Y', strtotime($lead['created_at'])) ?></td>
 <td>
 <a href="<?= $base_path ?>leads.php?edit=<?= $lead['id'] ?>" class="row-action" data-tooltip="Edit lead">
 <i class="fas fa-ellipsis-h"></i>
 </a>
 </td>
 </tr>
 <?php endforeach; ?>
 </tbody>
 </table>
 </div>
 <?php endif; ?>
 </div>
 </div>

 <!-- ─── Right Column ───────────────────────────────────────── -->
 <div class="dash-right-col">

 <!-- Lead Status Breakdown -->
 <div class="dash-card">
 <div class="dash-card-header">
 <div class="dash-card-title-group">
 <div class="dash-card-icon dash-card-icon-green">
 <i class="fas fa-chart-pie"></i>
 </div>
 <div>
 <h2 class="dash-card-title">Lead Status</h2>
 <p class="dash-card-subtitle">Breakdown by stage</p>
 </div>
 </div>
 </div>
 <div class="dash-card-body">
 <div class="status-breakdown">
 <?php
 $status_items = [
 ['label' => 'New', 'count' => $lead_status_counts['new'], 'class' => 'status-new', 'pct' => $leads_count > 0 ? round(($lead_status_counts['new'] / $leads_count) * 100) : 0],
 ['label' => 'Contacted', 'count' => $lead_status_counts['contacted'], 'class' => 'status-contacted', 'pct' => $leads_count > 0 ? round(($lead_status_counts['contacted'] / $leads_count) * 100) : 0],
 ['label' => 'Confirmed', 'count' => $lead_status_counts['confirmed'], 'class' => 'status-confirmed', 'pct' => $leads_count > 0 ? round(($lead_status_counts['confirmed'] / $leads_count) * 100) : 0],
 ['label' => 'Lost', 'count' => $lead_status_counts['lose'], 'class' => 'status-lose', 'pct' => $leads_count > 0 ? round(($lead_status_counts['lose'] / $leads_count) * 100) : 0],
 ];
 ?>
 <?php foreach ($status_items as $item): ?>
 <div class="status-row">
 <div class="status-info">
 <span class="status-label"><?= $item['label'] ?></span>
 <span class="status-count"><?= number_format($item['count']) ?></span>
 </div>
 <div class="status-bar-bg">
 <div class="status-bar-fill status-bar-<?= $item['class'] ?>" style="width: <?= $item['pct'] ?>%;"></div>
 </div>
 <span class="status-pct"><?= $item['pct'] ?>%</span>
 </div>
 <?php endforeach; ?>
 </div>
 </div>
 </div>

 <!-- Quick Actions -->
 <div class="dash-card">
 <div class="dash-card-header">
 <div class="dash-card-title-group">
 <div class="dash-card-icon dash-card-icon-purple">
 <i class="fas fa-bolt"></i>
 </div>
 <div>
 <h2 class="dash-card-title">Quick Actions</h2>
 <p class="dash-card-subtitle">Frequently used</p>
 </div>
 </div>
 </div>
 <div class="dash-card-body">
 <div class="quick-actions-grid">
 <a href="<?= $base_path ?>leads.php?action=new" class="qa-item">
 <div class="qa-icon qa-icon-primary">
 <img src="<?= $base_path ?>../files/lcons/leads.gif" alt="" class="qa-gif">
 </div>
 <span class="qa-label">Add Lead</span>
 </a>
 <a href="<?= $base_path ?>services.php?action=new" class="qa-item">
 <div class="qa-icon qa-icon-green">
 <img src="<?= $base_path ?>../files/lcons/services.gif" alt="" class="qa-gif">
 </div>
 <span class="qa-label">Add Service</span>
 </a>
 <a href="<?= $base_path ?>reviews.php?action=new" class="qa-item">
 <div class="qa-icon qa-icon-purple">
 <img src="<?= $base_path ?>../files/lcons/reviews.gif" alt="" class="qa-gif">
 </div>
 <span class="qa-label">Add Review</span>
 </a>
 <a href="<?= $base_path ?>projects.php" class="qa-item">
 <div class="qa-icon qa-icon-orange">
 <img src="<?= $base_path ?>../files/lcons/projects.gif" alt="" class="qa-gif">
 </div>
 <span class="qa-label">Projects</span>
 </a>
 <a href="<?= $base_path ?>leads.php" class="qa-item">
 <div class="qa-icon qa-icon-blue">
 <img src="<?= $base_path ?>../files/lcons/new-leads.gif" alt="" class="qa-gif">
 </div>
 <span class="qa-label">New Leads</span>
 </a>
 </div>
 </div>
 </div>

 <!-- Active Projects -->
 <div class="dash-card">
 <div class="dash-card-header">
 <div class="dash-card-title-group">
 <div class="dash-card-icon dash-card-icon-orange">
 <i class="fas fa-project-diagram"></i>
 </div>
 <div>
 <h2 class="dash-card-title">Active Projects</h2>
 <p class="dash-card-subtitle"><?= number_format(count($active_projects)) ?> in progress</p>
 </div>
 </div>
 <a href="<?= $base_path ?>projects.php" class="dash-card-link">
 View All <i class="fas fa-arrow-right"></i>
 </a>
 </div>
 <div class="dash-card-body">
 <?php if (empty($active_projects)): ?>
 <div class="empty-state-sm">
 <p class="text-muted text-sm">No active projects right now.</p>
 <a href="<?= $base_path ?>projects.php?action=new" class="btn btn-primary btn-sm" style="margin-top: 8px;">
 <i class="fas fa-plus"></i> Create Project
 </a>
 </div>
 <?php else: ?>
 <div class="project-list">
 <?php foreach ($active_projects as $proj): ?>
 <div class="project-item">
 <div class="project-dot"></div>
 <div class="project-info">
 <span class="project-name"><?= htmlspecialchars($proj['project_name']) ?></span>
 <span class="project-meta">
 <?= $proj['budget'] ? '$' . number_format($proj['budget']) . ' &middot; ' : '' ?>
 <?= $proj['project_datetime'] ? date('M j', strtotime($proj['project_datetime'])) : 'No date' ?>
 </span>
 </div>
 <span class="badge-sm badge-<?= $proj['status'] === 'running' ? 'success' : 'warning' ?>">
 <?= ucfirst($proj['status']) ?>
 </span>
 </div>
 <?php endforeach; ?>
 </div>
 <?php endif; ?>
 </div>
 </div>
 </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════
 BOTTOM ROW — Activity Timeline
 ═══════════════════════════════════════════════════════════════ -->
<div class="dash-card dash-card-activity" style="margin-top: var(--space-6);">
 <div class="dash-card-header">
 <div class="dash-card-title-group">
 <div class="dash-card-icon dash-card-icon-info">
 <i class="fas fa-clock"></i>
 </div>
 <div>
 <h2 class="dash-card-title">Recent Activity</h2>
 <p class="dash-card-subtitle"><?= number_format($today_activity) ?> actions today &middot; <?= number_format($total_uploads ?? 0) ?> uploads</p>
 </div>
 </div>
 <a href="<?= $base_path ?>activity.php" class="dash-card-link">
 View All <i class="fas fa-arrow-right"></i>
 </a>
 </div>
 <div class="dash-card-body">
 <?php if (empty($recent_activity)): ?>
 <div class="empty-state-sm">
 <div class="timeline-empty">
 <i class="fas fa-inbox"></i>
 <p class="text-muted text-sm">No activity recorded yet.</p>
 </div>
 </div>
 <?php else: ?>
 <div class="timeline">
 <?php foreach ($recent_activity as $i => $log): ?>
 <div class="timeline-item" style="animation-delay: <?= $i * 0.04 ?>s;">
 <div class="timeline-dot"></div>
 <div class="timeline-content">
 <div class="timeline-header">
 <span class="timeline-user"><?= htmlspecialchars($log['admin_name'] ?? 'System') ?></span>
 <span class="timeline-action"><?= htmlspecialchars($log['action']) ?></span>
 <span class="timeline-time"><?= date('M j, g:i A', strtotime($log['created_at'])) ?></span>
 </div>
 <?php if (!empty($log['details'])): ?>
 <p class="timeline-details"><?= htmlspecialchars($log['details']) ?></p>
 <?php endif; ?>
 </div>
 </div>
 <?php endforeach; ?>
 </div>
 <?php endif; ?>
 </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════
 DASHBOARD STYLES
 ═══════════════════════════════════════════════════════════════ -->
<style>
/* ═══ Animations ═══════════════════════════════════════════════ */
@keyframes fadeInUp {
 from { opacity: 0; transform: translateY(16px); }
 to { opacity: 1; transform: translateY(0); }
}
@keyframes fadeIn {
 from { opacity: 0; }
 to { opacity: 1; }
}
@keyframes shimmer {
 0% { background-position: -200% 0; }
 100% { background-position: 200% 0; }
}
@keyframes pulse-soft {
 0%, 100% { opacity: 1; }
 50% { opacity: 0.6; }
}
@keyframes float {
 0%, 100% { transform: translateY(0px); }
 50% { transform: translateY(-8px); }
}

/* All cards visible by default, animations are progressive enhancement */
.stat-card, .dash-card {
 opacity: 1;
 animation: fadeInUp 0.4s ease-out both;
}
.stats-grid {
 animation: fadeInUp 0.4s ease-out 0.05s both;
}
.hero-banner {
 animation: fadeInUp 0.4s ease-out both;
}

/* ═══ Hero Banner ═══════════════════════════════════════════════ */
.hero-banner {
 position: relative;
 background: linear-gradient(135deg, #5b6ef5 0%, #7c5cfc 50%, #a855f7 100%);
 border-radius: var(--radius-xl);
 padding: 32px 36px;
 margin-bottom: var(--space-6);
 overflow: hidden;
 animation: fadeInUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}
.hero-content {
 position: relative;
 z-index: 2;
 display: flex;
 align-items: center;
 justify-content: space-between;
 gap: var(--space-4);
 flex-wrap: wrap;
}
.hero-greeting {
 font-size: var(--text-sm);
 font-weight: 500;
 color: rgba(255,255,255,0.85);
 letter-spacing: 0.02em;
}
.hero-title {
 font-size: 28px;
 font-weight: 700;
 color: #ffffff;
 letter-spacing: -0.02em;
 margin: var(--space-1) 0 var(--space-2);
}
.hero-date {
 font-size: var(--text-sm);
 color: rgba(255,255,255,0.7);
 font-weight: 500;
}
.hero-date i {
 margin-right: var(--space-1);
 opacity: 0.8;
}
.hero-actions {
 display: flex;
 gap: var(--space-3);
 flex-shrink: 0;
}
.hero-btn {
 display: inline-flex;
 align-items: center;
 gap: var(--space-2);
 padding: 10px 20px;
 border-radius: var(--radius-md);
 font-size: var(--text-sm);
 font-weight: 600;
 letter-spacing: -0.01em;
 cursor: pointer;
 transition: all var(--duration-fast) var(--ease-out);
 text-decoration: none;
 border: none;
 font-family: inherit;
}
.hero-btn-primary {
 background: #ffffff;
 color: var(--primary);
 box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.hero-btn-primary:hover {
 transform: translateY(-2px);
 box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}
.hero-btn-secondary {
 background: rgba(255,255,255,0.15);
 color: #ffffff;
 border: 1px solid rgba(255,255,255,0.25);
 backdrop-filter: blur(10px);
}
.hero-btn-secondary:hover {
 background: rgba(255,255,255,0.25);
 transform: translateY(-2px);
}
/* Decorative orbs */
.hero-orb {
 position: absolute;
 border-radius: 50%;
 pointer-events: none;
 z-index: 1;
}
.hero-orb-1 {
 width: 200px;
 height: 200px;
 background: rgba(255,255,255,0.08);
 top: -60px;
 right: 40px;
 animation: float 6s ease-in-out infinite;
}
.hero-orb-2 {
 width: 120px;
 height: 120px;
 background: rgba(255,255,255,0.05);
 bottom: -40px;
 right: 200px;
 animation: float 8s ease-in-out infinite 2s;
}

/* ═══ Stats Grid ═══════════════════════════════════════════════ */
.stats-grid {
 display: grid;
 gap: var(--space-4);
 margin-bottom: var(--space-6);
}
@media (min-width: 480px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } }
@media (min-width: 1024px) { .stats-grid { grid-template-columns: repeat(3, 1fr); } }
@media (min-width: 1440px) { .stats-grid { grid-template-columns: repeat(6, 1fr); } }

/* ═══ Stat Card ═══════════════════════════════════════════════ */
.stat-card {
 position: relative;
 background: var(--bg-surface);
 border: 1px solid var(--border-light);
 border-radius: var(--radius-lg);
 padding: var(--space-5);
 overflow: hidden;
 transition: all var(--duration-base) var(--ease-out);
 cursor: default;
}
.stat-card:hover {
 border-color: var(--border-medium);
 box-shadow: var(--shadow-md);
 transform: translateY(-3px);
}
.stat-card-glow {
 position: absolute;
 top: -30px;
 right: -30px;
 width: 80px;
 height: 80px;
 border-radius: 50%;
 filter: blur(25px);
 opacity: 0;
 transition: opacity var(--duration-base) var(--ease-out);
}
.stat-card:hover .stat-card-glow {
 opacity: 0.6;
}
.stat-card-bar {
 position: absolute;
 bottom: 0;
 left: 0;
 width: 100%;
 height: 3px;
 background: linear-gradient(90deg, var(--primary), var(--accent));
 transform: scaleX(0);
 transform-origin: left;
 transition: transform var(--duration-base) var(--ease-out);
}
.stat-card:hover .stat-card-bar {
 transform: scaleX(1);
}
.stat-card-body {
 position: relative;
 z-index: 1;
}
.stat-icon-wrap {
 display: flex;
 align-items: center;
 justify-content: space-between;
 margin-bottom: var(--space-4);
}
.stat-icon {
 width: 44px;
 height: 44px;
 border-radius: var(--radius-md);
 display: flex;
 align-items: center;
 justify-content: center;
 font-size: 18px;
 color: #fff;
 flex-shrink: 0;
}
.stat-icon-blue { background: linear-gradient(135deg, #3b82f6, #2563eb); box-shadow: 0 4px 12px rgba(59,130,246,0.3); }
.stat-icon-green { background: linear-gradient(135deg, #22c55e, #16a34a); box-shadow: 0 4px 12px rgba(34,197,94,0.3); }
.stat-icon-orange { background: linear-gradient(135deg, #f59e0b, #d97706); box-shadow: 0 4px 12px rgba(245,158,11,0.3); }
.stat-icon-purple { background: linear-gradient(135deg, #7c5cfc, #5b6ef5); box-shadow: 0 4px 12px rgba(124,92,252,0.3); }
.stat-icon-red { background: linear-gradient(135deg, #ef4444, #dc2626); box-shadow: 0 4px 12px rgba(239,68,68,0.3); }

.stat-gif {
 width: 24px;
 height: 24px;
 object-fit: contain;
}
.stat-trend {
 font-size: 11px;
 font-weight: 700;
 padding: 3px 8px;
 border-radius: var(--radius-sm);
 letter-spacing: 0.02em;
}
.stat-trend-up {
 color: #15803d;
 background: rgba(34,197,94,0.1);
}
.stat-trend-down {
 color: #b91c1c;
 background: rgba(239,68,68,0.1);
}
.stat-trend i {
 font-size: 9px;
 margin-right: 2px;
}
.stat-value {
 font-size: 28px;
 font-weight: 700;
 color: var(--text-primary);
 letter-spacing: -0.03em;
 line-height: 1.1;
}
.stat-label {
 font-size: var(--text-sm);
 color: var(--text-secondary);
 font-weight: 500;
 margin-top: var(--space-1);
}

/* ═══ Dashboard Grid (2-column) ═══════════════════════════════ */
.dashboard-grid {
 display: grid;
 gap: var(--space-6);
}
@media (min-width: 1024px) {
 .dashboard-grid {
 grid-template-columns: 1fr 380px;
 }
}

/* ═══ Right Column ═════════════════════════════════════════════ */
.dash-right-col {
 display: flex;
 flex-direction: column;
 gap: var(--space-6);
}

/* ═══ Dash Card ═══════════════════════════════════════════════ */
.dash-card {
 background: var(--bg-surface);
 border: 1px solid var(--border-light);
 border-radius: var(--radius-lg);
 overflow: hidden;
 transition: all var(--duration-base) var(--ease-out);
}

.dash-card:hover {
 box-shadow: var(--shadow-sm);
 border-color: var(--border-medium);
}
.dash-card-header {
 display: flex;
 align-items: flex-start;
 justify-content: space-between;
 padding: var(--space-5) var(--space-5) 0;
}
.dash-card-title-group {
 display: flex;
 align-items: center;
 gap: var(--space-3);
}
.dash-card-icon {
 width: 40px;
 height: 40px;
 border-radius: var(--radius-md);
 display: flex;
 align-items: center;
 justify-content: center;
 font-size: 16px;
 color: #fff;
 flex-shrink: 0;
}
.dash-card-icon-primary { background: linear-gradient(135deg, #3b82f6, #5b6ef5); box-shadow: 0 4px 10px rgba(59,130,246,0.25); }
.dash-card-icon-green { background: linear-gradient(135deg, #22c55e, #16a34a); box-shadow: 0 4px 10px rgba(34,197,94,0.25); }
.dash-card-icon-orange { background: linear-gradient(135deg, #f59e0b, #d97706); box-shadow: 0 4px 10px rgba(245,158,11,0.25); }
.dash-card-icon-purple { background: linear-gradient(135deg, #7c5cfc, #6366f1); box-shadow: 0 4px 10px rgba(124,92,252,0.25); }
.dash-card-icon-info { background: linear-gradient(135deg, #0ea5e9, #0284c7); box-shadow: 0 4px 10px rgba(14,165,233,0.25); }

.dash-card-gif {
 width: 22px;
 height: 22px;
 object-fit: contain;
}
.dash-card-title {
 font-size: var(--text-base);
 font-weight: 600;
 color: var(--text-primary);
 letter-spacing: -0.01em;
 line-height: 1.2;
}
.dash-card-subtitle {
 font-size: var(--text-xs);
 color: var(--text-secondary);
 font-weight: 500;
 margin-top: 2px;
}
.dash-card-link {
 display: inline-flex;
 align-items: center;
 gap: var(--space-1);
 font-size: var(--text-xs);
 font-weight: 600;
 color: var(--primary);
 text-decoration: none;
 padding: 4px 10px;
 border-radius: var(--radius-sm);
 transition: all var(--duration-fast) var(--ease-out);
 white-space: nowrap;
}
.dash-card-link:hover {
 background: var(--primary-soft);
 gap: var(--space-2);
}
.dash-card-link i {
 font-size: 10px;
 transition: transform var(--duration-fast) var(--ease-out);
}
.dash-card-link:hover i {
 transform: translateX(2px);
}
.dash-card-body {
 padding: var(--space-5);
}

/* ═══ Table ═══════════════════════════════════════════════════ */
.table-wrap {
 overflow-x: auto;
 margin: 0 calc(-1 * var(--space-5));
 padding: 0 var(--space-5);
}
.dash-table {
 width: 100%;
 border-collapse: collapse;
 min-width: 480px;
}
.dash-table thead th {
 text-align: left;
 padding: var(--space-3) var(--space-2);
 font-size: 11px;
 font-weight: 700;
 text-transform: uppercase;
 letter-spacing: 0.08em;
 color: var(--text-tertiary);
 border-bottom: 1px solid var(--border-light);
 white-space: nowrap;
}
.dash-table tbody td {
 padding: var(--space-3) var(--space-2);
 font-size: var(--text-sm);
 color: var(--text-primary);
 border-bottom: 1px solid var(--border-light);
 vertical-align: middle;
}
.dash-table tbody tr:last-child td {
 border-bottom: none;
}
.dash-table tbody tr {
 transition: background var(--duration-fast) var(--ease-out);
}
.dash-table tbody tr:hover {
 background: var(--bg-hover);
}
.lead-name {
 display: flex;
 align-items: center;
 gap: var(--space-3);
}
.lead-avatar {
 width: 32px;
 height: 32px;
 border-radius: var(--radius-sm);
 background: linear-gradient(135deg, var(--primary), var(--accent));
 color: #fff;
 display: flex;
 align-items: center;
 justify-content: center;
 font-size: 13px;
 font-weight: 700;
 flex-shrink: 0;
}
.lead-name-text {
 font-weight: 600;
 color: var(--text-primary);
 font-size: var(--text-sm);
 letter-spacing: -0.01em;
}
.lead-email {
 font-size: 12px;
 color: var(--text-tertiary);
 margin-top: 1px;
}
.row-action {
 display: inline-flex;
 align-items: center;
 justify-content: center;
 width: 30px;
 height: 30px;
 border-radius: var(--radius-sm);
 color: var(--text-tertiary);
 text-decoration: none;
 transition: all var(--duration-fast) var(--ease-out);
}
.row-action:hover {
 background: var(--bg-hover);
 color: var(--text-primary);
}

/* ═══ Badges ═══════════════════════════════════════════════════ */
.badge-sm {
 display: inline-flex;
 align-items: center;
 padding: 3px 10px;
 font-size: 11px;
 font-weight: 700;
 border-radius: var(--radius-sm);
 letter-spacing: 0.02em;
 text-transform: uppercase;
 white-space: nowrap;
}
.badge-success { background: rgba(34,197,94,0.1); color: #15803d; }
.badge-danger { background: rgba(239,68,68,0.1); color: #b91c1c; }
.badge-warning { background: rgba(245,158,11,0.1); color: #b45309; }
.badge-info { background: rgba(14,165,233,0.1); color: #0369a1; }
.badge-neutral { background: var(--bg-surface-secondary); color: var(--text-secondary); border: 1px solid var(--border-light); }

/* ═══ Status Breakdown ═══════════════════════════════════════ */
.status-breakdown {
 display: flex;
 flex-direction: column;
 gap: var(--space-4);
}
.status-row {
 display: flex;
 align-items: center;
 gap: var(--space-3);
}
.status-info {
 display: flex;
 align-items: center;
 justify-content: space-between;
 width: 90px;
 flex-shrink: 0;
}
.status-label {
 font-size: var(--text-sm);
 font-weight: 500;
 color: var(--text-secondary);
}
.status-count {
 font-size: var(--text-sm);
 font-weight: 700;
 color: var(--text-primary);
 font-variant-numeric: tabular-nums;
}
.status-bar-bg {
 flex: 1;
 height: 8px;
 background: var(--bg-surface-secondary);
 border-radius: var(--radius-pill);
 overflow: hidden;
}
.status-bar-fill {
 height: 100%;
 border-radius: var(--radius-pill);
 transition: width 0.8s cubic-bezier(0.16, 1, 0.3, 1);
}
.status-bar-new { background: linear-gradient(90deg, #0ea5e9, #3b82f6); }
.status-bar-contacted { background: linear-gradient(90deg, #f59e0b, #f97316); }
.status-bar-confirmed { background: linear-gradient(90deg, #22c55e, #16a34a); }
.status-bar-lose { background: linear-gradient(90deg, #ef4444, #dc2626); }
.status-pct {
 font-size: 12px;
 font-weight: 600;
 color: var(--text-tertiary);
 width: 32px;
 text-align: right;
 flex-shrink: 0;
 font-variant-numeric: tabular-nums;
}

/* ═══ Quick Actions Grid ══════════════════════════════════════ */
.quick-actions-grid {
 display: grid;
 grid-template-columns: repeat(3, 1fr);
 gap: var(--space-3);
}
.qa-item {
 display: flex;
 flex-direction: column;
 align-items: center;
 gap: var(--space-2);
 padding: var(--space-4) var(--space-2);
 background: var(--bg-surface-secondary);
 border: 1px solid var(--border-light);
 border-radius: var(--radius-md);
 text-decoration: none;
 transition: all var(--duration-fast) var(--ease-out);
}
.qa-item:hover {
 border-color: var(--border-medium);
 background: var(--bg-hover);
 transform: translateY(-2px);
 box-shadow: var(--shadow-sm);
}
.qa-icon {
 width: 44px;
 height: 44px;
 border-radius: var(--radius-md);
 display: flex;
 align-items: center;
 justify-content: center;
 font-size: 18px;
 transition: transform var(--duration-fast) var(--ease-out);
}
.qa-item:hover .qa-icon {
 transform: scale(1.1);
}
.qa-icon-primary { background: rgba(91,110,245,0.1); color: var(--primary); }
.qa-icon-green { background: rgba(34,197,94,0.1); color: #16a34a; }
.qa-icon-orange { background: rgba(245,158,11,0.1); color: #d97706; }
.qa-icon-purple { background: rgba(124,92,252,0.1); color: var(--accent); }
.qa-icon-blue { background: rgba(14,165,233,0.1); color: #0284c7; }
.qa-gif {
 width: 26px;
 height: 26px;
 object-fit: contain;
}
.qa-label {
 font-size: 12px;
 font-weight: 600;
 color: var(--text-secondary);
 text-align: center;
 transition: color var(--duration-fast) var(--ease-out);
}
.qa-item:hover .qa-label {
 color: var(--text-primary);
}

/* ═══ Project List ═════════════════════════════════════════════ */
.project-list {
 display: flex;
 flex-direction: column;
 gap: var(--space-3);
}
.project-item {
 display: flex;
 align-items: center;
 gap: var(--space-3);
 padding: var(--space-3);
 background: var(--bg-surface-secondary);
 border-radius: var(--radius-md);
 transition: all var(--duration-fast) var(--ease-out);
}
.project-item:hover {
 background: var(--bg-hover);
}
.project-dot {
 width: 8px;
 height: 8px;
 border-radius: 50%;
 flex-shrink: 0;
}
.project-dot.running { background: #22c55e; box-shadow: 0 0 8px rgba(34,197,94,0.4); animation: pulse-soft 2s ease-in-out infinite; }
.project-dot.pending { background: #f59e0b; box-shadow: 0 0 8px rgba(245,158,11,0.4); }
.project-info {
 flex: 1;
 min-width: 0;
}
.project-name {
 display: block;
 font-size: var(--text-sm);
 font-weight: 600;
 color: var(--text-primary);
 letter-spacing: -0.01em;
 white-space: nowrap;
 overflow: hidden;
 text-overflow: ellipsis;
}
.project-meta {
 display: block;
 font-size: 12px;
 color: var(--text-tertiary);
 font-weight: 500;
 margin-top: 1px;
}

/* ═══ Activity Timeline ═══════════════════════════════════════ */
.timeline {
 display: flex;
 flex-direction: column;
 gap: 0;
}
.timeline-item {
 display: flex;
 gap: var(--space-4);
 position: relative;
 padding-bottom: var(--space-4);
}
.timeline-item:not(:last-child)::before {
 content: '';
 position: absolute;
 left: 7px;
 top: 20px;
 bottom: 0;
 width: 2px;
 background: var(--border-light);
}
.timeline-dot {
 width: 16px;
 height: 16px;
 border-radius: 50%;
 background: var(--bg-surface);
 border: 3px solid var(--primary);
 flex-shrink: 0;
 margin-top: 2px;
 position: relative;
 z-index: 1;
}
.timeline-content {
 flex: 1;
 min-width: 0;
}
.timeline-header {
 display: flex;
 align-items: center;
 gap: var(--space-2);
 flex-wrap: wrap;
}
.timeline-user {
 font-size: var(--text-sm);
 font-weight: 600;
 color: var(--text-primary);
}
.timeline-action {
 font-size: 11px;
 font-weight: 700;
 padding: 2px 8px;
 background: var(--primary-soft);
 color: var(--primary);
 border-radius: var(--radius-sm);
 text-transform: uppercase;
 letter-spacing: 0.03em;
}
.timeline-time {
 font-size: 12px;
 color: var(--text-tertiary);
 font-weight: 500;
 margin-left: auto;
}
.timeline-details {
 font-size: var(--text-sm);
 color: var(--text-secondary);
 margin-top: var(--space-1);
 line-height: 1.5;
}

/* ═══ Empty States ════════════════════════════════════════════ */
.empty-state {
 text-align: center;
 padding: var(--space-10) var(--space-4);
}
.empty-icon {
 width: 64px;
 height: 64px;
 border-radius: var(--radius-lg);
 background: var(--bg-surface-secondary);
 display: flex;
 align-items: center;
 justify-content: center;
 margin: 0 auto var(--space-4);
}
.empty-icon .empty-gif {
 width: 36px;
 height: 36px;
 object-fit: contain;
}
.empty-icon i {
 font-size: 24px;
 color: var(--text-tertiary);
}
.empty-title {
 font-size: var(--text-base);
 font-weight: 600;
 color: var(--text-primary);
 margin-bottom: var(--space-2);
}
.empty-text {
 font-size: var(--text-sm);
 color: var(--text-secondary);
 margin-bottom: var(--space-4);
 max-width: 320px;
 margin-left: auto;
 margin-right: auto;
}
.empty-state-sm {
 text-align: center;
 padding: var(--space-6) var(--space-4);
}
.timeline-empty {
 display: flex;
 flex-direction: column;
 align-items: center;
 gap: var(--space-2);
 padding: var(--space-6);
}
.timeline-empty i {
 font-size: 32px;
 color: var(--text-tertiary);
 opacity: 0.4;
}

/* ═══ Buttons ══════════════════════════════════════════════════ */
.btn {
 display: inline-flex;
 align-items: center;
 justify-content: center;
 gap: var(--space-2);
 padding: var(--space-2) var(--space-4);
 font-size: var(--text-sm);
 font-weight: 600;
 letter-spacing: -0.01em;
 border-radius: var(--radius-md);
 border: 1px solid transparent;
 cursor: pointer;
 transition: all var(--duration-fast) var(--ease-out);
 text-decoration: none;
 white-space: nowrap;
 min-height: 36px;
 font-family: inherit;
}
.btn:active { transform: scale(0.97); }
.btn-primary {
 background: var(--primary);
 color: #fff;
 box-shadow: 0 1px 3px rgba(91,110,245,0.3);
}
.btn-primary:hover {
 background: var(--primary-hover);
 box-shadow: 0 4px 12px rgba(91,110,245,0.3);
 transform: translateY(-1px);
}
.btn-secondary {
 background: var(--bg-surface);
 color: var(--text-primary);
 border-color: var(--border-medium);
}
.btn-secondary:hover {
 background: var(--bg-hover);
 border-color: var(--border-focus);
}
.btn-sm {
 padding: var(--space-1) var(--space-3);
 font-size: var(--text-xs);
 min-height: 28px;
}

/* ═══ Utility ═════════════════════════════════════════════════ */
.text-sm { font-size: var(--text-sm); }
.text-muted { color: var(--text-secondary); }
</style>
