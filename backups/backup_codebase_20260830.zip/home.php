<?php
$pageTitle = 'Best Digital Marketing Agency in Pudhucherry';
require_once __DIR__ . '/app/config.php';

// Fetch active services from DB
$services = $conn->query("SELECT * FROM services WHERE status = 'active' ORDER BY created_at ASC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);

// Fetch active FAQs
$faq_items = [];
try {
    $faq_items = $conn->query("SELECT * FROM faqs WHERE status = 'active' ORDER BY COALESCE(sort_order, 0) ASC, created_at ASC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $faq_items = [];
}

// Fetch reviews (approved only)
$reviews = $conn->query("SELECT * FROM reviews WHERE status = 'approved' ORDER BY created_at DESC LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);

// Fetch active testimonials
$testimonials = $conn->query("SELECT * FROM testimonials WHERE status = 'active' ORDER BY created_at DESC LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);

// Fetch database counts for stats
$db_projects = (int)$conn->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$db_leads = (int)$conn->query("SELECT COUNT(*) FROM leads")->fetchColumn();
$db_services = (int)$conn->query("SELECT COUNT(*) FROM services WHERE status = 'active'")->fetchColumn();

// Calculate client satisfaction
$db_avg_rating = $conn->query("SELECT AVG(star_rating) FROM reviews WHERE status = 'approved' OR status IS NULL")->fetchColumn();
$satisfaction_percentage = ($db_avg_rating !== null && $db_avg_rating > 0) ? round(($db_avg_rating / 5) * 100) : 100;

$stat_projects = $db_projects;
$stat_clients = $db_leads;
$stat_satisfaction = $satisfaction_percentage . '%';
$stat_services = $db_services;

// Fallback service icons
$default_icons = ['fa-search','fa-share-alt','fa-google','fa-bullhorn','fa-pen-fancy','fa-code'];

require_once __DIR__ . '/app/Views/frontend/home.php';
