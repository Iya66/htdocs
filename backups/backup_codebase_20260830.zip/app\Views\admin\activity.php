<?php
require_once __DIR__ . '/../../../admin/includes/header.php';
?>

<style>
.activity-filters { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 24px; align-items: flex-end; }
.filter-group { display: flex; flex-direction: column; gap: 8px; }
.filter-group label { font-size: 13px; color: var(--text-main); font-weight: 600; }
.filter-group select, .filter-group input { 
    padding: 12px 16px; border: 1px solid var(--border-color); 
    border-radius: var(--btn-radius); background: var(--bg-main); 
    color: var(--text-main); font-size: 13px; min-width: 150px; 
    transition: all var(--transition);
}
.filter-group select:focus, .filter-group input:focus { outline: none; border-color: var(--primary); }

.stat-pills { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 24px; margin-bottom: 32px; }
.stat-pill { 
    background: var(--bg-card); border: 1px solid var(--border-color); 
    border-radius: var(--border-radius); padding: 24px; display: flex; 
    align-items: center; gap: 16px; box-shadow: var(--shadow-sm); 
    transition: all var(--transition);
}
.stat-pill:hover { transform: translateY(-4px); box-shadow: var(--shadow-md); border-color: var(--primary); }
.stat-pill .icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; }
.stat-pill .icon.blue { background: color-mix(in srgb, var(--primary) 15%, transparent); color: var(--primary); }
.stat-pill .icon.green { background: color-mix(in srgb, var(--success) 15%, transparent); color: var(--success); }
.stat-pill .icon.red { background: color-mix(in srgb, var(--danger) 15%, transparent); color: var(--danger); }
.stat-pill .icon.orange { background: color-mix(in srgb, var(--warning) 15%, transparent); color: var(--warning); }
.stat-pill .info strong { font-size: 24px; color: var(--text-main); display: block; font-weight: 700; margin-bottom: 4px; }
.stat-pill .info span { font-size: 13px; color: var(--text-muted); font-weight: 500; }

.activity-table { width: 100%; border-collapse: separate; border-spacing: 0; }
.activity-table th { 
    color: var(--text-muted); padding: 16px 20px; text-align: left; 
    font-size: 13px; font-weight: 600; text-transform: uppercase; 
    letter-spacing: 0.05em; border-bottom: 2px solid var(--border-color); 
}
.activity-table td { padding: 16px 20px; border-bottom: 1px solid var(--border-color); background: var(--bg-card); transition: all var(--transition); }
.activity-table tr:hover td { background: color-mix(in srgb, var(--primary) 5%, transparent); }

.activity-badge { display: inline-flex; padding: 6px 12px; border-radius: 8px; font-size: 11px; font-weight: 600; border: 1px solid var(--border-color); }
.badge-login { background: color-mix(in srgb, var(--primary) 15%, transparent); color: var(--primary); border-color: color-mix(in srgb, var(--primary) 30%, transparent); }
.badge-success { background: color-mix(in srgb, var(--success) 15%, transparent); color: var(--success); border-color: color-mix(in srgb, var(--success) 30%, transparent); }
.badge-warning { background: color-mix(in srgb, var(--warning) 15%, transparent); color: var(--warning); border-color: color-mix(in srgb, var(--warning) 30%, transparent); }
.badge-danger { background: color-mix(in srgb, var(--danger) 15%, transparent); color: var(--danger); border-color: color-mix(in srgb, var(--danger) 30%, transparent); }
.badge-info { background: color-mix(in srgb, var(--primary) 15%, transparent); color: var(--primary); border-color: color-mix(in srgb, var(--primary) 30%, transparent); }

.user-cell { display: flex; align-items: center; gap: 12px; }
.user-avatar { width: 36px; height: 36px; border-radius: 50%; background: color-mix(in srgb, var(--primary) 15%, transparent); display: flex; align-items: center; justify-content: center; color: var(--primary); font-weight: 700; font-size: 14px; }
.ip-cell { font-family: monospace; color: var(--text-muted); font-size: 12px; }
.time-cell { font-size: 13px; color: var(--text-muted); white-space: nowrap; }

.pagination { display: flex; justify-content: center; gap: 8px; margin-top: 32px; }
.pagination a, .pagination span { padding: 10px 16px; background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--btn-radius); text-decoration: none; color: var(--text-main); font-size: 14px; transition: all var(--transition); }
.pagination a:hover { border-color: var(--primary); color: var(--primary); }
.pagination .active { background: var(--primary); color: #fff; border-color: var(--primary); }
.empty-state { text-align: center; padding: 80px 20px; color: var(--text-muted); }
.empty-state i { font-size: 48px; opacity: 0.3; display: block; margin-bottom: 16px; }
</style>

<div class="saas-page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-history" style="color: var(--primary);"></i> Activity History & Audit Logs</h1>
        <p class="page-subtitle">Inspect user actions, session security, IP tracking, and system events.</p>
    </div>
    <div class="header-actions">
        <a href="export-activity" class="btn btn-primary">
            <i class="fas fa-download"></i> Export Logs
        </a>
    </div>
</div>

<!-- Stats Cards -->
<div class="stat-pills">
    <div class="stat-pill">
        <div class="icon blue"><i class="fas fa-sign-in-alt"></i></div>
        <div class="info">
            <strong><?= number_format($stats['logins_today']) ?></strong>
            <span>Logins Today</span>
        </div>
    </div>
    <div class="stat-pill">
        <div class="icon red"><i class="fas fa-exclamation-triangle"></i></div>
        <div class="info">
            <strong><?= number_format($stats['failed_logins_today']) ?></strong>
            <span>Failed Logins</span>
        </div>
    </div>
    <div class="stat-pill">
        <div class="icon orange"><i class="fas fa-history"></i></div>
        <div class="info">
            <strong><?= number_format($stats['activities_week']) ?></strong>
            <span>This Week</span>
        </div>
    </div>
    <div class="stat-pill">
        <div class="icon green"><i class="fas fa-desktop"></i></div>
        <div class="info">
            <strong><?= number_format($stats['active_sessions']) ?></strong>
            <span>Active Sessions</span>
        </div>
    </div>
    <?php if ($stats['unresolved_alerts'] > 0): ?>
    <div class="stat-pill" style="border-color: rgba(239, 68, 68, 0.3);">
        <div class="icon red"><i class="fas fa-bell"></i></div>
        <div class="info">
            <strong><?= number_format($stats['unresolved_alerts']) ?></strong>
            <span>Security Alerts</span>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Filters -->
<form method="GET" class="activity-filters">
    <div class="filter-group">
        <label>Action Type</label>
        <select name="action">
            <option value="">All Actions</option>
            <?php foreach ($unique_actions as $a): ?>
                <option value="<?= htmlspecialchars($a['action']) ?>" <?= $filter_action === $a['action'] ? 'selected' : '' ?>><?= htmlspecialchars($a['action']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="filter-group">
        <label>User</label>
        <select name="user">
            <option value="">All Users</option>
            <?php foreach ($unique_users as $u): ?>
                <option value="<?= htmlspecialchars($u['name']) ?>" <?= $filter_user === $u['name'] ? 'selected' : '' ?>><?= htmlspecialchars($u['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="filter-group">
        <label>IP Address</label>
        <input type="text" name="ip" value="<?= htmlspecialchars($filter_ip) ?>" placeholder="Search IP...">
    </div>
    <div class="filter-group">
        <label>From Date</label>
        <input type="date" name="from" value="<?= htmlspecialchars($date_from) ?>" class="form-control">
    </div>
    <div class="filter-group">
        <label>To Date</label>
        <input type="date" name="to" value="<?= htmlspecialchars($date_to) ?>" class="form-control">
    </div>
    <div class="filter-group" style="align-self: flex-end;">
        <button type="submit" class="btn btn-primary" style="padding: 10px 20px;">
            <i class="fas fa-search"></i> Filter
        </button>
    </div>
    <div class="filter-group" style="align-self: flex-end;">
        <a href="activity" class="btn btn-edit" style="padding: 10px 20px;">
            <i class="fas fa-times"></i> Clear
        </a>
    </div>
</form>

<!-- Activity Table -->
<div class="content-card" style="padding: 0; overflow: hidden;">
    <?php if (empty($activities)): ?>
        <div class="empty-state">
            <i class="fas fa-inbox"></i>
            <p>No activities found</p>
        </div>
    <?php else: ?>
        <table class="activity-table">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Action</th>
                    <th>Details</th>
                    <th>IP Address</th>
                    <th>Device</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($activities as $activity): ?>
                    <?php
                    $badgeClass = 'badge-info';
                    if (stripos($activity['action'], 'LOGIN_SUCCESS') !== false) $badgeClass = 'badge-success';
                    if (stripos($activity['action'], 'LOGIN_FAILED') !== false) $badgeClass = 'badge-danger';
                    if (stripos($activity['action'], 'DELETE') !== false) $badgeClass = 'badge-warning';
                    if (stripos($activity['action'], 'CREATE') !== false) $badgeClass = 'badge-info';
                    if (stripos($activity['action'], 'UPDATE') !== false) $badgeClass = 'badge-info';
                    ?>
                    <tr>
                        <td>
                            <div class="user-cell">
                                <div class="user-avatar"><?= strtoupper(substr($activity['user_name'] ?? 'S', 0, 1)) ?></div>
                                <div>
                                    <strong style="color: var(--text-primary);"><?= htmlspecialchars($activity['user_name'] ?? 'System') ?></strong>
                                    <div style="font-size: 11px; color: var(--text-muted);"><?= htmlspecialchars($activity['user_email'] ?? '') ?></div>
                                </div>
                            </div>
                        </td>
                        <td><span class="activity-badge <?= $badgeClass ?>"><?= htmlspecialchars(str_replace('_', ' ', $activity['action'])) ?></span></td>
                        <td style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?= htmlspecialchars($activity['details']) ?>"><?= htmlspecialchars($activity['details']) ?></td>
                        <td class="ip-cell"><?= htmlspecialchars($activity['ip_address'] ?? '-') ?></td>
                        <td style="font-size: 12px; color: var(--text-secondary);"><?= htmlspecialchars($activity['device_info'] ?? '-') ?></td>
                        <td class="time-cell"><?= date('M d, Y<br>H:i', strtotime($activity['created_at'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- Pagination -->
<?php if ($total_pages > 1): ?>
<div class="pagination">
    <?php if ($page > 1): ?>
        <a href="?page=<?= $page - 1 ?>&action=<?= urlencode($filter_action) ?>&user=<?= urlencode($filter_user) ?>&ip=<?= urlencode($filter_ip) ?>&from=<?= urlencode($date_from) ?>&to=<?= urlencode($date_to) ?>"><i class="fas fa-chevron-left"></i></a>
    <?php endif; ?>

    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
        <?php if ($i == $page): ?>
            <span class="active"><?= $i ?></span>
        <?php else: ?>
            <a href="?page=<?= $i ?>&action=<?= urlencode($filter_action) ?>&user=<?= urlencode($filter_user) ?>&ip=<?= urlencode($filter_ip) ?>&from=<?= urlencode($date_from) ?>&to=<?= urlencode($date_to) ?>"><?= $i ?></a>
        <?php endif; ?>
    <?php endfor; ?>

    <?php if ($page < $total_pages): ?>
        <a href="?page=<?= $page + 1 ?>&action=<?= urlencode($filter_action) ?>&user=<?= urlencode($filter_user) ?>&ip=<?= urlencode($filter_ip) ?>&from=<?= urlencode($date_from) ?>&to=<?= urlencode($date_to) ?>"><i class="fas fa-chevron-right"></i></a>
    <?php endif; ?>
</div>
<?php endif; ?>

<p style="text-align: center; color: var(--text-muted); margin-top: 20px;">
    Showing <?= number_format($offset + 1) ?> - <?= number_format(min($offset + $per_page, $total_activities)) ?> of <?= number_format($total_activities) ?> activities
</p>

<?php require_once __DIR__ . '/../../../admin/includes/footer.php'; ?>