<?php
/**
 * Homepage - index.php
 * Production-ready | SEO-optimised | Mobile-first
 */

// Fallbacks for stats if not set by controller
$site_name = $site_name ?? 'Cloud Aspire';
$stat_projects = $stat_projects ?? 150;
$stat_clients = $stat_clients ?? 120;
$stat_services = $stat_services ?? 6;
$stat_satisfaction = $stat_satisfaction ?? '99%';

// Limit services to 3 for homepage layout
if (!empty($services) && count($services) > 3) {
    $services = array_slice($services, 0, 3);
}
$faq_items = $faq_items ?? [];
$reviews = $reviews ?? [];

// SEO Meta Variables
$pageTitle = $site_name . " | Digital Marketing Agency";
$pageDesc = "Partner with " . $site_name . " — a results-driven digital marketing agency specialising in SEO, PPC, Social Media, and Web Development. Get your free consultation today.";
$canonical_url = "https://" . ($_SERVER['HTTP_HOST'] ?? 'cloudaspire.com') . "/";
?>
<?php include __DIR__ . '/../../../includes/header.php'; ?>
<?php include __DIR__ . '/../../../includes/intro.php'; ?>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "MarketingAgency",
  "name": "<?= addslashes($site_name) ?>",
  "url": "<?= $canonical_url ?>",
  "description": "<?= addslashes($pageDesc) ?>"
}
</script>

<?php if (!empty($reviews)): ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "<?= addslashes($site_name) ?>",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "<?= number_format(array_sum(array_column($reviews, 'star_rating')) / count($reviews), 1) ?>",
    "reviewCount": "<?= count($reviews) ?>"
  }
}
</script>
<?php endif; ?>

<style>
/* ══════════════════════════════════════════════
   DESIGN SYSTEM — CSS Custom Properties
   ══════════════════════════════════════════════ */
:root {
    --c-primary:       #6366f1; /* Indigo */
    --c-primary-h:     #4f46e5;
    --c-accent:        #f43f5e; /* Rose */
    --c-surface:       #ffffff;
    --c-bg:            #f8fafc;
    --c-bg-alt:        #ffffff;
    --c-text:          #0f172a;
    --c-muted:         #64748b;
    --c-border:        rgba(99, 102, 241, 0.08);
    --c-shadow:        0 12px 40px -12px rgba(99, 102, 241, 0.05);
    --c-shadow-hover:  0 25px 50px -12px rgba(99, 102, 241, 0.16);

    /* Standardized Radii System Token Scale (5 tokens) */
    --r-xs:            6px;
    --r-sm:            12px;
    --r-md:            18px;
    --radius-card:     24px;
    --radius-pill:     100px;

    /* Standardized Type Scale System Tokens (8 steps <= 10 limit) */
    --fs-xs:           0.75rem;   /* 12px - min accessible text, labels, badges */
    --fs-sm:           0.875rem;  /* 14px - small body, metadata */
    --fs-base:         1rem;      /* 16px - standard body copy, buttons */
    --fs-md:           1.125rem;  /* 18px - lead text, sub-headers */
    --fs-lg:           1.25rem;   /* 20px - card headings */
    --fs-xl:           1.5rem;    /* 24px - major section subheadings */
    --fs-2xl:          clamp(1.8rem, 4vw, 2.5rem); /* 28-40px section titles */
    --fs-3xl:          clamp(2.4rem, 5.8vw, 4rem);  /* Hero display heading */

    --transition:      0.35s cubic-bezier(0.16, 1, 0.3, 1);
    --max-w:           1200px;
}

/* ── Reset & Base ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body {
    font-family: 'Sora', 'Segoe UI', system-ui, sans-serif;
    background: var(--c-bg);
    color: var(--c-text);
    overflow-x: hidden;
    -webkit-font-smoothing: antialiased;
}
img { display: block; max-width: 100%; }
a  { text-decoration: none; color: inherit; }

.container { width: 100%; max-width: var(--max-w); margin: 0 auto; padding: 0 20px; }

/* ── BUTTONS ── */
.btn {
    display: inline-flex; align-items: center; justify-content: center;
    gap: 8px; padding: 14px 32px;
    border-radius: var(--radius-pill);
    font-weight: 700; font-size: var(--fs-base);
    transition: all var(--transition);
    border: 2px solid transparent;
    cursor: pointer; white-space: nowrap;
}
.btn-primary {
    position: relative;
    overflow: hidden;
    background: var(--c-primary);
    color: #fff;
    box-shadow: 0 8px 24px rgba(99, 102, 241, 0.25);
    transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}
.btn-primary::after {
    content: '';
    position: absolute;
    top: -50%; left: -75%;
    width: 50%; height: 200%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.35), transparent);
    transform: rotate(25deg);
    transition: left 0.75s ease;
}
.btn-primary:hover::after {
    left: 140%;
}
.btn-primary:hover {
    background: var(--c-primary-h);
    transform: translateY(-3px);
    box-shadow: 0 16px 32px rgba(99, 102, 241, 0.35);
    color: #fff;
}
.btn-ghost {
    background: var(--c-surface);
    color: var(--c-text);
    box-shadow: var(--c-shadow);
    border: 1px solid rgba(99, 102, 241, 0.1);
    transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.35s cubic-bezier(0.16, 1, 0.3, 1), border-color 0.35s;
}
.btn-ghost:hover {
    border-color: var(--c-primary);
    color: var(--c-primary);
    transform: translateY(-3px);
    box-shadow: 0 12px 24px rgba(99, 102, 241, 0.08);
}

/* ── SECTION SCAFFOLDING ── */
.section { padding: 96px 0; }
.section-header { text-align: center; max-width: 680px; margin: 0 auto 56px; }
.section-header h2 { font-size: var(--fs-2xl); font-weight: 800; line-height: 1.18; margin-bottom: 14px; letter-spacing: -0.02em; }
.section-header p  { color: var(--c-muted); font-size: var(--fs-md); line-height: 1.75; }
.highlight {
    color: var(--c-primary);
}

/* ── HERO ── */
.hero {
    padding: clamp(100px, 15vw, 170px) 0 110px;
    background: #ffffff;
    position: relative;
    overflow: hidden;
}
.hero::before {
    content: '';
    position: absolute; inset: 0;
    background-image: radial-gradient(rgba(99, 102, 241, 0.05) 1.5px, transparent 1.5px);
    background-size: 32px 32px;
    pointer-events: none;
}
.hero-grid { display: grid; grid-template-columns: 1fr; gap: 48px; align-items: center; position: relative; }
.hero-badge {
    display: inline-flex; align-items: center; gap: 8px;
    background: rgba(99, 102, 241, 0.06); color: var(--c-primary);
    border: 1px solid rgba(99, 102, 241, 0.15);
    border-radius: var(--radius-pill); padding: 8px 18px;
    font-size: var(--fs-xs); font-weight: 700; letter-spacing: .06em; text-transform: uppercase;
    margin-bottom: 24px;
    box-shadow: 0 4px 12px rgba(99, 102, 241, 0.04);
}
.hero-badge span { width: 6px; height: 6px; background: var(--c-primary); border-radius: 50%; animation: pulse 2s infinite; }
.hero h1 { font-size: var(--fs-3xl); font-weight: 800; line-height: 1.12; letter-spacing: -0.02em; margin-bottom: 24px; color: #0f172a; }
.hero p  { font-size: var(--fs-md); color: var(--c-muted); margin-bottom: 36px; line-height: 1.75; max-width: 600px; }
.hero-btns { display: flex; gap: 14px; flex-wrap: wrap; }
.hero-img-wrap {
    border-radius: var(--radius-card);
    box-shadow: 0 30px 70px -15px rgba(99, 102, 241, 0.28);
    animation: float 8s ease-in-out infinite;
    background: #1e1b4b;
    border: 1px solid rgba(255, 255, 255, 0.15);
    overflow: hidden;
    position: relative;
    display: flex;
    flex-direction: column;
}
.mockup-header {
    height: 32px;
    background: rgba(255, 255, 255, 0.05);
    display: flex;
    align-items: center;
    padding: 0 16px;
    gap: 6px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}
.mockup-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
}
.mockup-dot.red { background: #ef4444; }
.mockup-dot.yellow { background: #f59e0b; }
.mockup-dot.green { background: #10b981; }
.mockup-url {
    background: rgba(255, 255, 255, 0.08);
    height: 20px;
    border-radius: var(--r-xs);
    flex-grow: 1;
    margin-left: 20px;
    max-width: 240px;
    font-size: var(--fs-xs);
    color: rgba(255, 255, 255, 0.7);
    display: flex;
    align-items: center;
    padding-left: 8px;
    font-family: monospace;
    letter-spacing: 0.5px;
}
.mockup-body {
    flex-grow: 1;
    aspect-ratio: 16/10;
    overflow: hidden;
}
.mockup-body img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

/* ── LOGO CLOUD ── */
.logo-cloud-section {
    padding: 56px 0;
    border-bottom: 1px solid rgba(99, 102, 241, 0.06);
    background: #ffffff;
    overflow: hidden;
}
.logo-cloud-title {
    text-align: center;
    font-size: var(--fs-xs);
    font-weight: 700;
    letter-spacing: 0.15em;
    color: var(--c-muted);
    margin-bottom: 28px;
    text-transform: uppercase;
}
.logo-ticker-wrap {
    overflow: hidden;
    position: relative;
    width: 100%;
    mask-image: linear-gradient(to right, transparent 0%, #000 8%, #000 92%, transparent 100%);
    -webkit-mask-image: linear-gradient(to right, transparent 0%, #000 8%, #000 92%, transparent 100%);
}
.logo-ticker-track {
    display: flex;
    align-items: center;
    gap: 60px;
    width: max-content;
    animation: marquee 60s linear infinite;
}
.logo-ticker-wrap:hover .logo-ticker-track {
    animation-play-state: paused;
}
.logo-item {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    font-size: var(--fs-md);
    font-weight: 800;
    color: #475569;
    letter-spacing: -0.02em;
    white-space: nowrap;
    opacity: 0.75;
    transition: opacity 0.3s, transform 0.3s;
}
.logo-item i {
    font-size: var(--fs-lg);
    color: var(--c-primary);
}
.logo-item:hover {
    opacity: 1;
    transform: translateY(-2px);
}

@keyframes marquee {
    0%   { transform: translateX(0); }
    100% { transform: translateX(-50%); }
}

/* ── STATS ── */
.stats-section { padding: 0 20px; margin-top: -56px; position: relative; z-index: 10; }
.stats-bar {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-radius: var(--radius-card);
    box-shadow: 0 20px 50px -12px rgba(99, 102, 241, 0.08);
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0;
    overflow: hidden;
    border: 1px solid rgba(99, 102, 241, 0.08);
}
.stat-item {
    text-align: center;
    padding: 36px 20px;
    border-right: 1px solid rgba(99, 102, 241, 0.08);
    border-bottom: 1px solid rgba(99, 102, 241, 0.08);
    transition: background var(--transition);
}
.stat-item:nth-child(2n) { border-right: none; }
.stat-item:nth-child(n+3) { border-bottom: none; }
.stat-item:hover { background: rgba(99, 102, 241, 0.02); }
.stat-num { font-size: var(--fs-2xl); font-weight: 800; color: var(--c-primary); line-height: 1; margin-bottom: 6px; }
.stat-label { color: var(--c-muted); font-size: var(--fs-sm); font-weight: 600; }

/* ── ABOUT / SEO BLOCK ── */
.about-section {
    background: #f8fafc;
    color: #0f172a;
    border-top: 1px solid rgba(99, 102, 241, 0.05);
    border-bottom: 1px solid rgba(99, 102, 241, 0.05);
}
.about-section .section-header h2 { color: #0f172a; }
.about-inner { max-width: 860px; margin: 0 auto; text-align: center; }
.about-inner p { font-size: var(--fs-md); line-height: 1.85; color: #334155; margin-bottom: 24px; }
.about-inner strong { color: var(--c-primary); font-weight: 700; }
.about-inner p:last-child { margin-bottom: 0; }

/* ── SERVICES ── */
.services-grid { display: grid; grid-template-columns: 1fr; gap: 32px; }
.service-card {
    background: var(--c-surface);
    border-radius: var(--radius-card);
    padding: 44px 36px;
    box-shadow: 0 10px 30px -10px rgba(99, 102, 241, 0.04);
    border: 1px solid rgba(99, 102, 241, 0.06);
    transition: all var(--transition);
    display: flex; flex-direction: column;
    position: relative; overflow: hidden;
}
.service-card::before {
    content: '';
    position: absolute; top: 0; left: 0; right: 0; height: 4px;
    background: linear-gradient(90deg, var(--c-primary), var(--c-accent));
    transform: scaleX(0); transform-origin: left;
    transition: transform var(--transition);
}
.service-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 24px 50px -12px rgba(99, 102, 241, 0.16);
    border-color: rgba(99, 102, 241, 0.12);
}
.service-card:hover::before { transform: scaleX(1); }
.svc-icon {
    width: 64px; height: 64px; border-radius: var(--r-md);
    background: rgba(99, 102, 241, 0.06); color: var(--c-primary);
    display: flex; align-items: center; justify-content: center;
    font-size: var(--fs-xl); margin-bottom: 24px;
    transition: all var(--transition);
}
.service-card:hover .svc-icon { background: var(--c-primary); color: #fff; transform: scale(1.06); }
.service-card h3 { font-size: var(--fs-lg); font-weight: 700; margin-bottom: 14px; }
.service-card p  { color: var(--c-muted); font-size: var(--fs-base); line-height: 1.7; flex-grow: 1; margin-bottom: 24px; }
.svc-link {
    display: inline-flex; align-items: center; gap: 7px;
    color: var(--c-primary); font-weight: 700; font-size: var(--fs-sm);
    margin-top: auto; transition: gap var(--transition);
}
.svc-link:hover { gap: 12px; }
.services-cta { text-align: center; margin-top: 52px; }

/* ── FAQ / WHY US ── */
.faq-section { background: rgba(99, 102, 241, 0.015); }
.faq-wrap { max-width: 780px; margin: 0 auto; }
.faq-item {
    background: var(--c-surface);
    border-radius: var(--r-md);
    margin-bottom: 14px;
    box-shadow: 0 10px 30px -10px rgba(99, 102, 241, 0.04);
    border: 1px solid rgba(99, 102, 241, 0.06);
    overflow: hidden;
    transition: all var(--transition);
}
.faq-item:focus-within { box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2); }
.faq-trigger {
    width: 100%;
    background: none; border: none; cursor: pointer;
    padding: 24px 28px;
    display: flex; justify-content: space-between; align-items: center; gap: 16px;
    text-align: left;
    font-family: inherit; font-size: var(--fs-md); font-weight: 700; color: var(--c-text);
    transition: color var(--transition);
}
.faq-trigger[aria-expanded="true"] { color: var(--c-primary); }
.faq-icon { color: var(--c-primary); margin-right: 10px; flex-shrink: 0; }
.faq-arrow { color: var(--c-muted); transition: transform var(--transition); flex-shrink: 0; }
.faq-trigger[aria-expanded="true"] .faq-arrow { transform: rotate(180deg); color: var(--c-primary); }
.faq-body {
    max-height: 0; overflow: hidden;
    transition: max-height 0.38s cubic-bezier(0.16, 1, 0.3, 1), padding 0.28s;
    padding: 0 28px;
    color: var(--c-muted); line-height: 1.8; font-size: var(--fs-base);
}
.faq-body.open { max-height: 600px; padding: 0 28px 24px; }

/* ── REVIEWS ── */
.reviews-grid { display: grid; grid-template-columns: 1fr; gap: 32px; }
.review-card {
    background: var(--c-surface);
    border-radius: var(--radius-card);
    padding: 40px;
    box-shadow: 0 10px 30px -10px rgba(99, 102, 241, 0.04);
    border: 1px solid rgba(99, 102, 241, 0.06);
    transition: all var(--transition);
    display: flex; flex-direction: column;
}
.review-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 20px 40px -12px rgba(99, 102, 241, 0.12);
    border-color: rgba(99, 102, 241, 0.12);
}
.stars { color: #F59E0B; font-size: var(--fs-md); letter-spacing: 4px; margin-bottom: 20px; }
.review-text { font-style: italic; line-height: 1.8; flex-grow: 1; margin-bottom: 28px; font-size: var(--fs-base); color: #334155; }
.review-text::before { content: '\201C'; }
.review-text::after  { content: '\201D'; }
.reviewer { display: flex; align-items: center; gap: 14px; }
.reviewer-avatar {
    width: 48px; height: 48px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    color: #fff; font-weight: 800; font-size: var(--fs-md); flex-shrink: 0;
}
.reviewer-name { font-weight: 700; font-size: var(--fs-base); margin-bottom: 3px; }
.reviewer-role { color: var(--c-muted); font-size: var(--fs-sm); }
.reviews-cta { text-align: center; margin-top: 52px; }

/* ── ANIMATIONS ── */
@keyframes float  { 0%,100% { transform: translateY(0);     } 50% { transform: translateY(-12px); } }
@keyframes pulse  { 0%,100% { opacity: 1; transform: scale(1);   } 50% { opacity: .6; transform: scale(0.85); } }
@keyframes fadeUp { from { opacity:0; transform:translateY(24px); } to { opacity:1; transform:translateY(0); } }

.reveal { opacity: 0; transform: translateY(24px); transition: opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1), transform 0.8s cubic-bezier(0.16, 1, 0.3, 1); }
.reveal.visible { opacity: 1; transform: translateY(0); }
.reveal-d1 { transition-delay: 0.06s; }
.reveal-d2 { transition-delay: 0.12s; }
.reveal-d3 { transition-delay: 0.18s; }
.reveal-d4 { transition-delay: 0.24s; }

/* ── RESPONSIVE ── */
@media (min-width: 640px) {
    .stats-bar { grid-template-columns: repeat(4, 1fr); }
    .stat-item { border-bottom: none; }
    .stat-item:nth-child(2n) { border-right: 1px solid rgba(99, 102, 241, 0.08); }
    .stat-item:last-child    { border-right: none; }
}
@media (min-width: 768px) {
    .hero-grid { grid-template-columns: 1.15fr 0.85fr; gap: 64px; }
    .services-grid { grid-template-columns: repeat(2, 1fr); }
    .reviews-grid  { grid-template-columns: repeat(3, 1fr); }
    .stats-section { padding: 0; }
}
@media (min-width: 1024px) {
    .services-grid { grid-template-columns: repeat(3, 1fr); }
}
</style>

<main id="main-content">

    <section class="hero" aria-label="Hero">
        <div class="container hero-grid">
            <div>
                <div class="hero-badge"><span></span> Top-Rated Digital Agency</div>
                <h1>From Local Brands to Digital Leaders — <span class="highlight">Pondicherry’s Growth Agency</span></h1>
                <p>We help businesses grow with result-driven digital marketing, SEO, targeted advertising, social media, and custom web development solutions designed to increase visibility, attract customers, and drive measurable growth.</p>
                <div class="hero-btns">
                    <a href="<?= $base_url ?>/contact" class="btn btn-primary"><i class="fas fa-rocket" aria-hidden="true"></i> Get Free Consultation</a>
                    <a href="<?= $base_url ?>/services" class="btn btn-ghost">View Services</a>
                </div>
            </div>
            <div class="hero-img-wrap reveal">
                <div class="mockup-header">
                    <span class="mockup-dot red"></span>
                    <span class="mockup-dot yellow"></span>
                    <span class="mockup-dot green"></span>
                    <span class="mockup-url">cloudaspire.in/dashboard</span>
                </div>
                <div class="mockup-body">
                    <img
                        src="<?= $base_url ?>/assets/images/hero-banner.png"
                        alt="Digital Marketing strategy dashboard showing SEO and analytics growth"
                        width="600" height="375"
                        loading="eager"
                        fetchpriority="high"
                        decoding="async"
                        onerror="this.style.display='none';"
                    >
                </div>
            </div>
        </div>
    </section>

    <div class="stats-section">
        <div class="container">
            <div class="stats-bar" role="list">
                <div class="stat-item reveal reveal-d1" role="listitem">
                    <div class="stat-num" aria-label="<?= htmlspecialchars($stat_projects) ?> plus"><?= htmlspecialchars($stat_projects) ?>+</div>
                    <div class="stat-label">Projects Completed</div>
                </div>
                <div class="stat-item reveal reveal-d2" role="listitem">
                    <div class="stat-num" aria-label="<?= htmlspecialchars($stat_clients) ?> plus"><?= htmlspecialchars($stat_clients) ?>+</div>
                    <div class="stat-label">Happy Clients</div>
                </div>
                <div class="stat-item reveal reveal-d3" role="listitem">
                    <div class="stat-num"><?= htmlspecialchars($stat_satisfaction) ?></div>
                    <div class="stat-label">Client Satisfaction</div>
                </div>
                <div class="stat-item reveal reveal-d4" role="listitem">
                    <div class="stat-num"><?= htmlspecialchars($stat_services) ?></div>
                    <div class="stat-label">Digital Solutions</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Small Businesses & Startups Logo Cloud Section -->
    <section class="logo-cloud-section reveal" aria-label="Small businesses and local brands trusted by us">
        <div class="container">
            <p class="logo-cloud-title">POWERING PONDICHERRY’S FAST-GROWING BRANDS & STARTUPS</p>
        </div>
        <div class="logo-ticker-wrap">
            <div class="logo-ticker-track">
                <!-- Group 1 -->
                <div class="logo-item"><i class="fas fa-mug-hot"></i> White Town Cafes</div>
                <div class="logo-item"><i class="fas fa-store"></i> Heritage Boutiques</div>
                <div class="logo-item"><i class="fas fa-umbrella-beach"></i> Beach Road Resorts</div>
                <div class="logo-item"><i class="fas fa-leaf"></i> Auroville Organics</div>
                <div class="logo-item"><i class="fas fa-user-md"></i> Puducherry Clinics</div>
                <div class="logo-item"><i class="fas fa-shirt"></i> Pondy Handlooms</div>
                <div class="logo-item"><i class="fas fa-city"></i> Coastal Real Estate</div>
                <div class="logo-item"><i class="fas fa-graduation-cap"></i> Local Academies</div>
                <div class="logo-item"><i class="fas fa-bread-slice"></i> French Bakeries</div>
                <div class="logo-item"><i class="fab fa-google"></i> Google Local Maps</div>
                <div class="logo-item"><i class="fab fa-whatsapp"></i> WhatsApp Business</div>
                <div class="logo-item"><i class="fab fa-instagram"></i> Pondy D2C Brands</div>

                <!-- Group 2 (Duplicated for seamless infinite marquee loop) -->
                <div class="logo-item"><i class="fas fa-mug-hot"></i> White Town Cafes</div>
                <div class="logo-item"><i class="fas fa-store"></i> Heritage Boutiques</div>
                <div class="logo-item"><i class="fas fa-umbrella-beach"></i> Beach Road Resorts</div>
                <div class="logo-item"><i class="fas fa-leaf"></i> Auroville Organics</div>
                <div class="logo-item"><i class="fas fa-user-md"></i> Puducherry Clinics</div>
                <div class="logo-item"><i class="fas fa-shirt"></i> Pondy Handlooms</div>
                <div class="logo-item"><i class="fas fa-city"></i> Coastal Real Estate</div>
                <div class="logo-item"><i class="fas fa-graduation-cap"></i> Local Academies</div>
                <div class="logo-item"><i class="fas fa-bread-slice"></i> French Bakeries</div>
                <div class="logo-item"><i class="fab fa-google"></i> Google Local Maps</div>
                <div class="logo-item"><i class="fab fa-whatsapp"></i> WhatsApp Business</div>
                <div class="logo-item"><i class="fab fa-instagram"></i> Pondy D2C Brands</div>
            </div>
        </div>
    </section>

    <section class="section about-section" aria-labelledby="about-heading">
        <div class="container">
            <div class="section-header reveal">
                <h2 id="about-heading">Your Trusted Partner for <span class="highlight">Explosive Online Growth</span></h2>
            </div>
            <article class="about-inner reveal">
                <p>As a leading <strong>digital marketing agency in Pondicherry</strong>, <?= htmlspecialchars($site_name) ?> drives measurable growth through data-driven <strong>SEO</strong>, high-converting <strong>Google & Meta ads (PPC)</strong>, strategic <strong>social media marketing</strong>, and custom <strong>web development</strong>. We optimize your online presence to dominate search rankings, capture targeted leads, and maximize ROI.</p>
            </article>
        </div>
    </section>

    <?php if (!empty($services)): ?>
    <section class="section" id="services" aria-labelledby="services-heading">
        <div class="container">
            <div class="section-header reveal">
                <h2 id="services-heading">Core <span class="highlight">Marketing Services</span></h2>
                <p>Data-driven digital solutions designed to scale your business and increase your online visibility.</p>
            </div>
            <div class="services-grid">
                <?php foreach ($services as $i => $s): 
                    $delay_class = 'reveal-d' . (($i % 4) + 1);
                ?>
                <article class="service-card reveal <?= $delay_class ?>">
                    <div class="svc-icon" aria-hidden="true">
                        <i class="fas <?= htmlspecialchars(!empty($s['icon']) ? $s['icon'] : 'fa-briefcase') ?>"></i>
                    </div>
                    <h3><?= htmlspecialchars($s['service_name']) ?></h3>
                    <p><?= htmlspecialchars($s['short_description']) ?></p>
                    <a href="<?= $base_url ?>/services" class="svc-link" aria-label="Explore <?= htmlspecialchars($s['service_name']) ?>">
                        Read More <i class="fas fa-arrow-right" aria-hidden="true"></i>
                    </a>
                </article>
                <?php endforeach; ?>
            </div>
            
            <div class="services-cta reveal">
                <a href="<?= $base_url ?>/services" class="btn btn-ghost">
                    View All Services <i class="fas fa-arrow-right" aria-hidden="true"></i>
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($faq_items)): ?>
    <section class="section faq-section" id="why-us" aria-labelledby="faq-heading">
        <div class="container">
            <div class="section-header reveal">
                <h2 id="faq-heading">Why Partner With <span class="highlight"><?= htmlspecialchars($site_name) ?></span>?</h2>
                <p>We are committed to delivering transparent, measurable results for every brand we work with.</p>
            </div>
            <div class="faq-wrap" role="list">
                <?php foreach ($faq_items as $k => $f):
                    $is_open   = ($k === 0);
                    $item_id   = 'faq-body-' . $k;
                ?>
                <div class="faq-item reveal" role="listitem">
                    <button
                        class="faq-trigger"
                        aria-expanded="<?= $is_open ? 'true' : 'false' ?>"
                        aria-controls="<?= $item_id ?>"
                        onclick="toggleFaq(this)"
                    >
                        <span>
                            <i class="fas <?= htmlspecialchars(!empty($f['icon']) ? $f['icon'] : 'fa-check-circle') ?> faq-icon" aria-hidden="true"></i>
                            <?= htmlspecialchars($f['question']) ?>
                        </span>
                        <i class="fas fa-chevron-down faq-arrow" aria-hidden="true"></i>
                    </button>
                    <div id="<?= $item_id ?>" class="faq-body <?= $is_open ? 'open' : '' ?>" role="region">
                        <p><?= nl2br(htmlspecialchars($f['answer'])) ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($reviews)): ?>
    <section class="section" id="reviews" aria-labelledby="reviews-heading">
        <div class="container">
            <div class="section-header reveal">
                <h2 id="reviews-heading">Client <span class="highlight">Success Stories</span></h2>
                <p>Don't just take our word for it — hear from the businesses we've helped grow online.</p>
            </div>

            <div class="reviews-grid" itemscope itemtype="https://schema.org/Organization">
                <?php
                // Avatar gradient palette
                $gradients = [
                    'linear-gradient(135deg, #5B35E8, #8B5CF6)',
                    'linear-gradient(135deg, #F59E0B, #EA580C)',
                    'linear-gradient(135deg, #10B981, #059669)',
                ];
                foreach ($reviews as $k => $r):
                    $rating     = min(5, max(1, (int)($r['star_rating'] ?? 5)));
                    $delay_cls  = 'reveal-d' . (($k % 3) + 1);
                    $initials   = strtoupper(substr(trim($r['name'] ?? '?'), 0, 1));
                ?>
                <article
                    class="review-card reveal <?= $delay_cls ?>"
                    itemprop="review" itemscope itemtype="https://schema.org/Review"
                >
                    <div class="stars" aria-label="<?= $rating ?> out of 5 stars">
                        <?= str_repeat('★', $rating) . str_repeat('☆', 5 - $rating) ?>
                    </div>
                    <p class="review-text" itemprop="reviewBody"><?= htmlspecialchars($r['message']) ?></p>
                    <div class="reviewer" itemprop="author" itemscope itemtype="https://schema.org/Person">
                        <div class="reviewer-avatar" style="background: <?= $gradients[$k % 3] ?>;" aria-hidden="true">
                            <?= $initials ?>
                        </div>
                        <div>
                            <div class="reviewer-name" itemprop="name"><?= htmlspecialchars($r['name']) ?></div>
                            <div class="reviewer-role">
                                <?= !empty($r['designation']) ? htmlspecialchars($r['designation']) : 'Verified Client' ?>
                            </div>
                        </div>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>

            <div class="reviews-cta reveal" style="display: flex; justify-content: center; gap: 16px; flex-wrap: wrap;">
                <a href="<?= $base_url ?>/reviews" class="btn btn-ghost">
                    View All Reviews <i class="fas fa-arrow-right" aria-hidden="true"></i>
                </a>
                <a href="<?= $base_url ?>/reviews#write-review" class="btn btn-primary">
                    <i class="fas fa-star" aria-hidden="true"></i> Write a Review
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>

</main>

<script>
/* ─────────────────────────────────────────────
   FAQ Accordion 
───────────────────────────────────────────── */
function toggleFaq(btn) {
    const expanded = btn.getAttribute('aria-expanded') === 'true';
    const bodyId   = btn.getAttribute('aria-controls');
    const body     = document.getElementById(bodyId);

    // Collapse all first
    document.querySelectorAll('.faq-trigger').forEach(function(b) {
        b.setAttribute('aria-expanded', 'false');
        var bId = b.getAttribute('aria-controls');
        if (bId) document.getElementById(bId)?.classList.remove('open');
    });

    // Open clicked 
    if (!expanded) {
        btn.setAttribute('aria-expanded', 'true');
        body?.classList.add('open');
    }
}

/* ─────────────────────────────────────────────
   Scroll-based staggered reveal & Stats Counter
───────────────────────────────────────────── */
(function () {
    // Scroll reveal observer
    var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.reveal').forEach(function (el) {
        observer.observe(el);
    });

    // Animated count-up numbers for stats
    var statsObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                var numEl = entry.target.querySelector('.stat-num');
                if (numEl && !numEl.dataset.counted) {
                    numEl.dataset.counted = 'true';
                    var text = numEl.textContent.trim();
                    var match = text.match(/^(\d+)(.*)$/);
                    if (match) {
                        var targetNum = parseInt(match[1], 10);
                        var suffix = match[2] || '';
                        var duration = 1600;
                        var startTime = null;

                        function step(timestamp) {
                            if (!startTime) startTime = timestamp;
                            var progress = Math.min((timestamp - startTime) / duration, 1);
                            var easeProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
                            var currentNum = Math.floor(easeProgress * targetNum);
                            numEl.textContent = currentNum + suffix;
                            if (progress < 1) {
                                requestAnimationFrame(step);
                            } else {
                                numEl.textContent = targetNum + suffix;
                            }
                        }
                        requestAnimationFrame(step);
                    }
                }
                statsObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });

    document.querySelectorAll('.stat-item').forEach(function (el) {
        statsObserver.observe(el);
    });
})();
</script>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>