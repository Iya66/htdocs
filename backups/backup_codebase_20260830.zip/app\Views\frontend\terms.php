<?php include __DIR__ . '/../../../includes/header.php'; ?>
<?php
$policy_content = $settings['terms_conditions'] ?? '';
$site_name = $site_name ?? 'Cloud Aspire';
$contact_email = $contact_email ?? 'tamilaninstamedia1@gmail.com';

if (empty($policy_content)) {
    $policy_content = <<<EOT
<h2>1. Acceptance of Terms</h2>
<p>By browsing, accessing, or engaging services through {$site_name}, you agree to adhere to these Terms & Conditions, all applicable laws, and relevant industry regulations.</p>

<h2>2. Service Engagement & Deliverables</h2>
<p>All digital marketing, SEO, paid advertising, and web development deliverables are executed according to predefined project proposals and milestone agreements agreed upon between the client and {$site_name}.</p>

<h2>3. Intellectual Property Rights</h2>
<p>Upon full settlement of agreed project dues, all bespoke creative assets, website source codes, and campaign configurations developed specifically for the client become the proprietary property of the client.</p>

<h2>4. Client Responsibilities</h2>
<p>Clients are expected to provide timely feedback, necessary brand assets, and required account access to maintain agreed project schedules and campaign launch dates.</p>

<h2>5. Limitation of Liability</h2>
<p>While {$site_name} employs best-in-class industry methodologies, we do not guarantee third-party platform algorithm behaviors (e.g., search engine indexing timelines or ad platform policy updates) beyond direct control.</p>

<h2>6. Inquiries & Legal Notices</h2>
<p>For questions regarding our terms of service, contact our legal desk at <a href="mailto:{$contact_email}" style="color:var(--primary); font-weight:600;">{$contact_email}</a>.</p>
EOT;
}
?>

<style>
    .legal-card-wrap {
        max-width: 900px;
        margin: 0 auto;
        background: #FFFFFF;
        border: 1px solid var(--border-light);
        border-radius: var(--r-lg);
        padding: 50px 48px;
        box-shadow: var(--shadow-sm);
        line-height: 1.85;
    }

    .legal-card-wrap h2 {
        font-size: 1.35rem;
        font-weight: 700;
        color: var(--text);
        margin: 32px 0 12px;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }

    .legal-card-wrap h2:first-of-type {
        margin-top: 0;
    }

    .legal-card-wrap p, .legal-card-wrap li {
        color: var(--text2);
        font-size: 0.98rem;
        margin-bottom: 14px;
    }

    .legal-badge-bar {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: rgba(108, 59, 255, 0.06);
        border: 1px solid rgba(108, 59, 255, 0.14);
        padding: 6px 16px;
        border-radius: var(--r-pill);
        font-size: 0.82rem;
        font-weight: 600;
        color: var(--primary);
        margin-top: 14px;
    }

    @media (max-width: 768px) {
        .legal-card-wrap {
            padding: 32px 20px;
        }
    }
</style>

<section class="page-header">
    <div class="container">
        <h1>Terms & <span class="highlight">Conditions</span></h1>
        <p>Standard agreement, service deliverables, and guidelines for client engagements</p>
        <div class="legal-badge-bar">
            <i class="fas fa-file-contract"></i> Last Updated: <?= date('F j, Y'); ?>
        </div>
    </div>
</section>

<section class="section" style="padding-top: 50px; background: #F8FAFC;">
    <div class="container">
        <div class="legal-card-wrap fade-in">
            <?= $policy_content ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>
