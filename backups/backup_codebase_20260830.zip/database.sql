-- ===============================================================
-- CloudASPIRE Enterprise Production Database Dump
-- Exported on: 2026-08-30 11:00:57
-- Target Server: MySQL 5.7+ / MariaDB 10.3+
-- Default Collation: utf8mb4_unicode_ci
-- ===============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- ---------------------------------------------------------------
-- 1. Table structure for `accounts` -------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `wa_number` varchar(20) DEFAULT NULL,
  `avatar` varchar(500) DEFAULT NULL,
  `role` enum('admin','manager','user','viewer') DEFAULT 'user',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `google_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- 2. Table structure for `admin` ----------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `wa_number` varchar(20) DEFAULT NULL,
  `avatar` varchar(500) DEFAULT NULL,
  `role` varchar(50) DEFAULT 'admin',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `google_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `admin`
INSERT IGNORE INTO `admin` (`id`, `name`, `username`, `email`, `password`, `wa_number`, `avatar`, `role`, `is_active`, `last_login`, `google_id`, `created_at`, `updated_at`) VALUES
('1', 'cloudaspire', 'cloudaspire', 'cloudaspire2026@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '', '', 'admin', '1', NULL, NULL, '2026-07-05 06:53:50', '2026-07-29 15:38:33'),
('2', 'kutty', 'kutty', 'rkeditor03@gmail.com', '$2y$12$ZI8OPDgnMrwGZk5sK751yOfzk0VdzoLKuIw1SdQaEKtN4//WuiFTa', NULL, NULL, 'admin', '1', NULL, NULL, '2026-07-06 07:07:17', '2026-07-06 07:07:17');

-- ---------------------------------------------------------------
-- 3. Table structure for `registered_emails` ----------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `registered_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `role` enum('admin','manager','user','viewer') DEFAULT 'user',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- 4. Table structure for `modules` --------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_key` varchar(50) NOT NULL,
  `module_name` varchar(100) NOT NULL,
  `module_type` varchar(50) DEFAULT 'standard',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_key` (`module_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `modules`
INSERT IGNORE INTO `modules` (`id`, `module_key`, `module_name`, `module_type`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
('1', 'google_login', 'Google Login', 'oauth', 'Enable Google OAuth login for admin portal', '0', '2026-07-05 02:05:17', '2026-07-05 02:05:17'),
('2', 'email_notifications', 'Email Notifications', 'standard', 'Send email notifications for important events', '1', '2026-07-05 02:05:17', '2026-07-05 02:05:17'),
('3', 'whatsapp_integration', 'WhatsApp Integration', 'api', 'WhatsApp messaging integration', '1', '2026-07-05 02:05:17', '2026-07-05 02:05:17');

-- ---------------------------------------------------------------
-- 5. Table structure for `settings` -------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `settings`
INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'Cloud Aspire'),
('site_favicon', 'uploads/site_favicon_1783239900.png'),
('site_logo', 'uploads/site_logo_1783239874.png'),
('contact_email', 'cloudaspire2025@gmail.com'),
('contact_phone', '8098830937'),
('contact_whatsapp', '8098830937'),
('contact_hours', 'Mon - Sat: 9:00 AM - 7:00 PM'),
('contact_map_iframe', '<iframe src=\"https://maps.google.com/maps?q=No%2053%20Auvai%20Nagar&t=&z=13&ie=UTF8&iwloc=&output=embed\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>'),
('admin_onboarded', '1'),
('mail_admin_email', 'cloudaspire2026@gmail.com'),
('mail_smtp_email', 'noreply@cloudaspire.in'),
('mail_smtp_server', 'portel.cloudaspire.in'),
('mail_smtp_port', '587'),
('mail_smtp_protocol', 'tls'),
('mail_from_name', 'Cloud Aspire'),
('mail_force_ipv4', '0'),
('mail_smtp_password', 'cloudaspire@2026'),
('social_facebook_url', ''),
('social_facebook_enabled', '0'),
('social_instagram_url', 'https://www.instagram.com/cloudaspire.in/'),
('social_instagram_enabled', '1'),
('social_twitter_url', ''),
('social_twitter_enabled', '0'),
('social_linkedin_url', ''),
('social_linkedin_enabled', '0'),
('social_youtube_url', ''),
('social_youtube_enabled', '0'),
('social_whatsapp_url', ''),
('social_whatsapp_enabled', '0'),
('social_telegram_url', ''),
('social_telegram_enabled', '0'),
('social_discord_url', ''),
('social_discord_enabled', '0'),
('social_tiktok_url', ''),
('social_tiktok_enabled', '0'),
('social_github_url', ''),
('social_github_enabled', '0'),
('social_facebook', 'https://facebook.com'),
('social_instagram', 'https://www.instagram.com/cloudaspire.in/'),
('social_twitter', 'https://twitter.com'),
('social_linkedin', 'hhttps://www.linkedin.com/in/cloud-aspire-3819b43a3?utm_source=share_via&utm_content=profile&utm_medium=member_ios'),
('theme_primary', '#5b6ef5'),
('theme_accent', '#7c5cfc'),
('theme_sidebar_bg', '#1e1e2e'),
('theme_sidebar_text', '#b8b8d0'),
('theme_bg_primary', '#0f0f1a'),
('theme_btn_radius', '10px'),
('theme_card_radius', '16px'),
('theme_font', 'fiolex'),
('privacy_policy', '<h2>1. Information We Collect</h2><p>At Cloud Aspire, we collect information you provide directly to us, such as your name, email address, phone number, and business details when you fill out contact forms, request proposals, subscribe to updates, or engage our services.</p><h2>2. How We Use Your Information</h2><p>We use the data we collect for purposeful and transparent business operations:</p><ul><li>To deliver, execute, and monitor our digital marketing and web development services</li><li>To communicate critical project milestones, campaign performance, and strategy updates</li><li>To enhance website responsiveness, security, and customer experience</li><li>To adhere strictly to applicable statutory and legal frameworks</li></ul><h2>3. Information Sharing & Third Parties</h2><p>We strictly do not sell, trade, or monetize your personal or commercial data. We only share essential metadata with vetted infrastructure providers who are bound by non-disclosure agreements.</p><h2>4. Data Security</h2><p>We employ enterprise-grade security protocols, encryption in transit (SSL/TLS), access controls, and regular vulnerability assessments to safeguard your data against unauthorized access or breaches.</p><h2>5. Cookies & Tracking Technologies</h2><p>Our website utilizes necessary cookies and privacy-respecting analytics to optimize user navigation and performance.</p><h2>6. Your Data Rights</h2><p>You have the right to access, verify, export, or request deletion of your personal records. For inquiries, please reach out to our privacy compliance team at <a href=\"mailto:cloudaspire2025@gmail.com\">cloudaspire2025@gmail.com</a>.</p><h2>7. Policy Updates</h2><p>We may update this Privacy Policy periodically to reflect evolving legal standards. Changes will be posted on this page with an updated timestamp.</p>'),
('terms_conditions', '<h2>1. Acceptance of Terms</h2><p>By browsing, accessing, or engaging services through Cloud Aspire, you agree to adhere to these Terms & Conditions, all applicable laws, and relevant industry regulations.</p><h2>2. Service Engagement & Deliverables</h2><p>All digital marketing, SEO, paid advertising, and web development deliverables are executed according to predefined project proposals and milestone agreements agreed upon between the client and Cloud Aspire.</p><h2>3. Intellectual Property Rights</h2><p>Upon full settlement of agreed project dues, all bespoke creative assets, website source codes, and campaign configurations developed specifically for the client become the proprietary property of the client.</p><h2>4. Client Responsibilities</h2><p>Clients are expected to provide timely feedback, necessary brand assets, and required account access to maintain agreed project schedules and campaign launch dates.</p><h2>5. Limitation of Liability</h2><p>While Cloud Aspire employs best-in-class industry methodologies, we do not guarantee third-party platform algorithm behaviors beyond direct control.</p><h2>6. Inquiries & Legal Notices</h2><p>For questions regarding our terms of service, contact our legal desk at <a href=\"mailto:cloudaspire2025@gmail.com\">cloudaspire2025@gmail.com</a>.</p>'),
('refund_policy', '<h2>1. Satisfaction Commitment</h2><p>At Cloud Aspire, we are committed to providing top-tier digital marketing, SEO, and development solutions. We work closely with every client at every milestone to ensure our deliverables match expectations.</p><h2>2. Refund Eligibility & Window</h2><p>If you are dissatisfied with a standard subscription plan or service kickoff, you may submit a formal review request within 14 calendar days of onboarding.</p><h2>3. Excluded & Non-Refundable Services</h2><p>The following costs represent direct third-party or completed disbursements and are non-refundable:</p><ul><li>Third-party platform advertising spend paid directly to Google, Meta, or LinkedIn</li><li>Domain registration, dedicated server provisioning, or third-party API license fees</li><li>Custom design or development phases that have already been reviewed, approved, and delivered</li></ul><h2>4. Refund Request Process</h2><p>To request a billing review or dispute resolution, please email our finance desk at <a href=\"mailto:cloudaspire2025@gmail.com\">cloudaspire2025@gmail.com</a> with your invoice number and project details.</p>'),
('services_seeded', '1'),
('schema_version', '2026.08.30');

-- ---------------------------------------------------------------
-- 6. Table structure for `uploads` --------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_size` int(11) NOT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT current_timestamp(),
  `folder` varchar(50) DEFAULT 'general',
  `file_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `uploads`
INSERT IGNORE INTO `uploads` (`id`, `file_name`, `file_path`, `file_type`, `file_size`, `uploaded_by`, `uploaded_at`, `folder`, `file_title`) VALUES
('1', 'site_logo_1783239874.png', 'uploads/site_logo_1783239874.png', 'site_logo', '138061', NULL, '2026-07-05 13:54:34', 'general', NULL),
('2', 'site_favicon_1783239900.png', 'uploads/site_favicon_1783239900.png', 'site_favicon', '441736', NULL, '2026-07-05 13:55:00', 'general', NULL),
('3', 'site_favicon_1780257407.png', 'uploads/site_favicon_1780257407.png', 'image/jpeg', '40279', NULL, '2026-08-30 00:53:51', 'general', 'Site Favicon 1780257407'),
('4', 'site_logo_1780288068.png', 'uploads/site_logo_1780288068.png', 'image/png', '138061', NULL, '2026-08-30 00:53:51', 'general', 'Site Logo 1780288068'),
('5', 'ananya-sharma.jpg', 'assets/images/testimonials/ananya-sharma.jpg', 'image/jpeg', '707824', NULL, '2026-08-30 00:53:51', 'testimonials', 'Ananya Sharma'),
('6', 'moment-award.jpg', 'assets/images/testimonials/moment-award.jpg', 'image/jpeg', '853507', NULL, '2026-08-30 00:53:51', 'testimonials', 'Moment Award'),
('7', 'moment-launch.jpg', 'assets/images/testimonials/moment-launch.jpg', 'image/jpeg', '775741', NULL, '2026-08-30 00:53:51', 'testimonials', 'Moment Launch'),
('8', 'moment-review.jpg', 'assets/images/testimonials/moment-review.jpg', 'image/jpeg', '758570', NULL, '2026-08-30 00:53:51', 'testimonials', 'Moment Review'),
('9', 'moment-strategy.jpg', 'assets/images/testimonials/moment-strategy.jpg', 'image/jpeg', '872398', NULL, '2026-08-30 00:53:51', 'testimonials', 'Moment Strategy'),
('10', 'sarah-jenkins.jpg', 'assets/images/testimonials/sarah-jenkins.jpg', 'image/jpeg', '759244', NULL, '2026-08-30 00:53:51', 'testimonials', 'Sarah Jenkins'),
('11', 'vigneshwaran-m.jpg', 'assets/images/testimonials/vigneshwaran-m.jpg', 'image/jpeg', '714656', NULL, '2026-08-30 00:53:51', 'testimonials', 'Vigneshwaran M'),
('12', 'ads_fashion.png', 'assets/images/projects/ads_fashion.png', 'image/jpeg', '902259', NULL, '2026-08-30 00:53:51', 'projects', 'Ads Fashion'),
('13', 'ads_real_estate.png', 'assets/images/projects/ads_real_estate.png', 'image/jpeg', '695029', NULL, '2026-08-30 00:53:51', 'projects', 'Ads Real Estate'),
('14', 'seo_ecommerce.png', 'assets/images/projects/seo_ecommerce.png', 'image/jpeg', '814579', NULL, '2026-08-30 00:53:51', 'projects', 'Seo Ecommerce'),
('15', 'seo_healthcare.png', 'assets/images/projects/seo_healthcare.png', 'image/jpeg', '801420', NULL, '2026-08-30 00:53:51', 'projects', 'Seo Healthcare'),
('16', 'social_restaurant.png', 'assets/images/projects/social_restaurant.png', 'image/jpeg', '704019', NULL, '2026-08-30 00:53:51', 'projects', 'Social Restaurant'),
('17', 'web_saas.png', 'assets/images/projects/web_saas.png', 'image/jpeg', '672694', NULL, '2026-08-30 00:53:51', 'projects', 'Web Saas'),
('18', 'service_demo_seo.png', 'uploads/services/service_demo_seo.png', 'image/png', '2802', NULL, '2026-08-30 00:54:08', 'services', 'SEO & Growth Marketing Banner'),
('19', 'media_1788031607_7e43d0.png', 'uploads/general/media_1788031607_7e43d0.png', 'image/png', '1669987', '1', '2026-08-30 00:56:47', 'general', 'ChatGPT Image Jul 27  2026  08 55 45 AM');

-- ---------------------------------------------------------------
-- 7. Table structure for `services` -------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `short_description` text DEFAULT NULL,
  `full_description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `services`
INSERT IGNORE INTO `services` (`id`, `service_name`, `slug`, `short_description`, `full_description`, `icon`, `image`, `price`, `status`, `created_at`, `updated_at`) VALUES
('1', 'SEO Optimization', 'seo-optimization', 'Dominate search rankings, drive targeted organic traffic, and outrank competitors with proven data-driven SEO strategies.', 'Comprehensive SEO including technical site audits, on-page optimization, high-authority backlink outreach, keyword research, and rank tracking.', 'fa-search', 'https://images.unsplash.com/photo-1571721795195-a2ca2d3370a9?auto=format&fit=crop&w=800&q=80', '₹4,999/mo', 'active', '2026-08-29 12:42:35', '2026-08-29 12:42:35'),
('2', 'Google & Meta Ads', 'google-meta-ads', 'Maximize ROI with high-converting paid ad campaigns across Google Search, Display, YouTube, Instagram, and Facebook.', 'Targeted PPC advertising, dynamic retargeting, conversion rate optimization, lower cost-per-acquisition, and transparent analytics.', 'fa-bullhorn', 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80', '₹7,999/mo', 'active', '2026-08-29 12:42:35', '2026-08-29 12:42:35'),
('3', 'Social Media Marketing', 'social-media-marketing', 'Build brand authority, engage your audience, and scale follower growth across Instagram, LinkedIn, and Facebook.', 'Creative content creation, Reels/Shorts production, active community management, influencer partnerships, and growth campaigns.', 'fa-share-alt', 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=800&q=80', '₹5,999/mo', 'active', '2026-08-29 12:42:35', '2026-08-29 12:42:35'),
('4', 'Website & App Development', 'website-app-development', 'Ultra-fast, mobile-responsive custom websites and web applications built to turn visitors into paying customers.', 'Custom PHP/JavaScript/HTML5 web development, e-commerce portals, web applications, landing pages, and cloud hosting setup.', 'fa-code', 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80', '₹9,999', 'active', '2026-08-29 12:42:35', '2026-08-29 12:42:35'),
('5', 'Brand Identity & Design', 'brand-identity-design', 'Establish a memorable brand identity with professional logos, graphic design, and cohesive visual branding.', 'Comprehensive branding kits: logo packages, typography, color palettes, vector assets, stationery, and digital UI/UX assets.', 'fa-paint-brush', 'https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=800&q=80', '₹3,999', 'active', '2026-08-29 12:42:35', '2026-08-29 12:42:35'),
('6', 'Content Marketing & Copywriting', 'content-marketing', 'Compelling storytelling and conversion copywriting that captivates your audience and drives organic engagement.', 'SEO-optimized blog writing, landing page copywriting, email newsletters, whitepapers, and high-converting sales funnels.', 'fa-pen-fancy', 'https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=800&q=80', '₹3,499/mo', 'active', '2026-08-29 12:42:35', '2026-08-29 12:42:35');

-- ---------------------------------------------------------------
-- 8. Table structure for `plans` ----------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_name` varchar(150) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `duration` varchar(50) DEFAULT 'monthly',
  `features` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_popular` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `delivery_time` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `plans`
INSERT IGNORE INTO `plans` (`id`, `plan_name`, `category`, `price`, `duration`, `features`, `status`, `created_at`, `updated_at`, `is_popular`, `sort_order`, `delivery_time`) VALUES
('1', 'Starter Growth', NULL, '9999.00', 'monthly', 'Local SEO & Google Maps Optimization\nSocial Media Management (8 posts/mo)\nGoogle Search Ads Setup\nMonthly Performance Report\nEmail & WhatsApp Support', 'active', '2026-08-29 12:57:23', '2026-08-29 12:57:23', '0', '0', NULL),
('2', 'Scale & Dominate', NULL, '19999.00', 'monthly', 'Full Technical & On-Page SEO\nGoogle Ads & Meta Ads Management\nConversion Rate Optimization (CRO)\nSocial Media Growth (16 posts + Reels)\nDedicated Account Strategist\nBi-Weekly Strategy Calls', 'active', '2026-08-29 12:57:23', '2026-08-29 12:57:23', '1', '0', NULL),
('3', 'Enterprise Custom', NULL, '39999.00', 'monthly', 'Omnichannel Performance Marketing\nCustom High-Speed Web Development\nCRM & Lead Automation Pipeline\nAdvanced Data & ROI Attribution\n24/7 Priority Support & SLA\nWeekly Strategy Alignment', 'active', '2026-08-29 12:57:23', '2026-08-29 12:57:23', '0', '0', NULL);

-- ---------------------------------------------------------------
-- 9. Table structure for `projects` -------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(255) NOT NULL,
  `budget` varchar(50) DEFAULT NULL,
  `project_datetime` datetime DEFAULT NULL,
  `status` enum('pending','running','completed','cancelled') DEFAULT 'pending',
  `project_link` varchar(500) DEFAULT NULL,
  `thumbnail` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `category` varchar(100) DEFAULT 'web',
  `industry` varchar(100) DEFAULT 'Digital',
  `description` text DEFAULT NULL,
  `client_name` varchar(150) DEFAULT NULL,
  `results` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_projects_status_date` (`status`,`project_datetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `projects`
INSERT IGNORE INTO `projects` (`id`, `project_name`, `budget`, `project_datetime`, `status`, `project_link`, `thumbnail`, `created_at`, `updated_at`, `category`, `industry`, `description`, `client_name`, `results`) VALUES
('24', 'Auroville Organic Retail Scale', NULL, NULL, 'completed', NULL, NULL, '2026-08-29 12:57:01', '2026-08-29 12:57:01', 'seo', 'E-Commerce', 'Engineered a scalable organic search engine optimization strategy that grew non-brand organic search traffic by 340% in 6 months.', 'Auroville Organics', '+340% Organic Traffic'),
('25', 'Heritage Boutique Villa Lead Engine', NULL, NULL, 'completed', NULL, NULL, '2026-08-29 12:57:01', '2026-08-29 12:57:01', 'ads', 'Hospitality', 'Implemented high-converting Meta Ads and Google Search campaigns targeting high-net-worth travelers, decreasing cost per lead by 52%.', 'White Town Heritage', '5.4x ROAS on Paid Ads'),
('26', 'Coastal Realty Premium Portal', NULL, NULL, 'completed', NULL, NULL, '2026-08-29 12:57:01', '2026-08-29 12:57:01', 'web', 'Real Estate', 'Designed and developed a lightning-fast real estate listing portal with integrated WhatsApp lead capture and CRM pipeline automation.', 'Pondy Coastal Properties', '850+ Verified Buyer Inquiries'),
('27', 'D2C Sustainable Fashion Launch', NULL, NULL, 'completed', NULL, NULL, '2026-08-29 12:57:01', '2026-08-29 12:57:01', 'social', 'Fashion & D2C', 'Executed viral influencer collaborations and micro-targeted Instagram reels campaigns, generating 12,000+ purchases in Q4.', 'Pondy Handloom Co.', '₹45L+ Revenue Generated');

-- ---------------------------------------------------------------
-- 10. Table structure for `testimonials` --------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `designation` varchar(150) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `testimonials`
INSERT IGNORE INTO `testimonials` (`id`, `name`, `designation`, `message`, `image`, `status`, `created_at`, `updated_at`) VALUES
('1', 'Ananya Sharma', 'Head of Marketing, D2C Apparel', 'Partnering with Cloud Aspire has been a game-changer for our customer acquisition strategy. Highly recommended!', 'assets/images/testimonials/ananya-sharma.jpg', 'active', '2026-08-29 12:57:01', '2026-08-29 18:07:59'),
('2', 'Vigneshwaran M.', 'Director, Coastal Real Estate', 'Their lead generation campaigns delivered high-intent buyers with zero wasted budget. Professional, responsive, and innovative.', 'assets/images/testimonials/vigneshwaran-m.jpg', 'active', '2026-08-29 12:57:01', '2026-08-29 18:07:59'),
('3', 'Sarah Jenkins', 'Co-Founder, Heritage Boutique Resorts', 'From brand strategy to paid performance, they transformed our online visibility and bookings across South India.', 'assets/images/testimonials/sarah-jenkins.jpg', 'active', '2026-08-29 12:57:01', '2026-08-29 18:07:59');

-- ---------------------------------------------------------------
-- 11. Table structure for `reviews` -------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `star_rating` tinyint(1) DEFAULT 5,
  `message` text DEFAULT NULL,
  `rating` varchar(50) DEFAULT NULL,
  `review_text` text DEFAULT NULL,
  `designation` varchar(150) DEFAULT NULL,
  `company` varchar(150) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'approved',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_reviews_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `reviews`
INSERT IGNORE INTO `reviews` (`id`, `name`, `star_rating`, `message`, `rating`, `review_text`, `designation`, `company`, `status`, `created_at`, `updated_at`) VALUES
('6', 'Rajesh Kumar', '5', 'Cloud Aspire helped us scale our e-commerce sales by over 240% within 4 months. Their data-driven approach and transparent reporting are unmatched.', NULL, NULL, 'Founder & CEO', 'Pondy Crafts Co.', 'approved', '2026-08-29 12:57:01', '2026-08-29 12:57:01'),
('7', 'Dr. Meera Swaminathan', '5', 'Our local clinic patient inquiries tripled after Cloud Aspire overhauled our local SEO and Google Maps optimization. Exceptional service!', NULL, NULL, 'Medical Director', 'Auroville Wellness', 'approved', '2026-08-29 12:57:01', '2026-08-29 12:57:01'),
('8', 'Alexandre Dubois', '5', 'The return on ad spend from their Meta & Google Ads campaigns exceeded our highest expectations. Truly the top digital agency in Pondicherry.', NULL, NULL, 'Managing Director', 'French Quarter Hospitality', 'approved', '2026-08-29 12:57:01', '2026-08-29 12:57:01');

-- ---------------------------------------------------------------
-- 12. Table structure for `why_choose_us` -------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `why_choose_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `answer` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_wcu_status_sort` (`status`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `why_choose_us`
INSERT IGNORE INTO `why_choose_us` (`id`, `question`, `answer`, `icon`, `status`, `sort_order`, `created_at`, `updated_at`) VALUES
('16', 'Proven Track Record', '500+ successful digital initiatives with measurable ROI across e-commerce, healthcare, and SaaS.', 'fa-trophy', 'active', '1', '2026-08-29 01:37:35', '2026-08-29 01:37:35'),
('17', 'Certified Specialists', 'Dedicated specialists in performance marketing, technical SEO, and conversion-focused web development.', 'fa-users-gear', 'active', '2', '2026-08-29 01:37:35', '2026-08-29 01:37:35'),
('18', 'Data-Driven Growth', 'Every campaign decision is backed by live analytics and deep audience behavior modeling.', 'fa-chart-line', 'active', '3', '2026-08-29 01:37:35', '2026-08-29 01:37:35'),
('19', 'Dedicated Support', 'Direct access to account leads and transparent bi-weekly strategy alignment calls.', 'fa-headset', 'active', '4', '2026-08-29 01:37:35', '2026-08-29 01:37:35'),
('20', 'Rapid Execution', 'Fast turnaround without sacrificing code quality, security, or creative finesse.', 'fa-bolt', 'active', '5', '2026-08-29 01:37:35', '2026-08-29 01:37:35'),
('21', 'Transparent Analytics', 'Live real-time performance dashboards so you always know your exact cost per acquisition.', 'fa-shield-halved', 'active', '6', '2026-08-29 01:37:35', '2026-08-29 01:37:35');

-- ---------------------------------------------------------------
-- 13. Table structure for `faqs` ----------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `faqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `faqs`
INSERT IGNORE INTO `faqs` (`id`, `question`, `answer`, `status`, `sort_order`, `created_at`, `updated_at`) VALUES
('18', 'Why partner with Cloud Aspire?', 'We treat your business as our own. By pairing data-driven analytics with creative excellence, we design campaigns that deliver measurable bottom-line growth, not vanity metrics.', 'active', '1', '2026-08-29 01:53:45', '2026-08-29 01:53:45'),
('19', 'How do you approach multi-channel digital growth?', 'We begin with a deep market audit, identify high-intent conversion bottlenecks, and deploy a synchronized mix of SEO, Meta/Google Ads, content, and high-speed landing pages.', 'active', '2', '2026-08-29 01:53:45', '2026-08-29 01:53:45'),
('20', 'How quickly can we expect to see tangible results?', 'Paid performance campaigns generate qualified inquiries within days of launch. SEO ranking momentum typically builds strong compounding returns within 60 to 90 days.', 'active', '3', '2026-08-29 01:53:45', '2026-08-29 01:53:45'),
('21', 'Do you offer custom tailored packages?', 'Yes! We craft bespoke growth roadmaps aligned with your immediate goals, target CAC (Customer Acquisition Cost), and market trajectory.', 'active', '4', '2026-08-29 01:53:45', '2026-08-29 01:53:45'),
('22', 'How do you report on campaign performance?', 'You receive 24/7 access to live analytics dashboards and concise executive summaries detailing spend, leads, conversions, and ROI.', 'active', '5', '2026-08-29 01:53:45', '2026-08-29 01:53:45');

-- ---------------------------------------------------------------
-- 14. Table structure for `pages` ---------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `page_slug` varchar(150) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `seo_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `canonical_url` varchar(500) DEFAULT NULL,
  `og_title` varchar(255) DEFAULT NULL,
  `og_description` text DEFAULT NULL,
  `og_image` varchar(500) DEFAULT NULL,
  `twitter_title` varchar(255) DEFAULT NULL,
  `twitter_description` text DEFAULT NULL,
  `twitter_image` varchar(500) DEFAULT NULL,
  `robots_meta` varchar(100) DEFAULT 'index, follow',
  `schema_markup` text DEFAULT NULL,
  `hero_section` mediumtext DEFAULT NULL,
  `main_content` mediumtext DEFAULT NULL,
  `images` text DEFAULT NULL,
  `buttons` text DEFAULT NULL,
  `custom_html` mediumtext DEFAULT NULL,
  `custom_css` mediumtext DEFAULT NULL,
  `custom_js` mediumtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_slug` (`page_slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `pages`
INSERT IGNORE INTO `pages` (`id`, `page_title`, `page_slug`, `is_active`, `seo_title`, `meta_description`, `meta_keywords`, `canonical_url`, `og_title`, `og_description`, `og_image`, `twitter_title`, `twitter_description`, `twitter_image`, `robots_meta`, `schema_markup`, `hero_section`, `main_content`, `images`, `buttons`, `custom_html`, `custom_css`, `custom_js`, `created_at`, `updated_at`) VALUES
('1', 'Home', 'home.php', '1', NULL, 'Leading digital agency for growth and ROI.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02'),
('2', 'Services', 'services.php', '1', NULL, 'Our full range of digital marketing and development services.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02'),
('3', 'Projects', 'projects.php', '1', NULL, 'Our showcase of successful client projects and case studies.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02'),
('4', 'Plans & Pricing', 'plans.php', '1', NULL, 'Transparent, scalable digital marketing pricing plans.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02'),
('5', 'Why Choose Us', 'why-choose-us.php', '1', NULL, 'Why brands trust us for data-backed growth.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02'),
('6', 'Testimonials', 'testimonials.php', '1', NULL, 'Client success stories and endorsements.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02'),
('7', 'Reviews', 'reviews.php', '1', NULL, 'Ratings and feedback from our partners.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02'),
('8', 'Contact Us', 'contact.php', '1', NULL, 'Get in touch for a free growth consultation.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02'),
('9', 'Privacy Policy', 'privacy-policy.php', '1', NULL, 'Our commitment to your privacy and data security.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02'),
('10', 'Refund Policy', 'refund-policy.php', '1', NULL, 'Information on our satisfaction guarantee and refund process.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02'),
('11', 'Terms & Conditions', 'terms.php', '1', NULL, 'Terms of service and legal agreement.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'index, follow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-29 12:41:02', '2026-08-29 12:41:02');

-- ---------------------------------------------------------------
-- 15. Table structure for `leads` ---------------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `leads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `service` varchar(150) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` enum('new','contacted','confirmed','lose') DEFAULT 'new',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_leads_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- 16. Table structure for `admin_activities` ----------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `device_info` varchar(255) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- 17. Table structure for `admin_sessions` ------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(128) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `device_info` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `last_activity` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_last_activity` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- 18. Table structure for `security_alerts` -----------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `security_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `severity` enum('low','medium','high','critical') DEFAULT 'medium',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `resolved` tinyint(1) DEFAULT 0,
  `resolved_by` int(11) DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_severity` (`severity`),
  KEY `idx_resolved` (`resolved`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- 19. Table structure for `rate_limits` ---------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `rate_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'failed_login',
  `count` int(11) DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_identifier_type` (`identifier`,`type`),
  KEY `idx_identifier_type` (`identifier`,`type`),
  KEY `idx_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- 20. Table structure for `ip_blocks` -----------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `ip_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `blocked_until` datetime NOT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_blocked_until` (`blocked_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- 21. Table structure for `mail_logs` -----------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `mail_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `error_message` text DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------
-- 22. Table structure for `mail_queue` ----------------------------
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `mail_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` mediumtext NOT NULL,
  `alt_body` text DEFAULT NULL,
  `is_html` tinyint(1) DEFAULT 1,
  `status` enum('pending','processing','sent','failed') DEFAULT 'pending',
  `attempts` int(11) DEFAULT 0,
  `max_attempts` int(11) DEFAULT 3,
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `processed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mail_queue_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
