<?php
// Testimonials are loaded by the controller testimonials.php and passed to this view.
$testimonials = $testimonials ?? [];
$site_name = $site_name ?? 'Cloud Aspire';
?>

<?php include __DIR__ . '/../../../includes/header.php'; ?>

<style>
    /* Metrics Row */
    .testimonial-metrics {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 24px;
        margin-bottom: 50px;
    }

    .t-metric-card {
        background: #FFFFFF;
        border: 1px solid var(--border-light);
        border-radius: var(--r);
        padding: 28px 20px;
        text-align: center;
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        position: relative;
        overflow: hidden;
    }

    .t-metric-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-md);
        border-color: rgba(108, 59, 255, 0.3);
    }

    .t-metric-card .metric-icon {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: rgba(108, 59, 255, 0.08);
        color: var(--primary);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        margin-bottom: 12px;
    }

    .t-metric-card h3 {
        font-size: 1.8rem;
        font-weight: 800;
        color: var(--text);
        margin: 0 0 4px 0;
        background: var(--grad);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    .t-metric-card p {
        margin: 0;
        color: var(--text2);
        font-size: 0.9rem;
        font-weight: 500;
    }

    /* Testimonials Grid */
    .testimonials-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
        gap: 32px;
        margin-top: 30px;
    }

    .testimonial-card {
        background: #FFFFFF;
        padding: 38px 32px 32px;
        border-radius: var(--r);
        border: 1px solid var(--border-light);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        display: flex;
        flex-direction: column;
        min-height: 380px;
        height: 100%;
        position: relative;
        overflow: hidden;
    }

    .testimonial-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: var(--grad);
    }

    .testimonial-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 16px 45px rgba(108, 59, 255, 0.14);
        border-color: rgba(108, 59, 255, 0.25);
    }

    .quote-icon {
        position: absolute;
        top: 24px;
        right: 26px;
        font-size: 2.6rem;
        color: var(--primary);
        opacity: 0.1;
        z-index: 0;
    }

    .testimonial-stars {
        color: #F59E0B;
        font-size: 1rem;
        margin-bottom: 16px;
        letter-spacing: 2px;
        display: flex;
        gap: 2px;
    }

    .testimonial-message {
        font-size: 1.02rem;
        line-height: 1.8;
        color: var(--text2);
        margin-bottom: 28px;
        font-style: italic;
        position: relative;
        z-index: 1;
        flex-grow: 1; 
    }

    .client-info {
        display: flex;
        align-items: center;
        gap: 16px;
        border-top: 1px solid rgba(0, 0, 0, 0.05);
        padding-top: 20px;
        margin-top: auto;
    }

    .avatar-wrap {
        width: 62px;
        height: 62px;
        border-radius: 50%;
        overflow: hidden;
        border: 2px solid var(--primary);
        background: rgba(108, 59, 255, 0.08);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        box-shadow: 0 4px 14px rgba(108, 59, 255, 0.2);
        position: relative;
    }

    .avatar-wrap img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .testimonial-card:hover .avatar-wrap img {
        transform: scale(1.08);
    }

    .avatar-fallback {
        font-size: 1.6rem;
        color: var(--primary);
    }

    .client-details {
        flex-grow: 1;
    }

    .client-details h4 {
        margin: 0 0 4px 0;
        font-size: 1.08rem;
        font-weight: 700;
        color: var(--text);
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .client-details .verified-badge {
        color: #10B981;
        font-size: 0.88rem;
    }

    .designation-text {
        margin: 0;
        color: var(--primary);
        font-weight: 600;
        font-size: 0.85rem;
    }

    /* Responsive */
    @media (max-width: 992px) {
        .testimonial-metrics {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 640px) {
        .testimonial-metrics {
            grid-template-columns: 1fr;
        }
        .testimonial-card {
            padding: 30px 22px 24px;
        }
    }
</style>

<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <h1>Client <span class="highlight">Testimonials</span></h1>
        <p>Real stories of growth, transformation, and impact from our valued business partners</p>
        <div class="breadcrumb"><a href="<?= $base_url ?>/">Home</a> / Testimonials</div>
    </div>
</section>

<!-- Trust & Performance Metrics -->
<section class="section">
    <div class="container">
        <div class="testimonial-metrics">
            <div class="t-metric-card fade-in">
                <div class="metric-icon"><i class="fas fa-handshake"></i></div>
                <h3><?= htmlspecialchars((string)($stat_partners ?? '120+')) ?></h3>
                <p>Enterprise & Growth Partners</p>
            </div>
            <div class="t-metric-card fade-in">
                <div class="metric-icon"><i class="fas fa-chart-line"></i></div>
                <h3><?= htmlspecialchars((string)($stat_growth ?? '350%')) ?></h3>
                <p>Average Client Growth</p>
            </div>
            <div class="t-metric-card fade-in">
                <div class="metric-icon"><i class="fas fa-smile-beam"></i></div>
                <h3><?= htmlspecialchars((string)($stat_satisfaction ?? '99%')) ?></h3>
                <p>Client Satisfaction Rate</p>
            </div>
            <div class="t-metric-card fade-in">
                <div class="metric-icon"><i class="fas fa-trophy"></i></div>
                <h3><?= htmlspecialchars((string)($stat_projects ?? '150+')) ?></h3>
                <p>Successful Projects</p>
            </div>
        </div>

        <div class="section-header fade-in">
            <h2>What Our Partners <span class="highlight">Say</span></h2>
            <p>Direct words of praise from founders, marketing leaders, and enterprise directors</p>
        </div>
        
        <div class="testimonials-grid">
            <?php if (!empty($testimonials)): ?>
                <?php foreach($testimonials as $t): ?>
                    <?php 
                    $image_src = '';
                    if (!empty($t['image'])) {
                        if (str_starts_with($t['image'], 'http://') || str_starts_with($t['image'], 'https://')) {
                            $image_src = $t['image'];
                        } else {
                            $image_src = $base_url . '/' . ltrim($t['image'], '/');
                        }
                    }
                    ?>
                    <div class="testimonial-card fade-in">
                        <i class="fas fa-quote-right quote-icon"></i>
                        <div class="testimonial-stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="testimonial-message">"<?= nl2br(htmlspecialchars($t['message'])) ?>"</p>
                        
                        <div class="client-info">
                            <div class="avatar-wrap">
                                <?php if (!empty($image_src)): ?>
                                    <img src="<?= htmlspecialchars($image_src) ?>" alt="<?= htmlspecialchars($t['name']) ?>" loading="lazy">
                                <?php else: ?>
                                    <i class="fas fa-user avatar-fallback"></i>
                                <?php endif; ?>
                            </div>
                            
                            <div class="client-details">
                                <h4>
                                    <?= htmlspecialchars($t['name']) ?>
                                    <i class="fas fa-check-circle verified-badge" title="Verified Client"></i>
                                </h4>
                                <?php if (!empty($t['designation'])): ?>
                                    <p class="designation-text">
                                        <?= htmlspecialchars($t['designation']) ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="grid-column: 1/-1; text-align: center; padding: 70px 20px; background: #FFFFFF; border-radius: var(--r); border: 1px dashed var(--border-light);">
                    <div style="width: 70px; height: 70px; border-radius: 50%; background: rgba(108, 59, 255, 0.08); color: var(--primary); display: inline-flex; align-items: center; justify-content: center; font-size: 1.8rem; margin-bottom: 20px;">
                        <i class="fas fa-comment-dots"></i>
                    </div>
                    <h3 style="font-size: 1.4rem; margin-bottom: 8px;">No Testimonials Yet</h3>
                    <p style="color: var(--text2); max-width: 460px; margin: 0 auto 24px;">Client video and written testimonials will appear here as they are published.</p>
                    <a href="<?= $base_url ?>/contact" class="btn btn-primary">Work With Us</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>