<?php 
$projects = $projects ?? [];
$site_name = $site_name ?? 'Cloud Aspire';
?>
<?php include __DIR__ . '/../../../includes/header.php'; ?>

<style>
    .project-card {
        border-radius: var(--r);
        overflow: hidden;
        background: #FFFFFF;
        border: 1px solid var(--border-light);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        display: flex;
        flex-direction: column;
        position: relative;
    }

    .project-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 45px rgba(108, 59, 255, 0.16);
        border-color: rgba(108, 59, 255, 0.25);
    }

    .project-card .img {
        height: 230px;
        background: linear-gradient(135deg, rgba(108, 59, 255, 0.05), rgba(79, 70, 229, 0.08));
        overflow: hidden;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .project-card .img img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .project-card:hover .img img {
        transform: scale(1.08);
    }

    .project-status-badge {
        position: absolute;
        top: 14px;
        right: 14px;
        padding: 5px 12px;
        border-radius: var(--r-pill);
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        backdrop-filter: blur(10px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        z-index: 2;
    }

    .project-status-completed {
        background: rgba(16, 185, 129, 0.9);
        color: #FFFFFF;
    }

    .project-status-running {
        background: rgba(59, 130, 246, 0.9);
        color: #FFFFFF;
    }

    .project-status-pending {
        background: rgba(245, 158, 11, 0.9);
        color: #FFFFFF;
    }

    .project-card .info {
        padding: 26px;
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    }

    .project-card .info h2 {
        font-size: 1.25rem;
        font-weight: 700;
        margin-bottom: 10px;
        line-height: 1.35;
    }

    .project-card .info h2 a:hover {
        color: var(--primary);
    }

    .project-desc {
        color: var(--text2);
        font-size: 0.92rem;
        line-height: 1.6;
        margin-bottom: 14px;
    }

    .project-result-tag {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(16, 185, 129, 0.08);
        border: 1px solid rgba(16, 185, 129, 0.2);
        color: var(--success);
        padding: 5px 12px;
        border-radius: var(--r-pill);
        font-size: 0.82rem;
        font-weight: 600;
        margin-bottom: 16px;
        align-self: flex-start;
    }

    .project-budget-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 14px;
        padding-bottom: 12px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }

    .project-budget-val {
        font-weight: 700;
        color: var(--primary);
        font-size: 1rem;
    }

    .project-date {
        color: var(--text-muted);
        font-size: 0.82rem;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 5px;
    }
</style>

<section class="page-header">
    <div class="container">
        <h1>Our <span class="highlight">Projects</span></h1>
        <p>Explore our portfolio of successful digital campaigns, web platforms, and growth cases</p>
        <div class="breadcrumb"><a href="<?= $base_url ?>/">Home</a> / Projects</div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="projects-filter fade-in">
            <button class="active" data-filter="all"><i class="fas fa-th"></i> All Projects</button>
            <button data-filter="seo"><i class="fas fa-search"></i> SEO</button>
            <button data-filter="social"><i class="fas fa-share-alt"></i> Social Media</button>
            <button data-filter="ads"><i class="fas fa-bullhorn"></i> Paid Ads</button>
            <button data-filter="web"><i class="fas fa-code"></i> Website</button>
        </div>

        <div class="projects-grid">
            <?php
            $colors = ['#6C3BFF','#4F46E5','#8B5CF6','#7C3AED','#6366F1','#818CF8','#6C3BFF','#4F46E5','#8B5CF6'];

            if (!empty($projects)):
                foreach($projects as $k => $p):
                    $cat = function_exists('getProjectCategory') ? getProjectCategory($p) : 'web';
                    $industry = function_exists('getProjectIndustry') ? getProjectIndustry($p) : 'Digital';
                    $color = $colors[$k % count($colors)];
                    $target_url = !empty($p['project_link']) ? $p['project_link'] : ($base_url . '/contact');
                    $status = strtolower($p['status'] ?? 'completed');
            ?>
                <div class="project-card fade-in" data-category="<?= htmlspecialchars($cat) ?>">
                    <span class="project-status-badge project-status-<?= $status ?>">
                        <?= ucfirst(htmlspecialchars($status)) ?>
                    </span>
                    
                    <a href="<?= htmlspecialchars($target_url) ?>" style="display:block">
                        <div class="img">
                            <?php if (!empty($p['thumbnail'])): ?>
                                <img src="<?= htmlspecialchars($p['thumbnail']) ?>" alt="<?= htmlspecialchars($p['project_name']) ?>" loading="lazy" decoding="async">
                            <?php else: ?>
                                <i class="fas <?= $cat=='seo'?'fa-search':($cat=='social'?'fa-share-alt':($cat=='ads'?'fa-bullhorn':'fa-code')) ?>" style="font-size:3.5rem;color:<?= $color ?>;opacity:.7"></i>
                            <?php endif; ?>
                        </div>
                    </a>
                    
                    <div class="info">
                        <div class="project-budget-row">
                            <span class="tag"><?= htmlspecialchars($industry) ?></span>
                            <span class="project-budget-val">
                                <?= is_numeric($p['budget']) ? '₹' . number_format((float)$p['budget']) : htmlspecialchars($p['budget'] ?: 'Custom') ?>
                            </span>
                        </div>
                        
                        <h2><a href="<?= htmlspecialchars($target_url) ?>"><?= htmlspecialchars($p['project_name']) ?></a></h2>
                        
                        <?php if (!empty($p['description'])): ?>
                            <p class="project-desc"><?= htmlspecialchars($p['description']) ?></p>
                        <?php endif; ?>

                        <?php if (!empty($p['results'])): ?>
                            <div class="project-result-tag">
                                <i class="fas fa-chart-line"></i> <?= htmlspecialchars($p['results']) ?>
                            </div>
                        <?php endif; ?>

                        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:auto;padding-top:12px;border-top:1px solid rgba(0,0,0,0.04);">
                            <span class="project-date">
                                <i class="fas fa-calendar-alt"></i> <?= !empty($p['project_datetime']) ? date('M Y', strtotime($p['project_datetime'])) : 'Recent' ?>
                            </span>
                            <a href="<?= htmlspecialchars($target_url) ?>" style="color:var(--primary);font-weight:600;font-size:0.88rem;display:inline-flex;align-items:center;gap:5px;">
                                View Details <i class="fas fa-arrow-right" style="font-size:0.75rem;"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php else: ?>
                <div style="grid-column: 1/-1; text-align: center; padding: 70px 20px; background: #FFFFFF; border-radius: var(--r); border: 1px dashed var(--border-light);">
                    <div style="width: 70px; height: 70px; border-radius: 50%; background: rgba(108, 59, 255, 0.08); color: var(--primary); display: inline-flex; align-items: center; justify-content: center; font-size: 1.8rem; margin-bottom: 20px;">
                        <i class="fas fa-folder-open"></i>
                    </div>
                    <h3 style="font-size: 1.4rem; margin-bottom: 8px;">No Projects Listed Yet</h3>
                    <p style="color: var(--text2); max-width: 460px; margin: 0 auto 24px;">Our portfolio is currently being updated with recent client case studies. Contact us to learn more about our past work.</p>
                    <a href="<?= $base_url ?>/contact" class="btn btn-primary">Start a New Project</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>
