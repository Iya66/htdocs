<?php include __DIR__ . '/../../../includes/header.php'; ?>
<?php
$policy_content = $settings['refund_policy'] ?? '';
$site_name = $site_name ?? 'Cloud Aspire';
$contact_email = $contact_email ?? 'tamilaninstamedia1@gmail.com';

if (empty($policy_content)) {
    $policy_content = <<<EOT
<h2>1. Satisfaction Commitment</h2>
<p>At {$site_name}, we are committed to providing top-tier digital marketing, SEO, and development solutions. We work closely with every client at every milestone to ensure our deliverables match expectations.</p>

<h2>2. Refund Eligibility & Window</h2>
<p>If you are dissatisfied with a standard subscription plan or service kickoff, you may submit a formal review request within 14 calendar days of onboarding.</p>

<h2>3. Excluded & Non-Refundable Services</h2>
<p>The following costs represent direct third-party or completed disbursements and are non-refundable:</p>
<ul>
    <li>Third-party platform advertising spend paid directly to Google, Meta, or LinkedIn</li>
    <li>Domain registration, dedicated server provisioning, or third-party API license fees</li>
    <li>Custom design or development phases that have already been reviewed, approved, and delivered</li>
</ul>

<h2>4. Refund Request Process</h2>
<p>To request a billing review or dispute resolution, please email our finance desk at <a href="mailto:{$contact_email}" style="color:var(--primary); font-weight:600;">{$contact_email}</a> with your invoice number and project details. We review and process valid claims within 5-7 business days.</p>
EOT;
}
?>

<style>
    .legal-card-wrap {
        max-width: 900px;
        margin: 0 auto;
        background: #FFFFFF;
        border: 1px solid var(--border-light);
        border-radius: var(--r-lg);
        padding: 50px 48px;
        box-shadow: var(--shadow-sm);
        line-height: 1.85;
    }

    .legal-card-wrap h2 {
        font-size: 1.35rem;
        font-weight: 700;
        color: var(--text);
        margin: 32px 0 12px;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }

    .legal-card-wrap h2:first-of-type {
        margin-top: 0;
    }

    .legal-card-wrap p, .legal-card-wrap li {
        color: var(--text2);
        font-size: 0.98rem;
        margin-bottom: 14px;
    }

    .legal-card-wrap ul {
        padding-left: 24px;
        margin-bottom: 20px;
    }

    .legal-badge-bar {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: rgba(108, 59, 255, 0.06);
        border: 1px solid rgba(108, 59, 255, 0.14);
        padding: 6px 16px;
        border-radius: var(--r-pill);
        font-size: 0.82rem;
        font-weight: 600;
        color: var(--primary);
        margin-top: 14px;
    }

    @media (max-width: 768px) {
        .legal-card-wrap {
            padding: 32px 20px;
        }
    }
</style>

<section class="page-header">
    <div class="container">
        <h1>Refund <span class="highlight">Policy</span></h1>
        <p>Clear, fair, and transparent cancellation and refund guidelines</p>
        <div class="legal-badge-bar">
            <i class="fas fa-undo"></i> Last Updated: <?= date('F j, Y'); ?>
        </div>
    </div>
</section>

<section class="section" style="padding-top: 50px; background: #F8FAFC;">
    <div class="container">
        <div class="legal-card-wrap fade-in">
            <?= $policy_content ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>
