<?php 
// Active services are loaded by the controller services.php and passed to this view.
$services = $services ?? [];
$site_name = $site_name ?? 'Cloud Aspire';
?>

<?php include __DIR__ . '/../../../includes/header.php'; ?>

<style>
    .svc-section {
        padding: 70px 0;
        position: relative;
        overflow: hidden;
    }
    .svc-section.row-even {
        background: #FFFFFF;
    }
    .svc-section.row-odd {
        background: #F8FAFC;
    }

    .service-row-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 40px;
        align-items: center;
    }

    .svc-text-col { order: 1; }
    .svc-img-col { order: 2; }

    /* Left & Right Slide Animations (Slower & Smoother) */
    .svc-slide-left {
        opacity: 0;
        transform: translateX(-80px);
        transition: opacity 1.4s cubic-bezier(0.2, 0.8, 0.2, 1), transform 1.4s cubic-bezier(0.2, 0.8, 0.2, 1);
        will-change: opacity, transform;
    }

    .svc-slide-right {
        opacity: 0;
        transform: translateX(80px);
        transition: opacity 1.4s cubic-bezier(0.2, 0.8, 0.2, 1), transform 1.4s cubic-bezier(0.2, 0.8, 0.2, 1);
        will-change: opacity, transform;
    }

    .svc-slide-left.is-visible,
    .svc-slide-right.is-visible {
        opacity: 1;
        transform: translateX(0);
    }

    .svc-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 14px;
        background: rgba(108, 59, 255, 0.08);
        border: 1px solid rgba(108, 59, 255, 0.18);
        border-radius: var(--r-pill);
        color: var(--primary);
        font-size: 0.8rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        margin-bottom: 16px;
    }

    .svc-title {
        font-size: 2.2rem;
        font-weight: 800;
        margin-bottom: 16px;
        line-height: 1.2;
    }

    .svc-desc {
        color: var(--text2);
        font-size: 1.02rem;
        line-height: 1.8;
        margin-bottom: 24px;
    }

    .svc-img-card {
        border-radius: var(--r-lg);
        overflow: hidden;
        box-shadow: 0 16px 45px rgba(108, 59, 255, 0.12);
        border: 1px solid var(--border-light);
        position: relative;
        background: linear-gradient(135deg, rgba(108, 59, 255, 0.04), rgba(79, 70, 229, 0.08));
        transition: var(--transition);
    }

    .svc-img-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 24px 60px rgba(108, 59, 255, 0.18);
    }

    .svc-img-card img {
        width: 100%;
        height: auto;
        aspect-ratio: 16/10;
        object-fit: cover;
        transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .svc-img-card:hover img {
        transform: scale(1.04);
    }

    .svc-placeholder {
        padding: 80px 40px;
        text-align: center;
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 320px;
    }

    .svc-placeholder i {
        font-size: 5rem;
        background: var(--grad);
        -webkit-background-clip: text;
        background-clip: text;
        -webkit-text-fill-color: transparent;
        opacity: 0.8;
    }

    @media (max-width: 768px) {
        .svc-slide-left {
            transform: translateX(-40px);
        }
        .svc-slide-right {
            transform: translateX(40px);
        }
    }

    @media (min-width: 768px) {
        .service-row-grid {
            grid-template-columns: 1.05fr 0.95fr;
            gap: 60px;
        }
        .row-even .svc-text-col { order: 2; }
        .row-even .svc-img-col { order: 1; }
    }

    @media (prefers-reduced-motion: reduce) {
        .svc-slide-left,
        .svc-slide-right {
            opacity: 1 !important;
            transform: none !important;
            transition: none !important;
        }
    }
</style>

<section class="page-header">
    <div class="container">
        <h1>Our <span class="highlight">Services</span></h1>
        <p>Result-driven digital marketing and development solutions engineered to scale your business online</p>
        <div class="breadcrumb"><a href="<?= $base_url ?>/">Home</a> / Services</div>
    </div>
</section>

<?php if (!empty($services)):
    $i = 0;
    foreach($services as $s): 
        $i++; 
        $isEven = ($i % 2 === 0); 
        $rowClass = $isEven ? 'row-even' : 'row-odd';
        $textSlide = $isEven ? 'svc-slide-right' : 'svc-slide-left';
        $imgSlide  = $isEven ? 'svc-slide-left' : 'svc-slide-right';
?>
    <section class="svc-section <?= $rowClass ?>">
        <div class="container">
            <div class="service-row-grid">
                
                <div class="svc-text-col <?= $textSlide ?>">
                    <div class="svc-badge">
                        <i class="fas <?= htmlspecialchars($s['icon'] ?: 'fa-cube') ?>"></i> Premium Service
                    </div>
                    
                    <h2 class="svc-title"><?= htmlspecialchars($s['service_name'] ?? '') ?></h2>
                    <p class="svc-desc"><?= htmlspecialchars($s['short_description'] ?? '') ?></p>
                    
                    <div style="display: flex; gap: 14px; flex-wrap: wrap;">
                        <a href="<?= $base_url ?>/contact?service=<?= urlencode($s['service_name'] ?? '') ?>" class="btn btn-primary">Get Started <i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                
                <div class="svc-img-col <?= $imgSlide ?>">
                    <div class="svc-img-card">
                        <?php 
                        $s_image_url = '';
                        if (!empty($s['image'])) {
                            if (str_starts_with($s['image'], 'http://') || str_starts_with($s['image'], 'https://') || str_starts_with($s['image'], '/')) {
                                $s_image_url = $s['image'];
                            } else {
                                $s_image_url = $base_url . '/' . ltrim($s['image'], '/');
                            }
                        }
                        ?>
                        <?php if ($s_image_url): ?>
                            <img src="<?= htmlspecialchars($s_image_url) ?>" alt="<?= htmlspecialchars($s['service_name'] ?? '') ?>" loading="lazy" decoding="async" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80';">
                        <?php else: ?>
                            <div class="svc-placeholder">
                                <i class="fas <?= htmlspecialchars($s['icon'] ?: 'fa-briefcase') ?>"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
<?php endforeach; 
else: ?>
    <section class="section">
        <div class="container" style="text-align: center; padding: 80px 20px;">
            <div style="width: 80px; height: 80px; border-radius: 50%; background: rgba(108, 59, 255, 0.08); color: var(--primary); display: inline-flex; align-items: center; justify-content: center; font-size: 2rem; margin-bottom: 20px;">
                <i class="fas fa-cube"></i>
            </div>
            <h3 style="font-size: 1.5rem; margin-bottom: 8px;">No Services Listed Yet</h3>
            <p style="color: var(--text2); max-width: 480px; margin: 0 auto 24px;">Our offerings are being updated. Check back shortly or contact our team directly for custom solutions.</p>
            <a href="<?= $base_url ?>/contact" class="btn btn-primary">Contact Our Team</a>
        </div>
    </section>
<?php endif; ?>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const animatedElements = document.querySelectorAll('.svc-slide-left, .svc-slide-right');
    
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries, obs) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    obs.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.12,
            rootMargin: '0px 0px -40px 0px'
        });
        
        animatedElements.forEach(el => observer.observe(el));
    } else {
        animatedElements.forEach(el => el.classList.add('is-visible'));
    }
});
</script>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>