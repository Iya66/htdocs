<?php 
$active_services = $active_services ?? [];
$selected_service = $selected_service ?? '';
$contact_email = $contact_email ?? 'tamilaninstamedia1@gmail.com';
$contact_phone = $contact_phone ?? '8098830937';
$contact_whatsapp = $contact_whatsapp ?? '8098830937';
$contact_hours = $contact_hours ?? 'Mon - Sat: 9:00 AM - 7:00 PM';
$msg_status = $msg_status ?? null;
$msg_text = $msg_text ?? '';

// Fallback: If active_services is not passed, fetch directly from DB
if (empty($active_services) && isset($conn)) {
    try {
        $active_services = $conn->query("SELECT id, service_name, slug, price FROM services WHERE status = 'active' ORDER BY created_at ASC")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $active_services = [];
    }
}
?>
<?php include __DIR__ . '/../../../includes/header.php'; ?>

<style>
    .contact-wrapper {
        display: grid;
        grid-template-columns: 1.2fr 0.8fr;
        gap: 40px;
        align-items: start;
    }

    .contact-form-card {
        background: #FFFFFF;
        border: 1px solid var(--border-light);
        border-radius: var(--r-lg);
        padding: 44px;
        box-shadow: var(--shadow-sm);
        position: relative;
    }

    .contact-form-card h3 {
        font-size: 1.6rem;
        font-weight: 800;
        margin-bottom: 8px;
    }

    .contact-form-card p.subtitle {
        color: var(--text2);
        font-size: 0.95rem;
        margin-bottom: 28px;
    }

    .contact-sidebar {
        display: flex;
        flex-direction: column;
        gap: 24px;
    }

    .contact-info-card {
        background: #FFFFFF;
        border: 1px solid var(--border-light);
        border-radius: var(--r-lg);
        padding: 36px;
        box-shadow: var(--shadow-sm);
    }

    .contact-info-card h3 {
        font-size: 1.3rem;
        font-weight: 700;
        margin-bottom: 20px;
    }

    .contact-info-item {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 16px 0;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }

    .contact-info-item:last-of-type {
        border-bottom: none;
    }

    .contact-info-item .icon {
        width: 48px;
        height: 48px;
        border-radius: var(--r-md);
        background: rgba(108, 59, 255, 0.08);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        font-size: 1.2rem;
        flex-shrink: 0;
    }

    .status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: var(--success);
        display: inline-block;
        box-shadow: 0 0 8px var(--success);
        margin-right: 4px;
    }

    .guarantee-chips {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
        margin-top: 24px;
    }

    .guarantee-chip {
        background: #F8FAFC;
        border: 1px solid var(--border-light);
        padding: 12px 14px;
        border-radius: var(--r-md);
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 0.82rem;
        font-weight: 600;
        color: var(--text2);
    }

    .guarantee-chip i {
        color: var(--primary);
    }

    @media (max-width: 992px) {
        .contact-wrapper {
            grid-template-columns: 1fr;
        }
        .contact-form-card {
            padding: 32px 24px;
        }
    }
</style>

<section class="page-header">
    <div class="container">
        <h1>Contact <span class="highlight">Us</span></h1>
        <p>Let's discuss how we can accelerate your digital growth and maximize your marketing ROI</p>
        <div class="breadcrumb"><a href="<?= $base_url ?>/">Home</a> / Contact</div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="contact-wrapper">
            
            <!-- Left Form Column -->
            <div class="contact-form-card fade-in">
                <h3>Send Us a Message</h3>
                <p class="subtitle">Fill out the form below and our strategy team will respond within 2 hours.</p>

                <?php if ($msg_status === 'success'): ?>
                    <div style="background: rgba(16,185,129,.08); border: 1px solid #10B981; color: #065F46; padding: 18px 20px; border-radius: 12px; margin-bottom: 28px; display: flex; align-items: center; gap: 12px; font-weight: 500;">
                        <i class="fas fa-check-circle" style="color: #10B981; font-size: 1.4rem;"></i>
                        <div><?= $msg_text ?></div>
                    </div>
                <?php elseif ($msg_status === 'error'): ?>
                    <div style="background: rgba(239,68,68,.08); border: 1px solid #EF4444; color: #991B1B; padding: 18px 20px; border-radius: 12px; margin-bottom: 28px; display: flex; align-items: center; gap: 12px; font-weight: 500;">
                        <i class="fas fa-exclamation-circle" style="color: #EF4444; font-size: 1.4rem;"></i>
                        <div><?= $msg_text ?></div>
                    </div>
                <?php endif; ?>

                <form action="" method="POST" id="contactForm">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(generateCSRFToken()) ?>">
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 18px;">
                        <div class="form-group">
                            <label>Full Name *</label>
                            <input type="text" name="name" placeholder="John Doe" value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Email Address *</label>
                            <input type="email" name="email" placeholder="john@company.com" value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>" required>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 18px;">
                        <div class="form-group">
                            <label>Phone Number *</label>
                            <input type="tel" name="phone" placeholder="+91 98765 43210" value="<?= isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : '' ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Select Service *</label>
                            <select name="service" required>
                                <option value="" disabled <?= empty($_POST['service']) && empty($_GET['service']) ? 'selected' : '' ?>>Select a Service</option>
                                <?php
                                $selected_service = $_POST['service'] ?? ($_GET['service'] ?? '');
                                foreach ($active_services as $svc):
                                    $sname = $svc['service_name'] ?? '';
                                    $is_sel = (strcasecmp($sname, $selected_service) === 0);
                                ?>
                                    <option value="<?= htmlspecialchars($sname) ?>" <?= $is_sel ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($sname) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Your Message / Project Goals *</label>
                        <textarea name="message" rows="4" placeholder="Tell us about your business goals, target audience, or current challenges..." required><?= isset($_POST['message']) ? htmlspecialchars($_POST['message']) : '' ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; padding: 15px;">
                        <i class="fas fa-paper-plane"></i> Send Inquiry
                    </button>
                </form>

                <div class="guarantee-chips">
                    <div class="guarantee-chip"><i class="fas fa-shield-halved"></i> 100% Confidential</div>
                    <div class="guarantee-chip"><i class="fas fa-clock"></i> Quick Response</div>
                </div>
            </div>

            <!-- Right Info Column -->
            <div class="contact-sidebar fade-in">
                <?php
                $whatsapp_clean = preg_replace('/[^0-9]/', '', $contact_whatsapp);
                if (strlen($whatsapp_clean) === 10) {
                    $whatsapp_clean = '91' . $whatsapp_clean;
                }
                ?>
                <div class="contact-info-card">
                    <h3>Direct Connect</h3>
                    
                    <div class="contact-info-item">
                        <div class="icon"><i class="fas fa-phone"></i></div>
                        <div>
                            <strong style="font-size: 0.85rem; color: var(--text2); text-transform: uppercase; letter-spacing: 0.04em;">Call Us</strong><br>
                            <a href="tel:<?= htmlspecialchars($contact_phone) ?>" style="font-weight: 700; color: var(--text); font-size: 1.05rem;">
                                <?= htmlspecialchars($contact_phone) ?>
                            </a>
                        </div>
                    </div>

                    <div class="contact-info-item">
                        <div class="icon"><i class="fas fa-envelope"></i></div>
                        <div>
                            <strong style="font-size: 0.85rem; color: var(--text2); text-transform: uppercase; letter-spacing: 0.04em;">Email Support</strong><br>
                            <a href="mailto:<?= htmlspecialchars($contact_email) ?>" style="font-weight: 600; color: var(--primary);">
                                <?= htmlspecialchars($contact_email) ?>
                            </a>
                        </div>
                    </div>

                    <div class="contact-info-item">
                        <div class="icon"><i class="fas fa-clock"></i></div>
                        <div>
                            <strong style="font-size: 0.85rem; color: var(--text2); text-transform: uppercase; letter-spacing: 0.04em;">Working Hours</strong><br>
                            <span style="font-size: 0.92rem; color: var(--text); font-weight: 500;">
                                <span class="status-dot"></span> <?= htmlspecialchars($contact_hours) ?>
                            </span>
                        </div>
                    </div>

                    <a href="https://wa.me/<?= $whatsapp_clean ?>" target="_blank" rel="noopener noreferrer" class="whatsapp-btn">
                        <i class="fab fa-whatsapp" style="font-size: 1.4rem;"></i> Chat Instantly on WhatsApp
                    </a>
                </div>
            </div>

        </div>

        <!-- Google Map Section -->
        <div class="map-section" style="margin-top: 48px; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.06); border: 1px solid rgba(0,0,0,0.08); height: 350px;">
            <?php 
            $is_safe_map = !empty($contact_map_iframe) && str_starts_with(trim($contact_map_iframe), '<iframe') && !stripos($contact_map_iframe, '<script') && !stripos($contact_map_iframe, 'javascript:');
            if ($is_safe_map): 
            ?>
                <?= $contact_map_iframe ?>
            <?php else: ?>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d62444.66444855427!2d79.7797746416181!3d11.936053896500732!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5361ab8e49cfcf%3A0xcc6bd326d2f0b04e!2sPuducherry!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>
