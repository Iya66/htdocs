<?php include __DIR__ . '/../../../includes/header.php'; ?>
<?php
$policy_content = $settings['privacy_policy'] ?? '';
$site_name = $site_name ?? 'Cloud Aspire';
$contact_email = $contact_email ?? 'tamilaninstamedia1@gmail.com';
$contact_phone = $contact_phone ?? '8098830937';

if (empty($policy_content)) {
    $policy_content = <<<EOT
<h2>1. Information We Collect</h2>
<p>At {$site_name}, we collect information you provide directly to us, such as your name, email address, phone number, and business details when you fill out contact forms, request proposals, subscribe to updates, or engage our services.</p>

<h2>2. How We Use Your Information</h2>
<p>We use the data we collect for purposeful and transparent business operations:</p>
<ul>
    <li>To deliver, execute, and monitor our digital marketing and web development services</li>
    <li>To communicate critical project milestones, campaign performance, and strategy updates</li>
    <li>To enhance website responsiveness, security, and customer experience</li>
    <li>To adhere strictly to applicable statutory and legal frameworks</li>
</ul>

<h2>3. Information Sharing & Third Parties</h2>
<p>We strictly do not sell, trade, or monetize your personal or commercial data. We only share essential metadata with vetted infrastructure providers (such as hosting, email delivery, and analytics) who are bound by non-disclosure agreements.</p>

<h2>4. Data Security</h2>
<p>We employ enterprise-grade security protocols, encryption in transit (SSL/TLS), access controls, and regular vulnerability assessments to safeguard your data against unauthorized access or breaches.</p>

<h2>5. Cookies & Tracking Technologies</h2>
<p>Our website utilizes necessary cookies and privacy-respecting analytics to optimize user navigation and performance. You may configure cookie preferences directly within your browser settings.</p>

<h2>6. Your Data Rights</h2>
<p>You have the right to access, verify, export, or request deletion of your personal records. For inquiries, please reach out to our privacy compliance team at <a href="mailto:{$contact_email}" style="color:var(--primary); font-weight:600;">{$contact_email}</a>.</p>

<h2>7. Policy Updates</h2>
<p>We may update this Privacy Policy periodically to reflect evolving legal standards. Changes will be posted on this page with an updated timestamp.</p>
EOT;
}
?>

<style>
    .legal-card-wrap {
        max-width: 900px;
        margin: 0 auto;
        background: #FFFFFF;
        border: 1px solid var(--border-light);
        border-radius: var(--r-lg);
        padding: 50px 48px;
        box-shadow: var(--shadow-sm);
        line-height: 1.85;
    }

    .legal-card-wrap h2 {
        font-size: 1.35rem;
        font-weight: 700;
        color: var(--text);
        margin: 32px 0 12px;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }

    .legal-card-wrap h2:first-of-type {
        margin-top: 0;
    }

    .legal-card-wrap p, .legal-card-wrap li {
        color: var(--text2);
        font-size: 0.98rem;
        margin-bottom: 14px;
    }

    .legal-card-wrap ul {
        padding-left: 24px;
        margin-bottom: 20px;
    }

    .legal-badge-bar {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: rgba(108, 59, 255, 0.06);
        border: 1px solid rgba(108, 59, 255, 0.14);
        padding: 6px 16px;
        border-radius: var(--r-pill);
        font-size: 0.82rem;
        font-weight: 600;
        color: var(--primary);
        margin-top: 14px;
    }

    @media (max-width: 768px) {
        .legal-card-wrap {
            padding: 32px 20px;
        }
    }
</style>

<section class="page-header">
    <div class="container">
        <h1>Privacy <span class="highlight">Policy</span></h1>
        <p>Our commitment to protecting your personal data, confidentiality, and digital privacy</p>
        <div class="legal-badge-bar">
            <i class="fas fa-shield-halved"></i> Last Updated: <?= date('F j, Y'); ?>
        </div>
    </div>
</section>

<section class="section" style="padding-top: 50px; background: #F8FAFC;">
    <div class="container">
        <div class="legal-card-wrap fade-in">
            <?= $policy_content ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>
