<?php
require_once __DIR__ . '/../../../admin/includes/header.php';
?>

<style>
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 24px; margin-bottom: 32px; }
.stat-card { 
    background: var(--bg-card); padding: 24px; 
    border-radius: var(--border-radius); border: 1px solid var(--border-color);
    box-shadow: var(--shadow-sm); text-align: center; 
    transition: all var(--transition);
}
.stat-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-md); border-color: var(--primary); }
.stat-card h3 { font-size: 32px; color: var(--primary); margin-bottom: 8px; font-weight: 700; letter-spacing: -0.02em; }
.stat-card p { color: var(--text-muted); font-size: 14px; margin: 0; font-weight: 500; }

.settings-card { background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--border-radius); padding: 32px; box-shadow: var(--shadow-sm); margin-bottom: 24px; }
.settings-card h3 { font-size: 18px; color: var(--text-main); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; }
.settings-card h3 i { color: var(--primary); }

.form-group { margin-bottom: 20px; }
.form-group label { display: block; margin-bottom: 8px; color: var(--text-main); font-weight: 600; font-size: 14px; }
.form-group input, .form-group select { 
    width: 100%; padding: 14px 18px; 
    border: 1px solid var(--border-color); border-radius: var(--btn-radius); 
    font-size: 14px; background: var(--bg-main); color: var(--text-main); transition: all var(--transition); 
}
.form-group input:focus, .form-group select:focus { outline: none; border-color: var(--primary); }

.action-badge { display: inline-block; padding: 6px 12px; background: var(--bg-main); color: var(--text-main); border-radius: 8px; font-size: 11px; font-weight: 600; text-transform: uppercase; border: 1px solid var(--border-color); }
.action-badge.create { background: color-mix(in srgb, var(--success) 15%, transparent); color: var(--success); border-color: color-mix(in srgb, var(--success) 30%, transparent); }
.action-badge.update { background: color-mix(in srgb, var(--warning) 15%, transparent); color: var(--warning); border-color: color-mix(in srgb, var(--warning) 30%, transparent); }
.action-badge.delete { background: color-mix(in srgb, var(--danger) 15%, transparent); color: var(--danger); border-color: color-mix(in srgb, var(--danger) 30%, transparent); }
.action-badge.login { background: color-mix(in srgb, var(--primary) 15%, transparent); color: var(--primary); border-color: color-mix(in srgb, var(--primary) 30%, transparent); }

.filter-section { background: var(--bg-card); padding: 24px; border-radius: var(--border-radius); border: 1px solid var(--border-color); margin-bottom: 24px; }
.filter-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; align-items: end; }

.tab-nav { display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; }
.tab-btn { 
    padding: 12px 24px; background: var(--bg-card); 
    border: 1px solid var(--border-color); border-radius: var(--btn-radius); 
    cursor: pointer; font-size: 14px; font-weight: 600; color: var(--text-muted); 
    transition: all var(--transition); 
}
.tab-btn:hover, .tab-btn.active { 
    background: var(--primary); color: #fff; border-color: var(--primary); 
}
.tab-content { display: none; }
.tab-content.active { display: block; }

.email-preview { background: var(--bg-main); padding: 24px; border-radius: var(--border-radius); border: 1px solid var(--border-color); margin-top: 15px; }

table { width: 100%; border-collapse: collapse; }
th { color: var(--text-muted); padding: 16px 20px; text-align: left; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 2px solid var(--border-color); }
td { padding: 16px 20px; border-bottom: 1px solid var(--border-color); font-size: 14px; color: var(--text-main); }
tr:hover { background: color-mix(in srgb, var(--primary) 5%, transparent); }
</style>

<div class="saas-page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-chart-line" style="color: var(--primary);"></i> Activity & System Reports</h1>
        <p class="page-subtitle">Analyze administrative actions, daily throughput, and automated email reporting.</p>
    </div>
</div>

<?php if ($message): ?>
<div class="alert alert-<?= $message_type ?>"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card">
        <h3><?= $today_count ?></h3>
        <p>Today's Actions</p>
    </div>
    <div class="stat-card">
        <h3><?= $week_count ?></h3>
        <p>This Week</p>
    </div>
    <div class="stat-card">
        <h3><?= $month_count ?></h3>
        <p>This Month</p>
    </div>
    <div class="stat-card">
        <h3><?= $total_count ?></h3>
        <p>Total Records</p>
    </div>
</div>

<div class="tab-nav">
    <button class="tab-btn active" onclick="showTab('activity')">Activity Log</button>
    <button class="tab-btn" onclick="showTab('email-report')">Email Report</button>
    <button class="tab-btn" onclick="showTab('settings')">Email Settings</button>
</div>

<!-- Activity Log Tab -->
<div id="activity-tab" class="tab-content active">
    <div class="filter-section">
        <div class="filter-row">
            <div class="form-group">
                <label>Search</label>
                <input type="text" id="searchInput" placeholder="Search by admin, action, or details..." onkeyup="filterTable()">
            </div>
            <div class="form-group">
                <label>Filter by Action</label>
                <select id="actionFilter" onchange="filterTable()">
                    <option value="">All Actions</option>
                    <?php foreach ($unique_actions as $action): ?>
                    <option value="<?= htmlspecialchars($action['action']) ?>"><?= htmlspecialchars($action['action']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Filter by Date</label>
                <select id="dateFilter" onchange="filterTable()">
                    <option value="">All Time</option>
                    <option value="today">Today</option>
                    <option value="week">This Week</option>
                    <option value="month">This Month</option>
                </select>
            </div>
        </div>
    </div>

    <div class="settings-card">
        <h3><i class="fas fa-list-alt"></i> Recent Activity</h3>
        <div style="overflow-x: auto;">
            <table id="activityTable">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Admin Name</th>
                        <th>Username</th>
                        <th>Action</th>
                        <th>Details</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($audit_logs)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 30px; color: #666;">No activity recorded yet.</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($audit_logs as $log): ?>
                    <tr data-action="<?= htmlspecialchars($log['action']) ?>" data-date="<?= date('Y-m-d', strtotime($log['created_at'])) ?>">
                        <td><?= date('Y-m-d H:i', strtotime($log['created_at'])) ?></td>
                        <td><?= htmlspecialchars($log['admin_name'] ?? '<em>System</em>') ?></td>
                        <td><?= htmlspecialchars($log['admin_username'] ?? '-') ?></td>
                        <td><span class="action-badge <?= strtolower(substr($log['action'], 0, 6)) === 'create' ? 'create' : (strtolower(substr($log['action'], 0, 6)) === 'update' ? 'update' : (strtolower(substr($log['action'], 0, 6)) === 'delete' ? 'delete' : (strtolower(substr($log['action'], 0, 4)) === 'login' ? 'login' : 'toggle'))) ?>"><?= htmlspecialchars($log['action']) ?></span></td>
                        <td><?= htmlspecialchars($log['details'] ?? '-') ?></td>
                        <td><code style="font-size: 11px;"><?= htmlspecialchars($log['ip_address'] ?? '-') ?></code></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Email Report Tab -->
<div id="email-report-tab" class="tab-content">
    <div class="settings-card">
        <h3><i class="fas fa-envelope"></i> Send Activity Report via Email</h3>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

            <div class="form-group">
                <label>Report Period</label>
                <select name="report_range">
                    <option value="all">All Time</option>
                    <option value="today">Today Only</option>
                    <option value="week">Last 7 Days</option>
                    <option value="month">Last 30 Days</option>
                </select>
            </div>

            <div class="form-group">
                <label>Recipient Email *</label>
                <input type="email" name="admin_email" required placeholder="admin@example.com" value="<?= htmlspecialchars($_SESSION['admin_email'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>Preview (Last 5 Actions)</label>
                <div class="email-preview">
                    <?php
                    $preview = $conn->query("SELECT al.*, a.name as admin_name FROM admin_activities al LEFT JOIN admin a ON al.user_id = a.id ORDER BY al.created_at DESC LIMIT 5")->fetchAll();
                    foreach ($preview as $p):
                    ?>
                    <div style="padding: 8px 0; border-bottom: 1px solid #eee;">
                        <strong><?= date('Y-m-d H:i', strtotime($p['created_at'])) ?></strong> -
                        <?= htmlspecialchars($p['admin_name'] ?? 'System') ?> -
                        <span style="color: #667eea;"><?= htmlspecialchars($p['action']) ?></span>
                        <?php if ($p['details']): ?> - <?= htmlspecialchars($p['details']) ?><?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                    <?php if (empty($preview)): ?>
                    <p style="color: #666;">No activity to preview.</p>
                    <?php endif; ?>
                </div>
            </div>

            <button type="submit" name="send_report_email" class="btn btn-success">
                <i class="fas fa-paper-plane"></i> Send Report Email
            </button>
        </form>
    </div>
</div>

<!-- Email Settings Tab -->
<div id="settings-tab" class="tab-content">
    <div class="settings-card">
        <h3><i class="fas fa-cog"></i> Email Notification Settings</h3>
        <p style="color: #666; margin-bottom: 20px;">Configure automatic email notifications for site changes.</p>

        <?php
        // Get current email notification settings
        $notif_settings = $conn->query("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'notif_%'")->fetchAll(PDO::FETCH_ASSOC);
        $notif = [];
        foreach ($notif_settings as $s) {
            $notif[$s['setting_key']] = $s['setting_value'];
        }
        ?>

        <form method="POST" action="settings/save-notifications.php">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="notif_staff" value="1" <?= ($notif['notif_staff'] ?? '') ? 'checked' : '' ?>>
                        Staff Changes (Create/Update/Delete)
                    </label>
                </div>
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="notif_settings" value="1" <?= ($notif['notif_settings'] ?? '') ? 'checked' : '' ?>>
                        Settings Changes
                    </label>
                </div>
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="notif_content" value="1" <?= ($notif['notif_content'] ?? '') ? 'checked' : '' ?>>
                        Content Changes (Leads, Reviews, etc.)
                    </label>
                </div>
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="notif_login" value="1" <?= ($notif['notif_login'] ?? '') ? 'checked' : '' ?>>
                        Login Activity
                    </label>
                </div>
            </div>

            <div class="form-group" style="margin-top: 20px;">
                <label>Notification Email</label>
                <input type="email" name="notif_email" placeholder="notify@example.com" value="<?= htmlspecialchars($notif['notif_email'] ?? '') ?>">
                <small style="color: #666; display: block; margin-top: 5px;">Leave empty to use admin email from mail settings.</small>
            </div>

            <button type="submit" class="btn">
                <i class="fas fa-save"></i> Save Notification Settings
            </button>
        </form>
    </div>
</div>

<script>
function showTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    
    const tabEl = document.getElementById(tabName + '-tab');
    if (tabEl) {
        tabEl.classList.add('active');
    }
    
    const btns = document.querySelectorAll('.tab-btn');
    btns.forEach(btn => {
        const onclickAttr = btn.getAttribute('onclick') || '';
        if (onclickAttr.includes("'" + tabName + "'") || onclickAttr.includes('"' + tabName + '"')) {
            btn.classList.add('active');
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const tab = urlParams.get('tab');
    if (tab) {
        showTab(tab);
    }
});

function filterTable() {
    const search = document.getElementById('searchInput').value.toLowerCase();
    const action = document.getElementById('actionFilter').value;
    const date = document.getElementById('dateFilter').value;
    const today = new Date().toISOString().split('T')[0];
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    document.querySelectorAll('#activityTable tbody tr').forEach(row => {
        const text = row.textContent.toLowerCase();
        const rowAction = row.getAttribute('data-action');
        const rowDate = row.getAttribute('data-date');

        let show = text.includes(search);
        if (action && rowAction !== action) show = false;
        if (date === 'today' && rowDate !== today) show = false;
        if (date === 'week' && rowDate < weekAgo) show = false;
        if (date === 'month' && rowDate < monthAgo) show = false;

        row.style.display = show ? '' : 'none';
    });
}
</script>

<?php require_once __DIR__ . '/../../../admin/includes/footer.php'; ?>