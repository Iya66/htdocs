<?php
/**
 * Admin Reviews Management
 */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/email_helper.php';
require_once __DIR__ . '/../app/security_notifier.php';

$message = '';
$message_type = '';
$userRole = $_SESSION['admin_role'] ?? 'viewer';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (in_array($userRole, ['viewer'])) {
        $message = 'Access denied. You have view-only privileges.';
        $message_type = 'error';
    } elseif (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $message = 'Invalid request. Please refresh and try again.';
        $message_type = 'error';
    } else {
        $action = $_POST['action'];
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

        switch ($action) {
            case 'create':
                $review_name = $_POST['name'] ?? '';
                $review_email = $_POST['email'] ?? '';
                $stmt = $conn->prepare("INSERT INTO reviews (name, email, star_rating, message, review_text, status) VALUES (?, ?, ?, ?, ?, 'approved')");
                $stmt->execute([$review_name, $review_email ?: null, (int)$_POST['star_rating'], $_POST['message'], $_POST['message']]);
                logAudit($conn, 'CREATE_REVIEW', "Created review: " . $review_name, $_SESSION['admin_id']);
                notifySecurity('CREATE_REVIEW', "Created review: $review_name (" . (int)$_POST['star_rating'] . " stars)", $_SESSION['admin_id']);
                $message = 'Review created successfully!'; $message_type = 'success';
                break;
            case 'update':
                $stmt = $conn->prepare("UPDATE reviews SET name = ?, email = ?, star_rating = ?, message = ?, review_text = ? WHERE id = ?");
                $stmt->execute([$_POST['name'], $_POST['email'] ?: null, (int)$_POST['star_rating'], $_POST['message'], $_POST['message'], $id]);
                logAudit($conn, 'UPDATE_REVIEW', "Updated review ID: $id", $_SESSION['admin_id']);
                notifySecurity('UPDATE_REVIEW', "Review ID $id updated (" . (int)$_POST['star_rating'] . " stars)", $_SESSION['admin_id']);
                $message = 'Review updated successfully!'; $message_type = 'success';
                break;
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM reviews WHERE id = ?");
                $stmt->execute([$id]);
                logAudit($conn, 'DELETE_REVIEW', "Deleted review ID: $id", $_SESSION['admin_id']);
                notifySecurity('DELETE_REVIEW', "Review ID $id deleted", $_SESSION['admin_id']);
                $message = 'Review deleted successfully!'; $message_type = 'success';
                break;
        }
    }
}

$reviews = $conn->query("SELECT * FROM reviews ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
$csrf_token = generateCSRFToken();

require_once __DIR__ . '/../app/Views/admin/reviews.php';
