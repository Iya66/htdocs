<?php
/**
 * Site Header
 * Fixed: Site name now properly seeded and fetched from database
 */

// Ensure global settings fallbacks
$site_name = $site_name ?? ($settings['site_name'] ?? 'Cloud Aspire');
$site_favicon = $site_favicon ?? ($settings['site_favicon'] ?? '');
$site_logo = $site_logo ?? ($settings['site_logo'] ?? '');
$contact_email = $contact_email ?? ($settings['contact_email'] ?? 'tamilaninstamedia1@gmail.com');
$contact_phone = $contact_phone ?? ($settings['contact_phone'] ?? '8098830937');
$contact_whatsapp = $contact_whatsapp ?? ($settings['contact_whatsapp'] ?? '8098830937');
$contact_hours = $contact_hours ?? ($settings['contact_hours'] ?? 'Mon - Sat: 9:00 AM - 7:00 PM');
$contact_map_iframe = $contact_map_iframe ?? ($settings['contact_map_iframe'] ?? '');

$page_settings = [];
$is_page_active = [];

if (isset($conn)) {
    try {
        // Fetch active page map for navigation guards
        $stmtPages = $conn->query("SELECT page_slug, is_active FROM pages");
        if ($stmtPages) {
            while ($pRow = $stmtPages->fetch(PDO::FETCH_ASSOC)) {
                $is_page_active[$pRow['page_slug']] = (int) $pRow['is_active'];
            }
        }

        // Fetch SEO & Page settings for current page script
        $current_script = basename($_SERVER['SCRIPT_NAME'] ?? '');
        if (!empty($current_script)) {
            $stmtCurr = $conn->prepare("SELECT * FROM pages WHERE page_slug = ? LIMIT 1");
            $stmtCurr->execute([$current_script]);
            $page_settings = $stmtCurr->fetch(PDO::FETCH_ASSOC) ?: [];
        }
    } catch (Exception $e) {
        error_log("[Header] Page settings fetch error: " . $e->getMessage());
    }
}

// Function to check if page is active
if (!function_exists('isActivePage')) {
    function isActivePage($slug) {
        global $is_page_active;
        return isset($is_page_active[$slug]) ? $is_page_active[$slug] === 1 : true;
    }
}

// Function to display site name dynamically
if (!function_exists('displaySiteName')) {
    function displaySiteName() {
        global $site_name;
        echo htmlspecialchars($site_name);
    }
}

// Base URL auto-detect (with proxy / ngrok / SSL / subfolder support)
$protocol = 'http';
if (
    (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') ||
    (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
    (!empty($_SERVER['HTTP_X_FORWARDED_SSL']) && strtolower($_SERVER['HTTP_X_FORWARDED_SSL']) === 'on') ||
    (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
) {
    $protocol = 'https';
}
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$script_dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
$subfolder = ($script_dir === '/' || $script_dir === '.') ? '' : rtrim($script_dir, '/');
if (preg_match('#^(.*?)/(admin|api|app)(?:/|$)#', $subfolder, $m)) {
    $subfolder = $m[1];
}
$base_url = $protocol . '://' . $host . $subfolder;

// Page title
$display_title = $page_settings['seo_title'] ?? ($page_settings['page_title'] ?? (isset($pageTitle) ? $pageTitle : $site_name));
$display_desc = $page_settings['meta_description'] ?? (isset($pageDesc) ? $pageDesc : 'Best digital marketing agency in Pudhucherry');
?>

<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">

 <!-- PERFORMANCE: Viewport with viewport-fit for notch support -->
 <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">

 <!-- PERFORMANCE: Preconnect to all external origins -->
 <link rel="preconnect" href="https://fonts.googleapis.com">
 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
 <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>

 <!-- DNS prefetch -->
 <link rel="dns-prefetch" href="//cdnjs.cloudflare.com">
 <title><?= htmlspecialchars($display_title) ?></title>
 <meta name="description" content="<?= htmlspecialchars($display_desc) ?>">
 <?php if (!empty($page_settings['meta_keywords'])): ?>
 <meta name="keywords" content="<?= htmlspecialchars($page_settings['meta_keywords']) ?>">
 <?php endif; ?>

 <meta name="robots" content="<?= htmlspecialchars($page_settings['robots_meta'] ?? 'index, follow') ?>">

 <?php if (!empty($page_settings['canonical_url'])): ?>
 <link rel="canonical" href="<?= htmlspecialchars($page_settings['canonical_url']) ?>">
 <?php endif; ?>

 <!-- Open Graph -->
 <?php if (!empty($page_settings['og_title'])): ?>
 <meta property="og:title" content="<?= htmlspecialchars($page_settings['og_title']) ?>">
 <?php endif; ?>
 <?php if (!empty($page_settings['og_description'])): ?>
 <meta property="og:description" content="<?= htmlspecialchars($page_settings['og_description']) ?>">
 <?php endif; ?>
 <?php if (!empty($page_settings['og_image'])): ?>
 <meta property="og:image" content="<?= htmlspecialchars($page_settings['og_image']) ?>">
 <?php endif; ?>

 <!-- Favicon -->
 <?php if ($site_favicon): ?>
 <link rel="icon" type="image/png" href="<?= $base_url ?>/<?= htmlspecialchars(ltrim($site_favicon, '/')) ?>">
 <?php endif; ?>

 <!-- Fonts & Stylesheets -->
 <link rel="preconnect" href="https://fonts.googleapis.com">
 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
 <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
 <link rel="stylesheet" href="<?= $base_url ?>/assets/css/style.css?v=2.0">
 <link rel="stylesheet" href="<?= $base_url ?>/assets/css/intro.css?v=1.0">

	<!-- CRITICAL: Inline CSS for above-the-fold content to prevent FOUC -->
	<style>
		*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
		html{scroll-behavior:smooth}
		body{font-family:'Plus Jakarta Sans','Inter',system-ui,-apple-system,sans-serif;line-height:1.6;overflow-x:hidden;-webkit-font-smoothing:antialiased;background:#F8FAFC;color:#0F172A}
		img{display:block;max-width:100%;height:auto}
		.header{position:fixed;top:0;left:0;right:0;height:76px;background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-bottom:1px solid rgba(99,102,241,0.08);z-index:1000;transition:all 0.3s cubic-bezier(0.16,1,0.3,1)}
		.header.scrolled{background:rgba(255,255,255,0.96);box-shadow:0 10px 30px -10px rgba(15,23,42,0.08);border-bottom-color:rgba(99,102,241,0.15)}
		.container{max-width:1240px;margin:0 auto;padding:0 24px}
		@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:0.01ms!important;transition-duration:0.01ms!important;scroll-behavior:auto!important}}
	</style>

	<?php if (!empty($page_settings['custom_css'])): ?>
	<style><?= $page_settings['custom_css'] ?></style>
	<?php endif; ?>

	<?php if (!empty($page_settings['schema_markup'])): ?>
	<?= $page_settings['schema_markup'] ?>
	<?php endif; ?>
</head>

<body>
	<!-- PERFORMANCE: Skip link for accessibility (appears on focus) -->
	<a href="#main-content"
		style="position:absolute;top:-40px;left:0;background:#6C3BFF;color:#fff;padding:8px 16px;z-index:10000;transition:top 0.3s"
		onfocus="this.style.top='0'"
		onblur="this.style.top='-40px'">
		Skip to main content
	</a>

 <header class="header" id="header">
 <div class="container">
 <a href="<?= $base_url ?>/" class="logo">
 <?php if ($site_logo): ?>
 <img src="<?= $base_url ?>/<?= htmlspecialchars($site_logo) ?>" alt="<?= htmlspecialchars($site_name) ?>" style="max-height:100px;width:auto;display:inline-block;">
 <?php else: ?>
 <span class="logo-text"><?= htmlspecialchars(explode(' ', $site_name)[0]) ?></span>
 <span class="logo-accent"><?= htmlspecialchars(trim(substr($site_name, strpos($site_name, ' ')))) ?></span>
 <?php endif; ?>
 </a>

 <nav class="nav">
 <?php $cp = basename($_SERVER["PHP_SELF"]); ?>
 <?php if (isActivePage('index.php') || isActivePage('home.php')): ?>
 <a href="<?= $base_url ?>/" class="<?= in_array($cp, ['index.php','home.php']) ? 'active' : '' ?>">Home</a>
 <?php endif; ?>
 <?php if (isActivePage('services.php')): ?>
 <a href="<?= $base_url ?>/services" class="<?= $cp == 'services.php' ? 'active' : '' ?>">Services</a>
 <?php endif; ?>

 <?php if (isActivePage('projects.php')): ?>
 <a href="<?= $base_url ?>/projects" class="<?= $cp == 'projects.php' ? 'active' : '' ?>">Projects</a>
 <?php endif; ?>

 <?php if (isActivePage('reviews.php') || isActivePage('testimonials.php') || isActivePage('why-choose-us.php')): ?>
 <div class="dropdown">
 <a href="#" class="<?= in_array($cp, ['reviews.php','testimonials.php','why-choose-us.php']) ? 'active' : '' ?>">Company <i class="fas fa-chevron-down" style="font-size:10px;"></i></a>
 <div class="dropdown-content">
 <?php if (isActivePage('why-choose-us.php')): ?>
 <a href="<?= $base_url ?>/why-choose-us">Why Choose Us</a>
 <?php endif; ?>
 <?php if (isActivePage('reviews.php')): ?>
 <a href="<?= $base_url ?>/reviews">Reviews</a>
 <?php endif; ?>
 <?php if (isActivePage('testimonials.php')): ?>
 <a href="<?= $base_url ?>/testimonials">Testimonials</a>
 <?php endif; ?>
 </div>
 </div>
 <?php endif; ?>

 <?php if (isActivePage('privacy-policy.php') || isActivePage('terms.php') || isActivePage('refund-policy.php')): ?>
 <div class="dropdown">
 <a href="#" class="<?= in_array($cp, ['privacy-policy.php','terms.php','refund-policy.php']) ? 'active' : '' ?>">Legal <i class="fas fa-chevron-down" style="font-size:10px;"></i></a>
 <div class="dropdown-content">
 <?php if (isActivePage('privacy-policy.php')): ?>
 <a href="<?= $base_url ?>/privacy-policy">Privacy Policy</a>
 <?php endif; ?>
 <?php if (isActivePage('terms.php')): ?>
 <a href="<?= $base_url ?>/terms">Terms</a>
 <?php endif; ?>
 <?php if (isActivePage('refund-policy.php')): ?>
 <a href="<?= $base_url ?>/refund-policy">Refund Policy</a>
 <?php endif; ?>
 </div>
 </div>
 <?php endif; ?>

 <?php if (isActivePage('contact.php')): ?>
 <a href="<?= $base_url ?>/contact" class="<?= $cp == 'contact.php' ? 'active' : '' ?>">Contact</a>
 <?php endif; ?>
 </nav>

 <a href="<?= $base_url ?>/contact" class="header-cta">Get Free Consultation</a>
 <button class="menu-toggle" id="menuToggle" aria-label="Menu">
 <span></span><span></span><span></span>
 </button>
 </div>
 </header>

 <div class="sidebar-overlay" id="sidebarOverlay"></div>
 <aside class="sidebar" id="sidebar">
 <button class="sidebar-close" id="sidebarClose">&times;</button>
 <nav class="sidebar-nav">
 <?php if (isActivePage('index.php') || isActivePage('home.php')): ?>
 <a href="<?= $base_url ?>/" class="<?= in_array($cp, ['index.php','home.php']) ? 'active' : '' ?>">Home</a>
 <?php endif; ?>
 <?php if (isActivePage('services.php')): ?>
 <a href="<?= $base_url ?>/services">Services</a>
 <?php endif; ?>



 <?php if (isActivePage('projects.php')): ?>
 <a href="<?= $base_url ?>/projects">Projects</a>
 <?php endif; ?>
 <?php if (isActivePage('why-choose-us.php')): ?>
 <a href="<?= $base_url ?>/why-choose-us">Why Choose Us</a>
 <?php endif; ?>
 <?php if (isActivePage('reviews.php')): ?>
 <a href="<?= $base_url ?>/reviews">Reviews</a>
 <?php endif; ?>
 <?php if (isActivePage('testimonials.php')): ?>
 <a href="<?= $base_url ?>/testimonials">Testimonials</a>
 <?php endif; ?>
 <?php if (isActivePage('privacy-policy.php')): ?>
 <a href="<?= $base_url ?>/privacy-policy">Privacy Policy</a>
 <?php endif; ?>
 <?php if (isActivePage('terms.php')): ?>
 <a href="<?= $base_url ?>/terms">Terms</a>
 <?php endif; ?>
 <?php if (isActivePage('refund-policy.php')): ?>
 <a href="<?= $base_url ?>/refund-policy">Refund Policy</a>
 <?php endif; ?>
 <?php if (isActivePage('contact.php')): ?>
 <a href="<?= $base_url ?>/contact">Contact Us</a>
 <?php endif; ?>
 </nav>
 </aside>