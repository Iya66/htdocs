<?php
/**
 * Cloud Aspire - Premium Opening / Welcome Animation Component
 * Pure PHP + HTML + CSS | Zero JavaScript
 * 
 * Usage:
 *   include 'includes/intro.php';
 */

// Prevent duplicate execution on the same page
if (defined('CLOUD_ASPIRE_INTRO_RENDERED')) {
    return;
}
define('CLOUD_ASPIRE_INTRO_RENDERED', true);

// Dynamic site parameters with fallback
$intro_site_name = !empty($site_name) ? $site_name : 'Cloud Aspire';
$intro_site_logo = !empty($site_logo) ? $site_logo : '';
$intro_base_url  = isset($base_url) ? $base_url : '';
?>

<!-- Cloud Aspire Intro Stylesheet -->
<link rel="stylesheet" href="/assets/css/intro.css?v=1.0">

<!-- Full-Screen Intro Animation Overlay -->
<div id="ca-intro-overlay" aria-hidden="true">
    <!-- Ambient Background Lighting Aura -->
    <div class="ca-intro-bg-glow"></div>
    
    <!-- Tech Grid Subtle Overlay -->
    <div class="ca-intro-grid"></div>

    <!-- Top Shimmer Ray -->
    <div class="ca-intro-shimmer-ray"></div>

    <!-- Ambient Floating Tech Particles (Pure CSS) -->
    <div class="ca-particle ca-p1"></div>
    <div class="ca-particle ca-p2"></div>
    <div class="ca-particle ca-p3"></div>
    <div class="ca-particle ca-p4"></div>
    <div class="ca-particle ca-p5"></div>

    <!-- Center Intro Content -->
    <div class="ca-intro-content">
        
        <!-- Step 1: Cloud Aspire Brand Logo (Fade + Scale) -->
        <div class="ca-intro-brand">
            <?php if (!empty($intro_site_logo)): ?>
                <div class="ca-intro-logo-badge">
                    <img src="/<?= htmlspecialchars(ltrim($intro_site_logo, '/')) ?>" 
                         alt="<?= htmlspecialchars($intro_site_name) ?>" 
                         class="ca-intro-logo-img">
                </div>
            <?php else: ?>
                <div class="ca-intro-logo-icon">
                    <svg viewBox="0 0 72 72" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                            <linearGradient id="caCloudGrad" x1="6" y1="12" x2="66" y2="60" gradientUnits="userSpaceOnUse">
                                <stop offset="0%" stop-color="#6C3BFF"/>
                                <stop offset="50%" stop-color="#4F46E5"/>
                                <stop offset="100%" stop-color="#38BDF8"/>
                            </linearGradient>
                            <linearGradient id="caCoreGrad" x1="24" y1="20" x2="48" y2="52" gradientUnits="userSpaceOnUse">
                                <stop offset="0%" stop-color="#A78BFA"/>
                                <stop offset="100%" stop-color="#60A5FA"/>
                            </linearGradient>
                            <filter id="caGlowFilter" x="-20%" y="-20%" width="140%" height="140%">
                                <feGaussianBlur stdDeviation="3" result="blur"/>
                                <feComposite in="SourceGraphic" in2="blur" operator="over"/>
                            </filter>
                        </defs>
                        <!-- Stylized Geometric Cloud Node -->
                        <path d="M52 48H22C15.3726 48 10 42.6274 10 36C10 29.7431 14.7797 24.6025 20.9022 24.0544C22.6865 17.0673 28.9839 12 36.5 12C45.3855 12 52.6896 18.8924 53.4276 27.6033C58.3377 28.5146 62 32.8251 62 38C62 43.5228 57.5228 48 52 48Z" 
                              fill="url(#caCloudGrad)" 
                              fill-opacity="0.22" 
                              stroke="url(#caCloudGrad)" 
                              stroke-width="2.5" 
                              stroke-linejoin="round"/>
                        <!-- Central Aspirational Apex -->
                        <path d="M36 22L45 37H27L36 22Z" 
                              fill="url(#caCoreGrad)" 
                              filter="url(#caGlowFilter)"/>
                        <circle cx="36" cy="41" r="2.5" fill="#FFFFFF"/>
                    </svg>
                </div>
                <div class="ca-intro-brand-title">
                    <span>Cloud</span>
                    <span class="accent">Aspire</span>
                </div>
            <?php endif; ?>
        </div>

        <!-- Step 2: Welcome Heading -->
        <h1 class="ca-intro-welcome">
            Welcome to <span class="highlight"><?= htmlspecialchars($intro_site_name) ?></span>
        </h1>

        <!-- Step 3: Tagline -->
        <p class="ca-intro-tagline">
            <span>Building Digital Experiences.</span>
            <span class="ca-intro-tagline-separator">•</span>
            <span>Growing Businesses.</span>
        </p>

    </div>

    <!-- Step 4: Thin Elegant Loading / Progress Line at Bottom -->
    <div class="ca-intro-progress-track">
        <div class="ca-intro-progress-bar"></div>
    </div>
</div>
