<?php
require_once __DIR__ . '/../../../admin/includes/header.php';
?>

<style>
.projects-grid { 
    display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 24px; 
}
.project-card { 
    background: var(--bg-card); 
    border: 1px solid var(--border-color); border-radius: var(--border-radius); 
    overflow: hidden; transition: all var(--transition); 
    box-shadow: var(--shadow-sm); 
    display: flex; flex-direction: column;
}
.project-card:hover { 
    transform: translateY(-4px); 
    box-shadow: var(--shadow-md); 
    border-color: color-mix(in srgb, var(--primary) 30%, var(--border-color));
}
.project-thumb { 
    width: 100%; height: 180px; 
    background: color-mix(in srgb, var(--primary) 5%, var(--bg-main)); 
    display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden; 
    border-bottom: 1px solid var(--border-color);
}
.project-thumb img { width: 100%; height: 100%; object-fit: cover; }
.project-thumb i { font-size: 48px; color: var(--text-muted); opacity: 0.3; }
.project-thumb .status-badge { 
    position: absolute; top: 16px; right: 16px; 
    padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; 
    backdrop-filter: blur(10px); 
    border: 1px solid rgba(255,255,255,0.2);
}
.status-pending { background: rgba(245, 158, 11, 0.9); color: #fff; }
.status-running { background: rgba(59, 130, 246, 0.9); color: #fff; }
.status-completed { background: rgba(16, 185, 129, 0.9); color: #fff; }
.status-cancelled { background: rgba(239, 68, 68, 0.9); color: #fff; }

.project-body { padding: 24px; flex: 1; display: flex; flex-direction: column; }
.project-name { font-size: 18px; font-weight: 600; color: var(--text-main); margin-bottom: 12px; letter-spacing: -0.01em; }

.project-meta { display: flex; flex-wrap: wrap; gap: 16px; margin-bottom: 20px; }
.project-meta span { font-size: 13px; color: var(--text-muted); display: flex; align-items: center; gap: 6px; font-weight: 500; }
.project-meta span i { color: var(--primary); }

.project-budget { 
    font-size: 28px; font-weight: 700; color: var(--text-main); 
    margin-bottom: 16px; display: flex; align-items: baseline; gap: 6px;
    letter-spacing: -0.02em;
}
.project-budget small { font-size: 13px; color: var(--text-muted); font-weight: 500; }

.project-link { font-size: 13px; color: var(--primary); margin-bottom: 20px; display: flex; align-items: center; gap: 6px; text-decoration: none; font-weight: 500; }
.project-link:hover { text-decoration: underline; }

.project-actions { 
    display: flex; gap: 8px; padding-top: 20px; 
    border-top: 1px solid var(--border-color); margin-top: auto;
}
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
@media (max-width: 992px) { .form-row { grid-template-columns: 1fr; gap: 16px; } }
</style>

<div class="saas-page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-diagram-project" style="color: var(--primary);"></i> Projects Management</h1>
        <p class="page-subtitle">Track project lifecycles, budgets, deadlines, and client deliverables.</p>
    </div>
    <div class="header-actions">
        <button class="btn btn-primary" onclick="openModal()"><i class="fas fa-plus"></i> Add Project</button>
    </div>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?= $message_type ?>">
        <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i> 
        <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<div class="projects-grid">
    <?php foreach ($projects as $project): ?>
    <div class="project-card">
        <div class="project-thumb">
            <?php if (!empty($project['thumbnail'])): ?>
                <img src="<?= htmlspecialchars($project['thumbnail']) ?>" alt="">
            <?php else: ?>
                <i class="fas fa-diagram-project"></i>
            <?php endif; ?>
            <span class="status-badge status-<?= htmlspecialchars($project['status'] ?? 'pending') ?>"><?= ucfirst(htmlspecialchars($project['status'] ?? 'pending')) ?></span>
        </div>
        <div class="project-body">
            <div style="display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px;">
                <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; background: rgba(108, 59, 255, 0.08); color: var(--primary); padding: 2px 8px; border-radius: 12px;"><?= htmlspecialchars(strtoupper($project['category'] ?? 'WEB')) ?></span>
                <span style="font-size: 11px; font-weight: 600; background: var(--bg-main); color: var(--text-muted); padding: 2px 8px; border-radius: 12px; border: 1px solid var(--border-color);"><?= htmlspecialchars($project['industry'] ?? 'Digital') ?></span>
            </div>
            <div class="project-name"><?= htmlspecialchars($project['project_name']) ?></div>
            
            <?php if (!empty($project['description'])): ?>
                <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 12px; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;"><?= htmlspecialchars($project['description']) ?></p>
            <?php endif; ?>

            <?php if (!empty($project['results'])): ?>
                <div style="font-size: 12px; color: var(--success); font-weight: 600; margin-bottom: 12px; display: flex; align-items: center; gap: 5px;">
                    <i class="fas fa-chart-line"></i> <?= htmlspecialchars($project['results']) ?>
                </div>
            <?php endif; ?>

            <div class="project-meta">
                <span><i class="fas fa-calendar"></i> <?= !empty($project['project_datetime']) ? date('M d, Y', strtotime($project['project_datetime'])) : 'N/A' ?></span>
                <?php if (!empty($project['client_name'])): ?>
                    <span><i class="fas fa-building"></i> <?= htmlspecialchars($project['client_name']) ?></span>
                <?php endif; ?>
            </div>
            <div class="project-budget">₹<?= number_format((float)($project['budget'] ?? 0)) ?><small>Budget</small></div>
            <?php if (!empty($project['project_link'])): ?>
                <a href="<?= htmlspecialchars($project['project_link']) ?>" target="_blank" class="project-link"><i class="fas fa-link"></i> External Link</a>
            <?php endif; ?>
            <div class="project-actions">
                <button class="btn btn-sm btn-edit" onclick="editProject(<?= htmlspecialchars(json_encode($project)) ?>)" style="flex: 1; justify-content: center;"><i class="fas fa-edit"></i> Edit</button>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this project permanently?')">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $project['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-delete" title="Delete"><i class="fas fa-trash"></i></button>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    
    <?php if (empty($projects)): ?>
    <div style="grid-column: 1/-1; text-align:center; padding:80px 20px; background: var(--bg-card); border-radius: var(--border-radius); border: 1px dashed var(--border-color);">
        <div style="width: 64px; height: 64px; background: var(--bg-main); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
            <i class="fas fa-diagram-project" style="font-size: 24px; color: var(--text-muted);"></i>
        </div>
        <h3 style="font-size: 18px; color: var(--text-main); margin-bottom: 8px;">No projects added</h3>
        <p style="color: var(--text-muted); font-size: 15px; margin-bottom: 24px;">Start tracking your projects and displaying your portfolio.</p>
        <button class="btn btn-primary" onclick="openModal()"><i class="fas fa-plus"></i> Add First Project</button>
    </div>
    <?php endif; ?>
</div>

<div class="modal" id="projectModal">
    <div class="modal-content" style="max-width: 680px;">
        <div class="modal-header">
            <h3 class="modal-title"><i class="fas fa-diagram-project"></i> <span id="modalTitle">Add New Project</span></h3>
            <button type="button" class="modal-close" onclick="closeModal()" aria-label="Close modal">&times;</button>
        </div>
        <form method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="projectId">
                <div class="form-group">
                    <label for="projectName"><i class="fas fa-tag"></i> Project Name <span class="text-danger">*</span></label>
                    <input type="text" name="project_name" id="projectName" required class="form-control" placeholder="e.g. E-Commerce SEO & Conversion">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="projectCategory"><i class="fas fa-filter"></i> Category <span class="text-danger">*</span></label>
                        <select name="category" id="projectCategory" class="form-control" required>
                            <option value="seo">SEO</option>
                            <option value="social">Social Media</option>
                            <option value="ads">Paid Ads</option>
                            <option value="web" selected>Website</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="projectIndustry"><i class="fas fa-industry"></i> Industry</label>
                        <input type="text" name="industry" id="projectIndustry" class="form-control" placeholder="e.g. E-Commerce, Healthcare, Real Estate">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="projectBudget"><i class="fas fa-rupee-sign"></i> Budget (₹) <span class="text-danger">*</span></label>
                        <input type="text" name="budget" id="projectBudget" required class="form-control" placeholder="e.g. 75000">
                    </div>
                    <div class="form-group">
                        <label for="projectStatus"><i class="fas fa-toggle-on"></i> Status</label>
                        <select name="status" id="projectStatus" class="form-control">
                            <option value="pending">Pending</option>
                            <option value="running">Running</option>
                            <option value="completed" selected>Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="projectClient"><i class="fas fa-building"></i> Client / Brand Name</label>
                        <input type="text" name="client_name" id="projectClient" class="form-control" placeholder="e.g. Acme Corporation">
                    </div>
                    <div class="form-group">
                        <label for="projectResults"><i class="fas fa-trophy"></i> Key Result / Metric</label>
                        <input type="text" name="results" id="projectResults" class="form-control" placeholder="e.g. 300% Traffic Growth (5x ROAS)">
                    </div>
                </div>
                <div class="form-group">
                    <label for="projectDescription"><i class="fas fa-align-left"></i> Description</label>
                    <textarea name="description" id="projectDescription" class="form-control" rows="3" placeholder="Brief project summary, deliverables, or case study overview..."></textarea>
                </div>
                <div class="form-group">
                    <label for="projectDatetime"><i class="fas fa-calendar"></i> Project Date & Time <span class="text-danger">*</span></label>
                    <input type="datetime-local" name="project_datetime" id="projectDatetime" required class="form-control">
                </div>
                <div class="form-group">
                    <label for="projectLink"><i class="fas fa-link"></i> Project Link</label>
                    <input type="url" name="project_link" id="projectLink" placeholder="https://example.com or /contact" class="form-control">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-upload"></i> Upload Thumbnail (JPG, PNG, WEBP, SVG)</label>
                    <input type="file" name="thumbnail_file" accept=".jpg,.jpeg,.png,.gif,.webp,.svg" class="form-control" style="cursor: pointer;">
                    <label style="margin-top: 10px;"><i class="fas fa-image"></i> Or Thumbnail URL</label>
                    <input type="url" name="thumbnail" id="projectThumb" placeholder="https://example.com/image.jpg" class="form-control">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()"><i class="fas fa-times"></i> Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Project</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('modalTitle').textContent = 'Add New Project';
    document.getElementById('formAction').value = 'create';
    document.getElementById('projectId').value = '';
    document.getElementById('projectName').value = '';
    document.getElementById('projectCategory').value = 'web';
    document.getElementById('projectIndustry').value = '';
    document.getElementById('projectBudget').value = '';
    document.getElementById('projectClient').value = '';
    document.getElementById('projectResults').value = '';
    document.getElementById('projectDescription').value = '';
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('projectDatetime').value = now.toISOString().slice(0, 16);
    document.getElementById('projectLink').value = '';
    document.getElementById('projectThumb').value = '';
    document.getElementById('projectStatus').value = 'completed';
    document.getElementById('projectModal').classList.add('active');
}
function editProject(p) {
    document.getElementById('modalTitle').textContent = 'Edit Project';
    document.getElementById('formAction').value = 'update';
    document.getElementById('projectId').value = p.id;
    document.getElementById('projectName').value = p.project_name || '';
    document.getElementById('projectCategory').value = p.category || 'web';
    document.getElementById('projectIndustry').value = p.industry || '';
    document.getElementById('projectBudget').value = p.budget || '';
    document.getElementById('projectClient').value = p.client_name || '';
    document.getElementById('projectResults').value = p.results || '';
    document.getElementById('projectDescription').value = p.description || '';
    document.getElementById('projectDatetime').value = p.project_datetime ? p.project_datetime.replace(' ', 'T').slice(0, 16) : '';
    document.getElementById('projectLink').value = p.project_link || '';
    document.getElementById('projectThumb').value = p.thumbnail || '';
    document.getElementById('projectStatus').value = p.status || 'completed';
    document.getElementById('projectModal').classList.add('active');
}
function closeModal() { document.getElementById('projectModal').classList.remove('active'); }
window.onclick = function(e) { if (e.target === document.getElementById('projectModal')) closeModal(); }
</script>

<?php require_once __DIR__ . '/../../../admin/includes/footer.php'; ?>