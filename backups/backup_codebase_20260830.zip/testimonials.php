<?php
require_once __DIR__ . '/app/config.php';
$pageTitle = 'Testimonials';
$pageDesc = 'Watch video testimonials and success stories from ' . $site_name . ' clients.';

$testimonials = [];
try {
    $stmt = $conn->query("SELECT * FROM testimonials WHERE status = 'active' ORDER BY created_at DESC");
    $testimonials = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
} catch (PDOException $e) {
    error_log("Error fetching testimonials from database: " . $e->getMessage());
    $testimonials = [];
}

// Fetch dynamic database counts & metrics
$stat_partners = '120+';
$stat_growth = '350%';
$stat_satisfaction = '99%';
$stat_projects = '150+';

try {
    $test_count = count($testimonials);
    $leads_count = (int)$conn->query("SELECT COUNT(*) FROM leads")->fetchColumn();
    $projects_count = (int)$conn->query("SELECT COUNT(*) FROM projects")->fetchColumn();
    
    $partners = max($test_count, $leads_count);
    if ($partners > 0) {
        $stat_partners = $partners . '+';
    }
    
    if ($projects_count > 0) {
        $stat_projects = $projects_count . '+';
    }

    $db_avg_rating = $conn->query("SELECT AVG(star_rating) FROM reviews WHERE status = 'approved' OR status IS NULL")->fetchColumn();
    if ($db_avg_rating !== null && (float)$db_avg_rating > 0) {
        $stat_satisfaction = round(((float)$db_avg_rating / 5) * 100) . '%';
    }
} catch (Exception $e) {
    error_log("Error calculating testimonial stats: " . $e->getMessage());
}

require_once __DIR__ . '/app/Views/frontend/testimonials.php';

