<?php
require_once __DIR__ . '/../../../admin/includes/header.php';
?>

<style>
.contact-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 32px;
}
@media (max-width: 992px) {
    .contact-grid {
        grid-template-columns: 1fr;
    }
}
.map-preview {
    border-radius: var(--border-radius);
    overflow: hidden;
    border: 1px solid var(--border-color);
    background: var(--bg-main);
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 400px;
    width: 100%;
}
.map-preview iframe {
    width: 100%;
    height: 400px;
    border: 0;
    display: block;
}

.settings-card { 
    background: var(--bg-card); 
    border: 1px solid var(--border-color); border-radius: var(--border-radius); 
    padding: 32px; box-shadow: var(--shadow-sm); margin-bottom: 24px; 
}
.settings-card h3 { font-size: 18px; color: var(--text-main); margin-bottom: 8px; display: flex; align-items: center; gap: 12px; }
.settings-card h3 i { color: var(--primary); }

.form-group { margin-bottom: 20px; }
.form-group label { display: block; margin-bottom: 8px; color: var(--text-main); font-weight: 600; font-size: 14px; display: flex; align-items: center; gap: 8px; }
.form-control { 
    width: 100%; padding: 14px 18px; 
    border: 1px solid var(--border-color); border-radius: var(--btn-radius); 
    font-size: 14px; background: var(--bg-main); color: var(--text-main); transition: all var(--transition); 
}
.form-control:focus { outline: none; border-color: var(--primary); }
</style>

<div class="saas-page-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-address-book" style="color: var(--primary);"></i> Contact Us Settings</h1>
        <p class="page-subtitle">Configure contact information, business hours, and Google Maps embed.</p>
    </div>
</div>

<?php if ($msg): ?>
    <div class="alert alert-<?= $type ?>">
        <i class="fas fa-<?= $type === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i> 
        <?= htmlspecialchars($msg) ?>
    </div>
<?php endif; ?>

<div class="contact-grid">
    <div>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            
            <div class="settings-card">
                <h3><i class="fa-solid fa-pen-to-square"></i> Contact Details</h3>
                <p style="color: var(--text-secondary); margin-bottom: 20px; font-size: 13px;">
                    Update the contact information that will be displayed on the user-side contact page.
                </p>

                <div class="form-group">
                    <label>Contact Email</label>
                    <input type="email" name="contact_email" class="form-control" value="<?= htmlspecialchars($contact_email) ?>" placeholder="e.g. support@yourdomain.com" required>
                </div>

                <div class="form-group">
                    <label>Contact Phone</label>
                    <input type="text" name="contact_phone" class="form-control" value="<?= htmlspecialchars($contact_phone) ?>" placeholder="e.g. +1 234 567 8900" required>
                </div>

                <div class="form-group">
                    <label>WhatsApp Number</label>
                    <input type="text" name="contact_whatsapp" class="form-control" value="<?= htmlspecialchars($contact_whatsapp) ?>" placeholder="e.g. +1 234 567 8901" required>
                </div>

                <div class="form-group">
                    <label>Business Hours</label>
                    <input type="text" name="contact_hours" class="form-control" value="<?= htmlspecialchars($contact_hours) ?>" placeholder="e.g. Mon - Sat: 9:00 AM - 7:00 PM" required>
                </div>
            </div>

            <div class="settings-card">
                <h3><i class="fa-solid fa-share-nodes"></i> Social Media Links</h3>
                <p style="color: var(--text-secondary); margin-bottom: 20px; font-size: 13px;">
                    Enable social media icons by providing links to your profiles.
                </p>

                <div class="form-group">
                    <label><i class="fa-brands fa-facebook" style="color: var(--primary);"></i> Facebook URL</label>
                    <input type="url" name="social_facebook" class="form-control" value="<?= htmlspecialchars($social_facebook) ?>" placeholder="https://facebook.com/yourpage">
                </div>

                <div class="form-group">
                    <label><i class="fa-brands fa-instagram" style="color: var(--primary);"></i> Instagram URL</label>
                    <input type="url" name="social_instagram" class="form-control" value="<?= htmlspecialchars($social_instagram) ?>" placeholder="https://instagram.com/yourprofile">
                </div>

                <div class="form-group">
                    <label><i class="fa-brands fa-x-twitter" style="color: var(--primary);"></i> Twitter / X URL</label>
                    <input type="url" name="social_twitter" class="form-control" value="<?= htmlspecialchars($social_twitter) ?>" placeholder="https://twitter.com/yourhandle">
                </div>

                <div class="form-group">
                    <label><i class="fa-brands fa-linkedin" style="color: var(--primary);"></i> LinkedIn URL</label>
                    <input type="url" name="social_linkedin" class="form-control" value="<?= htmlspecialchars($social_linkedin) ?>" placeholder="https://linkedin.com/in/yourprofile">
                </div>
            </div>

            <div class="settings-card">
                <h3><i class="fa-solid fa-map-location-dot"></i> Google Maps Location</h3>
                <p style="color: var(--text-secondary); margin-bottom: 20px; font-size: 13px;">
                    Enter your location name or address. The system will automatically fetch the map and update your settings.
                </p>
                
                <div class="form-group">
                    <label>Map Location / Address</label>
                    <input type="text" id="mapLocationInput" class="form-control" value="<?= htmlspecialchars($current_location) ?>" placeholder="e.g. New York, NY, USA">
                </div>

                <!-- Hidden textarea to store the generated iframe code for submission -->
                <textarea name="contact_map_iframe" id="mapIframeInput" style="display: none;"><?= htmlspecialchars($contact_map_iframe) ?></textarea>

                <button type="submit" name="save_contact" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Save Contact Settings
                </button>
            </div>
        </form>
    </div>

    <!-- PREVIEW PANEL -->
    <div>
        <div style="position: sticky; top: 20px;">
            <div class="settings-card">
                <h3><i class="fa-solid fa-eye"></i> Map Preview</h3>
                <p style="color: var(--text-secondary); margin-bottom: 20px; font-size: 13px;">
                    Real-time preview of how the map will appear on the front end.
                </p>
                <div class="map-preview" id="mapPreviewBox">
                    <?php 
                    // Basic security check: Only allow true iframes with Google Maps embed URLs
                    if (strpos($contact_map_iframe, '<iframe') !== false && (strpos($contact_map_iframe, 'google.com/maps/embed') !== false || strpos($contact_map_iframe, 'maps.google.com/maps') !== false) && !preg_match('/<script/i', $contact_map_iframe)): 
                        echo $contact_map_iframe;
                    ?>
                    <?php else: ?>
                        <div style="color: var(--text-muted); text-align: center;">
                            <i class="fa-solid fa-map" style="font-size: 40px; margin-bottom: 15px;"></i><br>
                            Invalid or missing location. Please enter a valid address.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Real-time Map Preview Auto-fetching
(function() {
    const locationInput = document.getElementById('mapLocationInput');
    const iframeTextarea = document.getElementById('mapIframeInput');
    const previewBox = document.getElementById('mapPreviewBox');

    function updateMapPreview(location) {
        const trimmed = location.trim();
        if (trimmed) {
            const iframeSrc = `https://maps.google.com/maps?q=${encodeURIComponent(trimmed)}&t=&z=13&ie=UTF8&iwloc=&output=embed`;
            const iframeHTML = `<iframe src="${iframeSrc}" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>`;
            
            iframeTextarea.value = iframeHTML;
            previewBox.innerHTML = iframeHTML;
        } else {
            iframeTextarea.value = '';
            previewBox.innerHTML = `
                <div style="color: var(--text-muted); text-align: center;">
                    <i class="fa-solid fa-map" style="font-size: 40px; margin-bottom: 15px;"></i><br>
                    Please enter a location/address to preview map.
                </div>
            `;
        }
    }

    // Debounce the map loading to prevent firing requests on every keystroke
    let debounceTimer;
    locationInput.addEventListener('input', function(e) {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            updateMapPreview(e.target.value);
        }, 500);
    });

    // Initialize map on load if not already matching standard query format
    if (locationInput.value.trim() && !iframeTextarea.value.trim()) {
        updateMapPreview(locationInput.value);
    }
})();
</script>

<?php require_once __DIR__ . '/../../../admin/includes/footer.php'; ?>
