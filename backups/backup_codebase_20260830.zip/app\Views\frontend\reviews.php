<?php 
$reviews = $reviews ?? [];
$site_name = $site_name ?? 'Cloud Aspire';
$avg_rating_display = $avg_rating_display ?? '4.9';
$stat_clients = $stat_clients ?? 120;
$stat_satisfaction = $stat_satisfaction ?? '98%';
$msg_status = $msg_status ?? '';
$msg_text = $msg_text ?? '';
$csrf_token = $csrf_token ?? '';
?>
<?php include __DIR__ . '/../../../includes/header.php'; ?>

<style>
    .reviews-metrics {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 24px;
        margin-bottom: 50px;
    }

    .review-card {
        background: #FFFFFF;
        border: 1px solid var(--border-light, rgba(0, 0, 0, 0.08));
        border-radius: var(--r, 16px);
        padding: 34px 28px;
        transition: var(--transition, all 0.3s ease);
        box-shadow: var(--shadow-sm, 0 2px 8px rgba(0, 0, 0, 0.04));
        display: flex;
        flex-direction: column;
        position: relative;
    }

    .review-card:hover {
        box-shadow: 0 16px 40px rgba(108, 59, 255, 0.14);
        transform: translateY(-6px);
        border-color: rgba(108, 59, 255, 0.25);
    }

    .quote-badge {
        position: absolute;
        top: 24px;
        right: 24px;
        font-size: 2rem;
        color: var(--primary, #6C3BFF);
        opacity: 0.12;
    }

    .review-card .stars {
        color: #F59E0B;
        font-size: 1.15rem;
        margin-bottom: 16px;
        letter-spacing: 2px;
    }

    .review-card .text {
        color: var(--text2, #475569);
        font-size: 0.98rem;
        line-height: 1.75;
        margin-bottom: 24px;
        font-style: italic;
        flex-grow: 1;
    }

    .review-verified-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 0.76rem;
        color: var(--success, #10B981);
        font-weight: 600;
        margin-top: 2px;
    }

    /* ── USER SIDE REVIEW BOX ── */
    .write-review-section {
        margin-top: 70px;
        padding-top: 20px;
    }

    .review-box-card {
        background: linear-gradient(180deg, #ffffff 0%, #fbfbfe 100%);
        border: 1px solid rgba(108, 59, 255, 0.15);
        border-radius: var(--r, 20px);
        padding: 44px 40px;
        box-shadow: 0 20px 50px rgba(108, 59, 255, 0.08);
        position: relative;
        overflow: hidden;
    }

    .review-box-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #6C3BFF 0%, #3B82F6 50%, #10B981 100%);
    }

    .review-box-header {
        text-align: center;
        max-width: 620px;
        margin: 0 auto 36px;
    }

    .review-box-header .badge-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(108, 59, 255, 0.08);
        color: var(--primary, #6C3BFF);
        padding: 6px 16px;
        border-radius: 50px;
        font-size: 0.82rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        margin-bottom: 12px;
    }

    .review-box-header h2 {
        font-size: 1.85rem;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 8px;
        letter-spacing: -0.02em;
    }

    .review-box-header p {
        color: var(--text2, #64748b);
        font-size: 0.95rem;
        line-height: 1.6;
        margin: 0;
    }

    .review-form-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
    }

    .review-form-full {
        grid-column: 1 / -1;
    }

    .custom-input-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .custom-input-group label {
        font-size: 0.88rem;
        font-weight: 600;
        color: #1e293b;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .custom-input-group label span.req {
        color: #ef4444;
    }

    .custom-input-group .helper-text {
        font-size: 0.78rem;
        color: #64748b;
        margin-top: 2px;
    }

    .custom-input-wrap {
        position: relative;
    }

    .custom-input-wrap i.input-icon {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: #94a3b8;
        font-size: 0.95rem;
        pointer-events: none;
        transition: color 0.2s;
    }

    .custom-input-wrap textarea + i.input-icon,
    .custom-input-wrap.textarea-wrap i.input-icon {
        top: 18px;
        transform: none;
    }

    .custom-form-control {
        width: 100%;
        padding: 12px 16px 12px 42px;
        border: 1.5px solid #e2e8f0;
        border-radius: 10px;
        font-size: 0.94rem;
        color: #0f172a;
        background: #ffffff;
        transition: all 0.2s ease;
        outline: none;
        box-sizing: border-box;
        font-family: inherit;
    }

    .custom-form-control:focus {
        border-color: var(--primary, #6C3BFF);
        box-shadow: 0 0 0 3.5px rgba(108, 59, 255, 0.12);
    }

    .custom-input-wrap:focus-within i.input-icon {
        color: var(--primary, #6C3BFF);
    }

    /* ── STAR RATING SELECTOR ── */
    .star-picker-container {
        background: #ffffff;
        border: 1.5px solid #e2e8f0;
        border-radius: 12px;
        padding: 16px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 12px;
        transition: border-color 0.2s;
    }

    .star-picker-container:hover {
        border-color: rgba(108, 59, 255, 0.3);
    }

    .interactive-star-group {
        display: inline-flex;
        flex-direction: row-reverse;
        gap: 6px;
    }

    .interactive-star-group input {
        display: none;
    }

    .interactive-star-group label {
        font-size: 28px;
        color: #cbd5e1;
        cursor: pointer;
        transition: all 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        user-select: none;
        padding: 0 2px;
    }

    .interactive-star-group label:hover,
    .interactive-star-group label:hover ~ label,
    .interactive-star-group input:checked ~ label {
        color: #f59e0b;
        transform: scale(1.18);
        text-shadow: 0 2px 10px rgba(245, 158, 11, 0.35);
    }

    .star-rating-label {
        font-size: 0.9rem;
        font-weight: 700;
        color: #92400e;
        background: #fef3c7;
        padding: 4px 12px;
        border-radius: 20px;
        border: 1px solid #fde68a;
    }

    /* ── SUBMIT BUTTON ── */
    .review-submit-btn {
        background: linear-gradient(135deg, #6C3BFF 0%, #4F46E5 100%);
        color: #ffffff;
        border: none;
        border-radius: 10px;
        padding: 14px 34px;
        font-size: 1rem;
        font-weight: 700;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        box-shadow: 0 8px 20px rgba(108, 59, 255, 0.25);
        transition: all 0.25s ease;
        width: 100%;
    }

    .review-submit-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 28px rgba(108, 59, 255, 0.35);
        color: #ffffff;
    }

    .review-submit-btn:disabled {
        opacity: 0.65;
        cursor: not-allowed;
        transform: none;
    }

    /* ── ALERT STYLES ── */
    .review-alert {
        padding: 16px 20px;
        border-radius: 12px;
        margin-bottom: 24px;
        display: flex;
        align-items: flex-start;
        gap: 12px;
        font-size: 0.95rem;
        line-height: 1.5;
        animation: fadeInDown 0.3s ease;
    }

    .review-alert.alert-success {
        background: #f0fdf4;
        border: 1px solid #bbf7d0;
        color: #166534;
    }

    .review-alert.alert-error {
        background: #fef2f2;
        border: 1px solid #fecaca;
        color: #991b1b;
    }

    .review-alert i {
        font-size: 1.2rem;
        margin-top: 2px;
        flex-shrink: 0;
    }

    .review-alert-success i {
        color: #16a34a;
    }

    .review-alert-error i {
        color: #dc2626;
    }

    .success-celebration {
        text-align: center;
        padding: 30px 20px;
        background: #f0fdf4;
        border: 1px solid #bbf7d0;
        border-radius: 16px;
        animation: fadeInUp 0.4s ease;
    }

    .success-icon-wrap {
        width: 68px;
        height: 68px;
        background: #dcfce7;
        color: #16a34a;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
        margin-bottom: 16px;
        box-shadow: 0 8px 20px rgba(22, 163, 74, 0.15);
    }

    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(12px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeInDown {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 992px) {
        .reviews-metrics {
            grid-template-columns: repeat(2, 1fr);
        }
        .review-box-card {
            padding: 32px 24px;
        }
    }

    @media (max-width: 640px) {
        .reviews-metrics {
            grid-template-columns: 1fr;
        }
        .review-form-grid {
            grid-template-columns: 1fr;
        }
        .review-box-header h2 {
            font-size: 1.5rem;
        }
        .star-picker-container {
            flex-direction: column;
            align-items: flex-start;
        }
    }
</style>

<section class="page-header">
    <div class="container">
        <h1>Client <span class="highlight">Reviews</span></h1>
        <p>Real feedback and verified ratings from businesses we have empowered to grow online</p>
        <div class="breadcrumb"><a href="<?= $base_url ?>/">Home</a> / Reviews</div>
    </div>
</section>

<section class="section">
    <div class="container">
        <!-- Live Metrics -->
        <div class="reviews-metrics">
            <div class="stat-card fade-in">
                <h3 data-count="<?= $avg_rating_display ?>/5">0</h3>
                <p>Average Rating</p>
            </div>
            <div class="stat-card fade-in">
                <h3 data-count="<?= $stat_clients ?>+">0</h3>
                <p>Happy Clients</p>
            </div>
            <div class="stat-card fade-in">
                <h3 data-count="<?= $stat_satisfaction ?>">0</h3>
                <p>Satisfaction Rate</p>
            </div>
            <div class="stat-card fade-in">
                <h3 data-count="<?= $stat_retention ?>">0</h3>
                <p>Positive Feedback</p>
            </div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 28px; flex-wrap: wrap; gap: 16px;">
            <div>
                <h2 style="font-size: 1.6rem; font-weight: 800; color: #0f172a; margin: 0;">Verified Testimonials</h2>
                <p style="color: var(--text2); margin: 4px 0 0 0; font-size: 0.92rem;">Reviews submitted by genuine clients &amp; partners</p>
            </div>
            <a href="#write-review" class="btn btn-primary" style="padding: 10px 22px; font-size: 0.92rem; border-radius: 8px;">
                <i class="fas fa-pen-nib"></i> Write a Review
            </a>
        </div>

        <!-- Reviews Grid -->
        <div class="reviews-grid" id="reviewsGrid">
            <?php 
            $grads = ['#6C3BFF','#4F46E5','#8B5CF6','#7C3AED','#6366F1','#818CF8'];
            if (!empty($reviews)): 
            ?>
                <?php foreach($reviews as $k => $r): 
                    $stars = (int)($r['star_rating'] ?? 5);
                    $reviewer_name = $r['name'] ?? 'Client';
                    $role_parts = array_filter([$r['designation'] ?? '', $r['company'] ?? '']);
                    $role_text = implode(' • ', $role_parts);
                ?>
                <div class="review-card fade-in" id="review-<?= (int)$r['id'] ?>">
                    <i class="fas fa-quote-right quote-badge"></i>
                    <div class="stars"><?= str_repeat('★', $stars) . str_repeat('☆', max(0, 5 - $stars)) ?></div>
                    <p class="text">"<?= htmlspecialchars($r['message'] ?? ($r['review_text'] ?? '')) ?>"</p>
                    <div class="author">
                        <div style="width:48px;height:48px;border-radius:50%;background:<?= $grads[$k % count($grads)] ?>;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:.9rem;flex-shrink:0;box-shadow:0 4px 12px rgba(108,59,255,0.2);">
                            <?= strtoupper(substr(trim($reviewer_name), 0, 2)) ?>
                        </div>
                        <div class="author-info">
                            <h4><?= htmlspecialchars($reviewer_name) ?></h4>
                            <?php if (!empty($role_text)): ?>
                                <div style="font-size: 0.8rem; color: var(--text2); font-weight: 500; margin-top: -2px;"><?= htmlspecialchars($role_text) ?></div>
                            <?php endif; ?>
                            <div class="review-verified-badge"><i class="fas fa-check-circle"></i> Verified Client &bull; <?= !empty($r['created_at']) ? date('M Y', strtotime($r['created_at'])) : 'Recent' ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div id="noReviewsPlaceholder" style="grid-column: 1/-1; text-align: center; padding: 70px 20px; background: #FFFFFF; border-radius: var(--r, 16px); border: 1px dashed var(--border-light, #e2e8f0);">
                    <div style="width: 70px; height: 70px; border-radius: 50%; background: rgba(108, 59, 255, 0.08); color: var(--primary, #6C3BFF); display: inline-flex; align-items: center; justify-content: center; font-size: 1.8rem; margin-bottom: 20px;">
                        <i class="fas fa-star"></i>
                    </div>
                    <h3 style="font-size: 1.4rem; margin-bottom: 8px;">No Reviews Listed Yet</h3>
                    <p style="color: var(--text2); max-width: 460px; margin: 0 auto 24px;">Be the first to share your experience with <?= htmlspecialchars($site_name) ?>!</p>
                    <a href="#write-review" class="btn btn-primary">Leave First Review</a>
                </div>
            <?php endif; ?>
        </div>

        <!-- ══════════════ USER-SIDE REVIEW BOX ══════════════ -->
        <div class="write-review-section" id="write-review">
            <div class="review-box-card">
                <div class="review-box-header">
                    <span class="badge-pill"><i class="fas fa-heart"></i> Share Your Experience</span>
                    <h2>Rate &amp; Review Our Services</h2>
                    <p>We appreciate your feedback! Share your genuine experience to help us improve and support other businesses in Pondicherry.</p>
                </div>

                <?php if ($msg_status): ?>
                    <div class="review-alert review-alert-<?= $msg_status ?> <?= $msg_status === 'success' ? 'alert-success' : 'alert-error' ?>" id="serverAlert">
                        <i class="fas fa-<?= $msg_status === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <div><?= $msg_text ?></div>
                    </div>
                <?php endif; ?>

                <div id="ajaxAlertContainer"></div>

                <div id="reviewFormWrapper">
                    <form action="<?= $base_url ?>/reviews#write-review" method="POST" id="userReviewForm">
                        <input type="hidden" name="action" value="submit_review">
                        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                        
                        <div class="review-form-grid">
                            <!-- Star Rating Picker -->
                            <div class="custom-input-group review-form-full">
                                <label>Your Overall Rating <span class="req">*</span></label>
                                <div class="star-picker-container">
                                    <div class="interactive-star-group">
                                        <input type="radio" name="star_rating" id="userStar5" value="5" checked>
                                        <label for="userStar5" title="5 Stars - Excellent">★</label>
                                        
                                        <input type="radio" name="star_rating" id="userStar4" value="4">
                                        <label for="userStar4" title="4 Stars - Very Good">★</label>
                                        
                                        <input type="radio" name="star_rating" id="userStar3" value="3">
                                        <label for="userStar3" title="3 Stars - Good">★</label>
                                        
                                        <input type="radio" name="star_rating" id="userStar2" value="2">
                                        <label for="userStar2" title="2 Stars - Fair">★</label>
                                        
                                        <input type="radio" name="star_rating" id="userStar1" value="1">
                                        <label for="userStar1" title="1 Star - Poor">★</label>
                                    </div>
                                    <span class="star-rating-label" id="ratingSummaryLabel">★ 5 Stars - Excellent!</span>
                                </div>
                            </div>

                            <!-- Name -->
                            <div class="custom-input-group">
                                <label for="reviewerName">Your Full Name <span class="req">*</span></label>
                                <div class="custom-input-wrap">
                                    <i class="fas fa-user input-icon"></i>
                                    <input type="text" name="name" id="reviewerName" class="custom-form-control" placeholder="e.g. Rahul Sharma" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                                </div>
                            </div>

                            <!-- Email (Required for Thank-You Email) -->
                            <div class="custom-input-group">
                                <label for="reviewerEmail">Email Address <span class="req">*</span></label>
                                <div class="custom-input-wrap">
                                    <i class="fas fa-envelope input-icon"></i>
                                    <input type="email" name="email" id="reviewerEmail" class="custom-form-control" placeholder="e.g. rahul@example.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                                </div>
                                <div class="helper-text"><i class="fas fa-shield-alt"></i> We'll send a confirmation note. Your email is never shared or displayed publicly.</div>
                            </div>

                            <!-- Company / Business (Optional) -->
                            <div class="custom-input-group review-form-full">
                                <label for="reviewerCompany">Business / Brand Name <span style="color:#94a3b8; font-weight: normal;">(Optional)</span></label>
                                <div class="custom-input-wrap">
                                    <i class="fas fa-building input-icon"></i>
                                    <input type="text" name="company" id="reviewerCompany" class="custom-form-control" placeholder="e.g. Cafe Heritage Pondy" value="<?= htmlspecialchars($_POST['company'] ?? '') ?>">
                                </div>
                            </div>

                            <!-- Review Message -->
                            <div class="custom-input-group review-form-full">
                                <label for="reviewerMessage">Your Review &amp; Experience <span class="req">*</span></label>
                                <div class="custom-input-wrap textarea-wrap">
                                    <i class="fas fa-comment-dots input-icon"></i>
                                    <textarea name="message" id="reviewerMessage" class="custom-form-control" rows="4" placeholder="Tell us about the results achieved, project quality, team collaboration, or overall satisfaction..." required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
                                </div>
                            </div>

                            <!-- Submit Button -->
                            <div class="custom-input-group review-form-full" style="margin-top: 8px;">
                                <button type="submit" class="review-submit-btn" id="submitReviewBtn">
                                    <i class="fas fa-paper-plane"></i> <span>Submit Review &amp; Receive Confirmation</span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Rating text updater
    const starLabels = {
        '5': '★ 5 Stars - Excellent!',
        '4': '★ 4 Stars - Very Good',
        '3': '★ 3 Stars - Good',
        '2': '★ 2 Stars - Fair',
        '1': '★ 1 Star - Poor'
    };

    const ratingSummaryLabel = document.getElementById('ratingSummaryLabel');
    const starRadios = document.querySelectorAll('input[name="star_rating"]');
    
    starRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.checked && starLabels[this.value]) {
                ratingSummaryLabel.textContent = starLabels[this.value];
            }
        });
    });

    // AJAX Form Handling for smooth user experience
    const form = document.getElementById('userReviewForm');
    const submitBtn = document.getElementById('submitReviewBtn');
    const alertContainer = document.getElementById('ajaxAlertContainer');
    const formWrapper = document.getElementById('reviewFormWrapper');
    const reviewsGrid = document.getElementById('reviewsGrid');
    const noReviewsPlaceholder = document.getElementById('noReviewsPlaceholder');

    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('reviewerName').value.trim();
            const email = document.getElementById('reviewerEmail').value.trim();
            const message = document.getElementById('reviewerMessage').value.trim();
            const selectedStar = document.querySelector('input[name="star_rating"]:checked');
            const starValue = selectedStar ? parseInt(selectedStar.value, 10) : 5;

            if (!name || !email || !message) {
                showAlert('Please fill in all required fields.', 'error');
                return;
            }

            // Disable button & show spinner
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> <span>Sending your review...</span>';
            alertContainer.innerHTML = '';

            const formData = new FormData(form);
            formData.append('ajax', '1');

            fetch('<?= $base_url ?>/reviews', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> <span>Submit Review &amp; Receive Confirmation</span>';

                if (data.success) {
                    // Show celebration success card
                    formWrapper.innerHTML = `
                        <div class="success-celebration">
                            <div class="success-icon-wrap">
                                <i class="fas fa-check"></i>
                            </div>
                            <h3 style="color: #166534; font-size: 1.4rem; font-weight: 800; margin-bottom: 8px;">Review Submitted Successfully!</h3>
                            <p style="color: #334155; max-width: 520px; margin: 0 auto 16px; font-size: 0.95rem; line-height: 1.6;">
                                ${escapeHtml(data.message)}
                            </p>
                            <p style="color: #64748b; font-size: 0.85rem; margin-bottom: 20px;">
                                A thank-you message and receipt have been dispatched to <strong>${escapeHtml(email)}</strong>.
                            </p>
                            <button type="button" class="btn btn-ghost" onclick="location.reload()" style="font-size: 0.9rem;">
                                <i class="fas fa-sync-alt"></i> Refresh Page
                            </button>
                        </div>
                    `;

                    // Prepend new review card to reviewsGrid
                    if (data.review) {
                        if (noReviewsPlaceholder) {
                            noReviewsPlaceholder.remove();
                        }
                        const r = data.review;
                        const starStr = '★'.repeat(r.star_rating) + '☆'.repeat(Math.max(0, 5 - r.star_rating));
                        const initials = (r.name.trim().substring(0, 2) || 'CL').toUpperCase();
                        const roleSubtitle = (r.designation || r.company) 
                            ? `<div style="font-size: 0.8rem; color: var(--text2); font-weight: 500; margin-top: -2px;">${escapeHtml([r.designation, r.company].filter(Boolean).join(' • '))}</div>` 
                            : '';

                        const newCard = document.createElement('div');
                        newCard.className = 'review-card fade-in';
                        newCard.style.border = '2px solid rgba(16, 185, 129, 0.4)';
                        newCard.innerHTML = `
                            <i class="fas fa-quote-right quote-badge"></i>
                            <div class="stars">${starStr}</div>
                            <p class="text">"${escapeHtml(r.message)}"</p>
                            <div class="author">
                                <div style="width:48px;height:48px;border-radius:50%;background:#10B981;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:.9rem;flex-shrink:0;box-shadow:0 4px 12px rgba(16,185,129,0.2);">
                                    ${initials}
                                </div>
                                <div class="author-info">
                                    <h4>${escapeHtml(r.name)} <span style="font-size: 0.72rem; background: #dcfce7; color: #166534; padding: 2px 6px; border-radius: 4px; margin-left: 6px; vertical-align: middle;">Just Now</span></h4>
                                    ${roleSubtitle}
                                    <div class="review-verified-badge"><i class="fas fa-check-circle"></i> Verified Client &bull; ${r.date || 'Recent'}</div>
                                </div>
                            </div>
                        `;
                        reviewsGrid.prepend(newCard);
                        newCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                } else {
                    showAlert(data.message || 'Unable to post review. Please try again.', 'error');
                }
            })
            .catch(err => {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> <span>Submit Review &amp; Receive Confirmation</span>';
                showAlert('Network error. Please try submitting again.', 'error');
            });
        });
    }

    function showAlert(text, type) {
        alertContainer.innerHTML = `
            <div class="review-alert review-alert-${type} alert-${type}">
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                <div>${escapeHtml(text)}</div>
            </div>
        `;
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }
});
</script>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>
