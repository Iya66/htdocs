<?php 
$why_items = $why_items ?? [];
$faqs = $faqs ?? [];
$site_name = $site_name ?? 'Cloud Aspire';
$stat_projects = $stat_projects ?? 150;
$stat_clients = $stat_clients ?? 120;
$stat_services = $stat_services ?? 6;
$stat_satisfaction = $stat_satisfaction ?? '98%';
?>
<?php include __DIR__ . '/../../../includes/header.php'; ?>

<style>
    .advantage-card {
        background: #FFFFFF;
        border: 1px solid var(--border-light);
        border-radius: var(--r);
        padding: 38px 28px;
        text-align: center;
        transition: var(--transition);
        box-shadow: var(--shadow-sm);
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .advantage-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 16px 45px rgba(108, 59, 255, 0.12);
        border-color: rgba(108, 59, 255, 0.25);
    }

    .advantage-icon {
        width: 64px;
        height: 64px;
        border-radius: var(--r-md);
        background: rgba(108, 59, 255, 0.08);
        color: var(--primary);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.6rem;
        margin-bottom: 22px;
        transition: var(--transition);
    }

    .advantage-card:hover .advantage-icon {
        background: var(--grad);
        color: #FFFFFF;
        transform: scale(1.08);
    }

    .advantage-card h3 {
        font-size: 1.25rem;
        font-weight: 700;
        margin-bottom: 12px;
        color: var(--text-main);
    }

    .advantage-card p {
        color: var(--text2);
        font-size: 0.94rem;
        line-height: 1.7;
    }
</style>

<section class="page-header">
    <div class="container">
        <h1>Why Choose <span class="highlight"><?= htmlspecialchars($site_name) ?></span></h1>
        <p>Strategic insight, creative power, and measurable results that set us apart</p>
        <div class="breadcrumb"><a href="<?= $base_url ?>/">Home</a> / Why Choose Us</div>
    </div>
</section>

<!-- Why Choose Us Cards Grid -->
<?php if (!empty($why_items)): ?>
<section class="section">
    <div class="container">
        <div class="section-header fade-in">
            <h2>Why Choose <span class="highlight"><?= htmlspecialchars($site_name) ?></span></h2>
            <p>Our core strengths, proven methodologies, and competitive advantages</p>
        </div>

        <div class="services-grid" style="margin-bottom: 40px;">
            <?php
            foreach($why_items as $a):
                $rawIcon = trim($a['icon'] ?? 'fa-star');
                if (str_starts_with($rawIcon, 'fas ') || str_starts_with($rawIcon, 'far ') || str_starts_with($rawIcon, 'fab ')) {
                    $iconClass = $rawIcon;
                } elseif (str_starts_with($rawIcon, 'fa-')) {
                    $iconClass = 'fas ' . $rawIcon;
                } else {
                    $iconClass = 'fas fa-' . $rawIcon;
                }
            ?>
                <div class="advantage-card fade-in">
                    <div class="advantage-icon"><i class="<?= htmlspecialchars($iconClass); ?>"></i></div>
                    <h3><?= htmlspecialchars($a['question']); ?></h3>
                    <p><?= htmlspecialchars($a['answer']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- FAQ Accordion -->
<section class="section" style="background: #F8FAFC; border-top: 1px solid var(--border-light); border-bottom: 1px solid var(--border-light);">
    <div class="container">
        <div class="section-header fade-in">
            <h2>Frequently Asked <span class="highlight">Questions</span></h2>
            <p>Everything you need to know about our partnership process and deliverables</p>
        </div>

        <div class="faq-list">
            <?php if (!empty($faqs)): ?>
                <?php foreach($faqs as $k => $f): ?>
                    <div class="faq-item <?= $k === 0 ? 'active' : '' ?> fade-in">
                        <div class="faq-q" role="button" tabindex="0" aria-expanded="<?= $k === 0 ? 'true' : 'false' ?>">
                            <span><?= htmlspecialchars($f['question']) ?></span>
                            <span class="arrow"><i class="fas fa-chevron-down"></i></span>
                        </div>
                        <div class="faq-a"><p><?= nl2br(htmlspecialchars($f['answer'])) ?></p></div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 40px 20px; color: var(--text2);">
                    <p>Have questions? <a href="<?= $base_url ?>/contact" style="color: var(--primary); font-weight: 600;">Contact our team</a> anytime for custom assistance.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Performance Metrics -->
<section class="section">
    <div class="container">
        <div class="section-header fade-in">
            <h2>Performance <span class="highlight">Metrics</span></h2>
            <p>Milestones that showcase our commitment to excellence</p>
        </div>

        <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 24px;">
            <div class="stat-card fade-in">
                <h3 data-count="<?= $stat_projects ?>+">0</h3>
                <p>Projects Delivered</p>
            </div>
            <div class="stat-card fade-in">
                <h3 data-count="<?= $stat_clients ?>+">0</h3>
                <p>Active Brand Partners</p>
            </div>
            <div class="stat-card fade-in">
                <h3 data-count="<?= $stat_services ?>+">0</h3>
                <p>Specialized Services</p>
            </div>
            <div class="stat-card fade-in">
                <h3 data-count="<?= $stat_satisfaction ?>">0</h3>
                <p>Client Retention</p>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>
