<?php
require_once __DIR__ . '/../../../../admin/includes/header.php';
?>

<style>
    .appearance-grid {
        display: grid;
        grid-template-columns: 1.2fr 0.8fr;
        gap: 32px;
    }

    @media (max-width: 992px) {
        .appearance-grid {
            grid-template-columns: 1fr;
        }
    }

    .settings-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius);
        padding: 32px;
        box-shadow: var(--shadow-sm);
        margin-bottom: 24px;
    }

    .settings-card h3 {
        font-size: 18px;
        color: var(--text-main);
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .settings-card h3 i {
        color: var(--primary);
    }

    .form-group {
        margin-bottom: 24px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        color: var(--text-main);
        font-weight: 600;
        font-size: 14px;
    }

    .form-group label span {
        font-weight: 400;
        color: var(--text-muted);
        font-size: 12px;
        margin-left: 8px;
    }

    .color-picker-wrapper {
        display: flex;
        gap: 16px;
        align-items: center;
    }

    .color-picker-wrapper input[type="color"] {
        width: 64px;
        height: 48px;
        border: 1px solid var(--border-color);
        border-radius: var(--btn-radius);
        cursor: pointer;
        background: var(--bg-main);
        padding: 4px;
    }

    .color-picker-wrapper input[type="text"] {
        flex: 1;
        padding: 14px 18px;
        border: 1px solid var(--border-color);
        border-radius: var(--btn-radius);
        background: var(--bg-main);
        color: var(--text-main);
        font-family: monospace;
        font-size: 14px;
        transition: all var(--transition);
    }

    .color-picker-wrapper input[type="text"]:focus {
        outline: none;
        border-color: var(--primary);
    }

    .form-control {
        width: 100%;
        padding: 14px 18px;
        border: 1px solid var(--border-color);
        border-radius: var(--btn-radius);
        font-size: 14px;
        background: var(--bg-main);
        color: var(--text-main);
        transition: all var(--transition);
    }

    .form-control:focus {
        outline: none;
        border-color: var(--primary);
    }

    .theme-preview-box {
        background: #0f0f1a;
        border-radius: 16px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        overflow: hidden;
        height: 100%;
        min-height: 400px;
        display: flex;
        flex-direction: column;
    }

    .preview-header {
        background: #16162a;
        padding: 12px 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .preview-dots {
        display: flex;
        gap: 6px;
    }

    .preview-dots span {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #ef4444;
    }

    .preview-dots span:nth-child(2) {
        background: #f59e0b;
    }

    .preview-dots span:nth-child(3) {
        background: #10b981;
    }

    .preview-title {
        font-size: 11px;
        color: #8893a8;
        font-family: monospace;
    }

    .preview-body {
        display: flex;
        flex: 1;
    }

    .preview-sidebar {
        width: 120px;
        padding: 15px 10px;
        border-right: 1px solid rgba(255, 255, 255, 0.05);
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .preview-logo {
        font-size: 11px;
        font-weight: bold;
        color: #fff;
        margin-bottom: 10px;
        padding: 0 5px;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .preview-menu-item {
        font-size: 10px;
        padding: 8px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .preview-menu-item.active {
        box-shadow: 0 4px 10px rgba(102, 126, 234, 0.2);
    }

    .preview-content {
        flex: 1;
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .preview-card {
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 12px;
        padding: 15px;
    }

    .preview-button {
        padding: 8px 16px;
        border-radius: 8px;
        font-size: 11px;
        font-weight: 600;
        color: #fff;
        border: none;
        cursor: pointer;
        display: inline-block;
    }

    .url-notice {
        font-size: 13px;
        color: var(--text-secondary);
        background: rgba(99, 102, 241, 0.08);
        border: 1px dashed rgba(99, 102, 241, 0.3);
        padding: 15px 20px;
        border-radius: 12px;
        margin-bottom: 20px;
    }

    .input-addon-group {
        display: flex;
        align-items: stretch;
        border: 1px solid var(--border-color);
        border-radius: var(--btn-radius);
        background: var(--bg-input);
        overflow: hidden;
        transition: border-color var(--transition), box-shadow var(--transition);
        width: 100%;
    }

    .input-addon-group:focus-within {
        border-color: var(--primary);
        box-shadow: 0 0 0 4px var(--primary-soft);
    }

    .input-addon-prefix {
        background: rgba(0, 0, 0, 0.02);
        padding: 14px 18px;
        color: var(--text-muted);
        font-size: 14px;
        font-weight: 600;
        border-right: 1px solid var(--border-color);
        display: flex;
        align-items: center;
        user-select: none;
    }

    [data-theme="dark"] .input-addon-prefix {
        background: rgba(255, 255, 255, 0.02);
    }

    .input-addon-group input.form-control {
        border: none !important;
        background: transparent !important;
        padding: 14px 18px;
        font-size: 14px;
        color: var(--text-main);
        flex: 1;
        outline: none;
        box-shadow: none !important;
        height: auto;
        border-radius: 0 !important;
    }
</style>

<div class="saas-header">
    <h1 class="saas-header-title">
        <i class="fa-solid fa-palette" aria-hidden="true" style="color: var(--primary);"></i>
        Appearance & Customization
    </h1>
    <p class="saas-header-subtitle">Customize theme presets, primary accent colors, font typography, and background modes.</p>
</div>

<?php require_once __DIR__ . '/../../../../admin/includes/settings-nav.php'; ?>

<?php if ($url_msg): ?>
    <div class="alert alert-<?= $url_type ?>"><i class="fas fa-<?= $url_type === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i> <?= htmlspecialchars($url_msg) ?></div>
<?php endif; ?>

<?php if ($theme_msg): ?>
    <div class="alert alert-<?= $theme_type ?>"><i class="fas fa-<?= $theme_type === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i> <?= htmlspecialchars($theme_msg) ?></div>
<?php endif; ?>

<div class="appearance-grid">
    <div>
        <!-- SECTION 1: ADMIN URL CONFIG -->
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            <div class="settings-card">
                <h3><i class="fa-solid fa-link"></i> Admin Path Customization</h3>
                <p style="color: var(--text-secondary); margin-bottom: 20px; font-size: 13px;">
                    Secure your admin portal by changing its access URL path. After updating, accessing the default <code>/admin/</code> directory directly will result in a 404 Error page.
                </p>

                <div class="url-notice">
                    <strong>Current Admin URL:</strong> <a href="<?= htmlspecialchars('/' . $admin_url_path . '/dashboard') ?>" target="_blank" style="color: var(--primary);">http://localhost/<?= htmlspecialchars($admin_url_path) ?></a>
                </div>

                <div class="form-group">
                    <label>Admin Access Path <span>*</span></label>
                    <div class="input-addon-group">
                        <span class="input-addon-prefix">http://localhost/</span>
                        <input type="text" class="form-control" name="admin_url_path" value="<?= htmlspecialchars($admin_url_path) ?>" placeholder="e.g. secret-portal" required>
                    </div>
                    <small style="color: var(--text-muted); display: block; margin-top: 8px;">
                        Only lowercase letters, numbers, hyphens, and underscores are allowed. Avoid spaces or slashes.
                    </small>
                </div>

                <button type="submit" name="save_admin_url" class="btn btn-primary" onclick="return confirm('Are you sure you want to change the Admin URL? You will be immediately redirected to the new URL path.')">
                    <i class="fa-solid fa-arrows-rotate"></i> Update Admin URL
                </button>
            </div>
        </form>

        <!-- SECTION 2: THEME COLORS -->
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            <div class="settings-card">
                <h3><i class="fa-solid fa-palette"></i> Customize Theme Colors</h3>
                <p style="color: var(--text-secondary); margin-bottom: 20px; font-size: 13px;">
                    Personalize the admin dashboard layout colors. Use the real-time preview panel on the right to see your changes immediately.
                </p>

                <div class="form-group">
                    <label>Primary Theme Color</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="primaryColorInput" name="theme_primary" value="<?= htmlspecialchars($theme_primary) ?>">
                        <input type="text" id="primaryColorText" value="<?= htmlspecialchars($theme_primary) ?>" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label>Accent Highlight Color</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="accentColorInput" name="theme_accent" value="<?= htmlspecialchars($theme_accent) ?>">
                        <input type="text" id="accentColorText" value="<?= htmlspecialchars($theme_accent) ?>" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label>Sidebar Background Color</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="sidebarBgInput" name="theme_sidebar_bg" value="<?= htmlspecialchars($theme_sidebar_bg) ?>">
                        <input type="text" id="sidebarBgText" value="<?= htmlspecialchars($theme_sidebar_bg) ?>" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label>Sidebar Menu Text Color</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="sidebarTextInput" name="theme_sidebar_text" value="<?= htmlspecialchars($theme_sidebar_text) ?>">
                        <input type="text" id="sidebarTextText" value="<?= htmlspecialchars($theme_sidebar_text) ?>" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label>Dashboard Background Color <span>(Optional)</span></label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="bgPrimaryInput" name="theme_bg_primary" value="<?= htmlspecialchars($theme_bg_primary ? $theme_bg_primary : '#0f0f1a') ?>">
                        <input type="text" id="bgPrimaryText" name="theme_bg_primary_text" value="<?= htmlspecialchars($theme_bg_primary) ?>" placeholder="Leave blank for default gradient">
                    </div>
                </div>

                <div class="form-group">
                    <label>Button Shape</label>
                    <select name="theme_btn_radius" id="btnRadiusInput" style="width: 100%; padding: 12px 16px; border: 1px solid var(--border-color); border-radius: 12px; background: var(--bg-input); color: var(--text-main); font-family: inherit;">
                        <option value="0px" <?= $theme_btn_radius === '0px' ? 'selected' : '' ?>>Sharp (0px)</option>
                        <option value="6px" <?= $theme_btn_radius === '6px' ? 'selected' : '' ?>>Rounded (6px)</option>
                        <option value="10px" <?= $theme_btn_radius === '10px' ? 'selected' : '' ?>>Soft (10px)</option>
                        <option value="30px" <?= $theme_btn_radius === '30px' ? 'selected' : '' ?>>Pill (30px)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Card Shape / Border Radius</label>
                    <select name="theme_card_radius" id="cardRadiusInput" style="width: 100%; padding: 12px 16px; border: 1px solid var(--border-color); border-radius: 12px; background: var(--bg-input); color: var(--text-main); font-family: inherit;">
                        <option value="0px" <?= $theme_card_radius === '0px' ? 'selected' : '' ?>>Sharp (0px)</option>
                        <option value="8px" <?= $theme_card_radius === '8px' ? 'selected' : '' ?>>Rounded (8px)</option>
                        <option value="16px" <?= $theme_card_radius === '16px' ? 'selected' : '' ?>>Soft (16px)</option>
                        <option value="24px" <?= $theme_card_radius === '24px' ? 'selected' : '' ?>>Extra Soft (24px)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Dashboard Font Family</label>
                    <select name="theme_font" id="fontInput" style="width: 100%; padding: 12px 16px; border: 1px solid var(--border-color); border-radius: 12px; background: var(--bg-input); color: var(--text-main); font-family: inherit;">
                        <option value="system" <?= $theme_font === 'system' ? 'selected' : '' ?>>MacOS Default (San Francisco / System)</option>
                        <option value="inter" <?= $theme_font === 'inter' ? 'selected' : '' ?>>Inter (Clean & Professional)</option>
                        <option value="poppins" <?= $theme_font === 'poppins' ? 'selected' : '' ?>>Poppins (Friendly & Round)</option>
                        <option value="roboto" <?= $theme_font === 'roboto' ? 'selected' : '' ?>>Roboto (Tech & Modern)</option>
                        <option value="outfit" <?= $theme_font === 'outfit' ? 'selected' : '' ?>>Outfit (Bold & Trendy)</option>
                        <option value="fiolex" <?= $theme_font === 'fiolex' ? 'selected' : '' ?>>Fiolex Girls (Decorative & Stylish)</option>
                        <?php foreach ($custom_fonts as $font): ?>
                            <option value="<?= htmlspecialchars($font['name']) ?>" <?= $theme_font === $font['name'] ? 'selected' : '' ?>><?= htmlspecialchars($font['name']) ?> (Custom Font)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <button type="submit" name="save_theme" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Save Appearance Theme
                </button>
            </div>
        </form>

        <!-- SECTION 3: CUSTOM FONTS MANAGER -->
        <div class="settings-card" style="margin-top: 24px;">
            <h3><i class="fa-solid fa-font"></i> Custom Fonts Manager</h3>
            <p style="color: var(--text-secondary); margin-bottom: 20px; font-size: 13px;">
                Upload your own custom font files (TTF, OTF, WOFF, or WOFF2) to use them as the primary font for your dashboard. Once uploaded, you can select them from the "Dashboard Font Family" dropdown above.
            </p>

            <!-- UPLOAD FORM -->
            <form method="POST" enctype="multipart/form-data" style="margin-bottom: 30px; border-bottom: 1px solid var(--border-color); padding-bottom: 24px;">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                
                <div class="form-group">
                    <label>Font Display Name <span style="color: var(--danger);">*</span></label>
                    <input type="text" name="custom_font_name" placeholder="e.g. My Custom Font" required style="width: 100%; padding: 12px 16px; border: 1px solid var(--border-color); border-radius: 12px; background: var(--bg-input); color: var(--text-main); font-family: inherit;">
                </div>

                <div class="form-group">
                    <label>Font File (.ttf, .otf, .woff, .woff2) <span style="color: var(--danger);">*</span></label>
                    <div style="position: relative;">
                        <input type="file" name="custom_font_file" accept=".ttf,.otf,.woff,.woff2" required style="width: 100%; padding: 12px 16px; border: 1px dashed var(--border-color); border-radius: 12px; background: var(--bg-input); color: var(--text-main); font-family: inherit; cursor: pointer;">
                    </div>
                    <small style="color: var(--text-muted); display: block; margin-top: 8px;">
                        Max file size: 5MB. Make sure you have the legal right to use this font.
                    </small>
                </div>

                <button type="submit" name="upload_custom_font" class="btn btn-primary">
                    <i class="fa-solid fa-cloud-arrow-up"></i> Upload Custom Font
                </button>
            </form>

            <!-- UPLOADED FONTS LIST -->
            <h4>Uploaded Custom Fonts</h4>
            <?php if (empty($custom_fonts)): ?>
                <p style="color: var(--text-muted); font-size: 13px; margin-top: 10px; font-style: italic;">
                    No custom fonts uploaded yet.
                </p>
            <?php else: ?>
                <div style="margin-top: 12px; display: flex; flex-direction: column; gap: 10px;">
                    <?php foreach ($custom_fonts as $font): ?>
                        <div style="display: flex; align-items: center; justify-content: space-between; padding: 14px 18px; background: var(--bg-input); border: 1px solid var(--border-color); border-radius: 12px;">
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="width: 36px; height: 36px; border-radius: 8px; background: var(--primary-soft); color: var(--primary); display: flex; align-items: center; justify-content: center; font-weight: bold; font-family: '<?= addslashes($font['name']) ?>', sans-serif; font-size: 16px;">
                                    Aa
                                </div>
                                <div>
                                    <div style="font-weight: 600; color: var(--text-main); font-size: 14px; font-family: '<?= addslashes($font['name']) ?>', sans-serif;">
                                        <?= htmlspecialchars($font['name']) ?>
                                    </div>
                                    <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase; margin-top: 2px;">
                                        Format: <?= htmlspecialchars($font['format']) ?>
                                    </div>
                                </div>
                            </div>
                            <form method="POST" style="margin: 0;" onsubmit="return confirm('Are you sure you want to delete this custom font? If it is currently selected as active, the dashboard font will reset to system default.')">
                                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                <input type="hidden" name="delete_custom_font" value="1">
                                <input type="hidden" name="font_name" value="<?= htmlspecialchars($font['name']) ?>">
                                <button type="submit" style="background: transparent; border: none; color: #ef4444; cursor: pointer; padding: 6px; font-size: 14px; transition: opacity 0.2s;" onmouseenter="this.style.opacity=0.7" onmouseleave="this.style.opacity=1" title="Delete Font">
                                    <i class="fa-solid fa-trash-can"></i>
                                </button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- PREVIEW PANEL -->
    <div>
        <div style="position: sticky; top: 20px;">
            <div class="theme-preview-box">
                <div class="preview-header">
                    <div class="preview-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="preview-title">theme_preview.html</div>
                    <div></div>
                </div>
                <div class="preview-body" id="themePreviewBody">
                    <div class="preview-sidebar" id="previewSidebar">
                        <div class="preview-logo"><i class="fa-solid fa-cloud"></i> Portal</div>
                        <div class="preview-menu-item active" id="previewMenuItem"><i class="fa-solid fa-gauge"></i> Dashboard</div>
                        <div class="preview-menu-item" style="color: rgba(255,255,255,0.4);"><i class="fa-solid fa-user-group"></i> Leads</div>
                        <div class="preview-menu-item" style="color: rgba(255,255,255,0.4);"><i class="fa-solid fa-gear"></i> Settings</div>
                    </div>
                    <div class="preview-content">
                        <h4 style="font-size: 13px; color: #fff; margin-bottom: 5px;">Dashboard Preview</h4>
                        <div class="preview-card">
                            <p style="font-size: 11px; color: rgba(255,255,255,0.7); margin-bottom: 10px;">Primary Button Action</p>
                            <button class="preview-button" id="previewButton">Action Button</button>
                        </div>
                        <div class="preview-card">
                            <p style="font-size: 11px; color: rgba(255,255,255,0.7); margin-bottom: 10px;">Gradient Element</p>
                            <div id="previewGradient" style="height: 30px; border-radius: 6px;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Real-time UI Sync for Color Pickers
    const primaryInput = document.getElementById('primaryColorInput');
    const primaryText = document.getElementById('primaryColorText');
    const accentInput = document.getElementById('accentColorInput');
    const accentText = document.getElementById('accentColorText');
    const sidebarBgInput = document.getElementById('sidebarBgInput');
    const sidebarBgText = document.getElementById('sidebarBgText');
    const sidebarTextInput = document.getElementById('sidebarTextInput');
    const sidebarTextText = document.getElementById('sidebarTextText');
    const bgPrimaryInput = document.getElementById('bgPrimaryInput');
    const bgPrimaryText = document.getElementById('bgPrimaryText');
    const btnRadiusInput = document.getElementById('btnRadiusInput');

    // Preview Elements
    const previewSidebar = document.getElementById('previewSidebar');
    const previewMenuItem = document.getElementById('previewMenuItem');
    const previewButton = document.getElementById('previewButton');
    const previewGradient = document.getElementById('previewGradient');
    const themePreviewBody = document.getElementById('themePreviewBody');

    function updateLivePreview() {
        const primary = primaryInput.value;
        const accent = accentInput.value;
        const sidebarBg = sidebarBgInput.value;
        const sidebarText = sidebarTextInput.value;
        const bgPrimary = bgPrimaryText.value;
        const btnRadius = btnRadiusInput.value;
        const cardRadius = document.getElementById('cardRadiusInput').value;
        const font = document.getElementById('fontInput').value;

        // Font mapping
        let fontFamily = '-apple-system, BlinkMacSystemFont, "SF Pro Text", "Helvetica Neue", Arial, sans-serif';
        if (font === 'inter') fontFamily = '"Inter", sans-serif';
        else if (font === 'poppins') fontFamily = '"Poppins", sans-serif';
        else if (font === 'roboto') fontFamily = '"Roboto", sans-serif';
        else if (font === 'outfit') fontFamily = '"Outfit", sans-serif';
        else if (font === 'fiolex') fontFamily = '"Fiolex Girls", cursive';
        else {
            const customFonts = <?= json_encode($custom_fonts) ?>;
            const found = customFonts.find(f => f.name === font);
            if (found) {
                fontFamily = `"${found.name}", sans-serif`;
            }
        }
        themePreviewBody.style.fontFamily = fontFamily;

        // Apply styles to Preview Elements
        previewSidebar.style.backgroundColor = sidebarBg;
        previewSidebar.style.color = sidebarText;
        previewMenuItem.style.background = `linear-gradient(135deg, ${primary} 0%, ${accent} 100%)`;
        previewMenuItem.style.color = '#fff';
        previewButton.style.background = `linear-gradient(135deg, ${primary} 0%, ${accent} 100%)`;
        previewButton.style.borderRadius = btnRadius;

        // Apply card radius to preview cards
        const previewCards = document.querySelectorAll('.preview-card');
        previewCards.forEach(card => card.style.borderRadius = cardRadius);
        previewGradient.style.background = `linear-gradient(135deg, ${primary} 0%, ${accent} 100%)`;

        if (bgPrimary) {
            themePreviewBody.style.background = bgPrimary;
        } else {
            themePreviewBody.style.background = 'linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 100%)';
        }
    }

    // Event Listeners for Live Changes
    primaryInput.addEventListener('input', (e) => {
        primaryText.value = e.target.value;
        updateLivePreview();
    });
    accentInput.addEventListener('input', (e) => {
        accentText.value = e.target.value;
        updateLivePreview();
    });
    sidebarBgInput.addEventListener('input', (e) => {
        sidebarBgText.value = e.target.value;
        updateLivePreview();
    });
    sidebarTextInput.addEventListener('input', (e) => {
        sidebarTextText.value = e.target.value;
        updateLivePreview();
    });
    bgPrimaryInput.addEventListener('input', (e) => {
        bgPrimaryText.value = e.target.value;
        updateLivePreview();
    });
    bgPrimaryText.addEventListener('input', (e) => {
        bgPrimaryInput.value = e.target.value;
        updateLivePreview();
    });
    btnRadiusInput.addEventListener('change', updateLivePreview);
    document.getElementById('cardRadiusInput').addEventListener('change', updateLivePreview);
    document.getElementById('fontInput').addEventListener('change', updateLivePreview);

    // Run on load
    updateLivePreview();
</script>

<?php require_once __DIR__ . '/../../../../admin/includes/footer.php'; ?>