<?php

/**
 * Admin Appearance Settings - Custom Theme Colors and Admin URL Path
 */
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../../app/config.php';
require_once __DIR__ . '/../../app/email_helper.php';
require_once __DIR__ . '/../../app/security_notifier.php';

// Admin-only access
$stmt = $conn->prepare("SELECT role FROM admin WHERE id = ?");
$stmt->execute([$_SESSION['admin_id']]);
$cu = $stmt->fetch();
if (!$cu || $cu['role'] !== 'admin') {
    $_SESSION['error'] = 'Access denied. Admin privileges required.';
    header('Location: ../dashboard.php');
    exit;
}

$csrf_token = generateCSRFToken();

// Helper to get setting (Bug #4: guard against redefinition)
if (!function_exists('getSetting')) {
function getSetting(PDO $conn, string $key, $default = '')
{
    $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $row = $stmt->fetch();
    return $row ? $row['setting_value'] : $default;
}
}

// Function to safely update .htaccess with new admin URL
function updateHtaccessAdminUrl(string $new_path)
{
    $htaccess_path = dirname(__DIR__, 2) . '/.htaccess';

    $content = '';
    if (file_exists($htaccess_path)) {
        $content = file_get_contents($htaccess_path);
    }

    // Define the new block content
    $new_block = "# BEGIN ADMIN URL\n";
    if ($new_path !== 'admin' && !empty($new_path)) {
        // Rewrite rule for no trailing slash
        $new_block .= "RewriteRule ^" . $new_path . "$ " . $new_path . "/ [R=301,L]\n";
        // Rewrite rule for root url dashboard redirect
        $new_block .= "RewriteCond %{REQUEST_URI} ^/" . $new_path . "/$\n";
        $new_block .= "RewriteRule ^" . $new_path . "/$ /" . $new_path . "/dashboard.php [L,R=301]\n";
        // Internal rewrite to admin folder
        $new_block .= "RewriteRule ^" . $new_path . "/(.*)$ admin/$1 [L,QSA]\n";
        // Block direct access to physical admin folder
        $new_block .= "RewriteCond %{THE_REQUEST} \\s/admin/ [NC]\n";
        $new_block .= "RewriteRule ^admin/ - [R=404,L]\n";
    } else {
        // Default admin path
        $new_block .= "RewriteCond %{REQUEST_URI} ^/admin/$\n";
        $new_block .= "RewriteRule ^admin/$ /admin/dashboard.php [L,R=301]\n";
    }
    $new_block .= "# END ADMIN URL";

    // Replace existing block or append if not exists
    if (preg_match('/# BEGIN ADMIN URL.*# END ADMIN URL/s', $content)) {
        $content = preg_replace('/# BEGIN ADMIN URL.*# END ADMIN URL/s', str_replace('$', '\\$', $new_block), $content);
    } else {
        // Remove old generic redirection rules if they exist to prevent conflicts
        $content = preg_replace('/RewriteCond %{REQUEST_URI} \^\/admin\/\$\s*RewriteRule \^admin\/\$ \/admin\/dashboard\.php \[L,R=301\]/s', '', $content);

        // Append rewrite rules after RewriteEngine On
        if (preg_match('/RewriteEngine On/i', $content)) {
            $content = preg_replace('/RewriteEngine On/i', "RewriteEngine On\n\n" . str_replace('$', '\\$', $new_block), $content);
        } else {
            $content = "RewriteEngine On\nRewriteBase /\n\n" . $new_block . "\n\n" . $content;
        }
    }

    return file_put_contents($htaccess_path, $content) !== false;
}

// Handle Admin URL Save
if (isset($_POST['save_admin_url'])) {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $_SESSION['url_msg'] = 'Invalid security token. Please refresh.';
        $_SESSION['url_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    $new_url_path = strtolower(trim($_POST['admin_url_path']));

    // Validate path
    if (empty($new_url_path)) {
        $new_url_path = 'admin';
    }

    if (!preg_match('/^[a-z0-9-_]+$/', $new_url_path)) {
        $_SESSION['url_msg'] = 'Invalid URL path. Only lowercase letters, numbers, hyphens, and underscores are allowed.';
        $_SESSION['url_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    // Reserved paths
    $reserved = ['app', 'controllers', 'vendor', 'uploads', 'css', 'js', 'api', 'assets'];
    if (in_array($new_url_path, $reserved)) {
        $_SESSION['url_msg'] = 'This path is reserved by the system. Please choose another path.';
        $_SESSION['url_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    try {
        // Save to DB
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        $stmt->execute(['admin_url_path', $new_url_path]);

        // Update .htaccess
        if (updateHtaccessAdminUrl($new_url_path)) {
            logAudit($conn, 'UPDATE_ADMIN_URL', 'Updated admin URL path to: ' . $new_url_path, $_SESSION['admin_id']);

            $_SESSION['url_msg'] = 'Admin URL updated successfully!';
            $_SESSION['url_type'] = 'success';

            // Redirect user to the new path to avoid 404!
            $redirect_url = '/' . $new_url_path . '/settings/appearance.php';
            header('Location: ' . $redirect_url);
            exit;
        } else {
            throw new Exception('Failed to write rules to .htaccess file. Please check file permissions.');
        }
    } catch (Exception $e) {
        $_SESSION['url_msg'] = 'Error: ' . $e->getMessage();
        $_SESSION['url_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }
}

// Handle Theme Colors Save
if (isset($_POST['save_theme'])) {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $_SESSION['theme_msg'] = 'Invalid security token. Please refresh.';
        $_SESSION['theme_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    try {
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        $stmt->execute(['theme_primary', trim($_POST['theme_primary'])]);
        $stmt->execute(['theme_accent', trim($_POST['theme_accent'])]);
        $stmt->execute(['theme_sidebar_bg', trim($_POST['theme_sidebar_bg'])]);
        $stmt->execute(['theme_sidebar_text', trim($_POST['theme_sidebar_text'])]);
        $stmt->execute(['theme_bg_primary', trim($_POST['theme_bg_primary'])]);
        $stmt->execute(['theme_btn_radius', trim($_POST['theme_btn_radius'])]);
        $stmt->execute(['theme_card_radius', trim($_POST['theme_card_radius'])]);
        $stmt->execute(['theme_font', trim($_POST['theme_font'])]);

        logAudit($conn, 'UPDATE_THEME', 'Updated admin panel appearance theme settings', $_SESSION['admin_id']);
        $_SESSION['theme_msg'] = 'Appearance theme colors saved successfully!';
        $_SESSION['theme_type'] = 'success';
    } catch (Exception $e) {
        $_SESSION['theme_msg'] = 'Error: ' . $e->getMessage();
        $_SESSION['theme_type'] = 'error';
    }
    header('Location: appearance.php');
    exit;
}

// Handle Custom Font Upload
if (isset($_POST['upload_custom_font'])) {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $_SESSION['theme_msg'] = 'Invalid security token. Please refresh.';
        $_SESSION['theme_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    $font_name = trim($_POST['custom_font_name']);
    if (empty($font_name)) {
        $_SESSION['theme_msg'] = 'Font name is required.';
        $_SESSION['theme_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    if (!preg_match('/^[a-zA-Z0-9_ -]+$/', $font_name)) {
        $_SESSION['theme_msg'] = 'Invalid font name. Only letters, numbers, spaces, hyphens, and underscores are allowed.';
        $_SESSION['theme_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    if (!isset($_FILES['custom_font_file']) || $_FILES['custom_font_file']['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['theme_msg'] = 'Font file is required or upload failed.';
        $_SESSION['theme_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    $file = $_FILES['custom_font_file'];
    
    // Size check (max 5MB)
    if ($file['size'] > 5 * 1024 * 1024) {
        $_SESSION['theme_msg'] = 'Font file too large. Maximum size is 5MB.';
        $_SESSION['theme_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_exts = ['ttf', 'otf', 'woff', 'woff2'];
    if (!in_array($ext, $allowed_exts)) {
        $_SESSION['theme_msg'] = 'Invalid file type. Only TTF, OTF, WOFF, and WOFF2 fonts are allowed.';
        $_SESSION['theme_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    // Determine font format
    $format = 'truetype';
    if ($ext === 'otf') {
        $format = 'opentype';
    } elseif ($ext === 'woff') {
        $format = 'woff';
    } elseif ($ext === 'woff2') {
        $format = 'woff2';
    }

    // MIME type check
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowed_mimes = [
        'application/x-font-ttf', 'font/ttf', 'application/x-font-truetype',
        'application/x-font-opentype', 'font/otf', 'font/opentype',
        'font/woff', 'font/woff2', 'application/font-woff', 'application/font-woff2',
        'application/octet-stream', 'application/vnd.ms-opentype',
        'application/font-sfnt', 'font/sfnt', 'application/x-font-otf'
    ];

    if (!in_array($mime, $allowed_mimes)) {
        $_SESSION['theme_msg'] = 'Invalid mime type ' . htmlspecialchars($mime) . ' detected.';
        $_SESSION['theme_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    $upload_dir = dirname(__DIR__, 2) . '/uploads/fonts/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Generate unique sanitized filename
    $sanitized_name = preg_replace('/[^a-zA-Z0-9_-]/', '', str_replace(' ', '_', $font_name));
    $filename = $sanitized_name . '_' . time() . '.' . $ext;
    $filepath = $upload_dir . $filename;

    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        try {
            // Log in uploads table
            $stmt = $conn->prepare("INSERT INTO uploads (file_name, file_path, file_type, file_size) VALUES (?, ?, ?, ?)");
            $stmt->execute([$filename, 'uploads/fonts/' . $filename, 'custom_font', $file['size']]);

            // Add to custom fonts list in settings
            $custom_fonts_json = getSetting($conn, 'custom_fonts', '[]');
            $custom_fonts = json_decode($custom_fonts_json, true) ?: [];
            
            $updated = false;
            foreach ($custom_fonts as &$f) {
                if (strtolower($f['name']) === strtolower($font_name)) {
                    $old_filepath = dirname(__DIR__, 2) . '/' . $f['path'];
                    if (file_exists($old_filepath)) {
                        @unlink($old_filepath);
                    }
                    $f['path'] = 'uploads/fonts/' . $filename;
                    $f['format'] = $format;
                    $updated = true;
                    break;
                }
            }
            if (!$updated) {
                $custom_fonts[] = [
                    'name' => $font_name,
                    'path' => 'uploads/fonts/' . $filename,
                    'format' => $format
                ];
            }

            $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            $stmt->execute(['custom_fonts', json_encode($custom_fonts)]);

            logAudit($conn, 'UPLOAD_FONT', 'Uploaded custom font: ' . $font_name, $_SESSION['admin_id'] ?? null);

            $_SESSION['theme_msg'] = 'Custom font uploaded successfully!';
            $_SESSION['theme_type'] = 'success';
        } catch (Exception $e) {
            $_SESSION['theme_msg'] = 'Database error: ' . $e->getMessage();
            $_SESSION['theme_type'] = 'error';
        }
    } else {
        $_SESSION['theme_msg'] = 'Failed to move uploaded font file.';
        $_SESSION['theme_type'] = 'error';
    }

    header('Location: appearance.php');
    exit;
}

// Handle Custom Font Deletion
if (isset($_POST['delete_custom_font'])) {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $_SESSION['theme_msg'] = 'Invalid security token. Please refresh.';
        $_SESSION['theme_type'] = 'error';
        header('Location: appearance.php');
        exit;
    }

    $font_name = trim($_POST['font_name']);
    
    $custom_fonts_json = getSetting($conn, 'custom_fonts', '[]');
    $custom_fonts = json_decode($custom_fonts_json, true) ?: [];

    $new_custom_fonts = [];
    $file_to_delete = '';

    foreach ($custom_fonts as $f) {
        if ($f['name'] === $font_name) {
            $file_to_delete = $f['path'];
        } else {
            $new_custom_fonts[] = $f;
        }
    }

    if ($file_to_delete) {
        $filepath = dirname(__DIR__, 2) . '/' . $file_to_delete;
        if (file_exists($filepath)) {
            @unlink($filepath);
        }

        try {
            // Delete from settings
            $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            $stmt->execute(['custom_fonts', json_encode($new_custom_fonts)]);

            // Delete from uploads table
            $stmt = $conn->prepare("DELETE FROM uploads WHERE file_path = ? AND file_type = 'custom_font'");
            $stmt->execute([$file_to_delete]);

            // If deleted font was currently selected as active font, reset back to system
            $theme_font = getSetting($conn, 'theme_font', 'system');
            if ($theme_font === $font_name) {
                $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
                $stmt->execute(['theme_font', 'system']);
            }

            logAudit($conn, 'DELETE_FONT', 'Deleted custom font: ' . $font_name, $_SESSION['admin_id'] ?? null);

            $_SESSION['theme_msg'] = 'Custom font deleted successfully!';
            $_SESSION['theme_type'] = 'success';
        } catch (Exception $e) {
            $_SESSION['theme_msg'] = 'Error deleting custom font: ' . $e->getMessage();
            $_SESSION['theme_type'] = 'error';
        }
    } else {
        $_SESSION['theme_msg'] = 'Font not found.';
        $_SESSION['theme_type'] = 'error';
    }

    header('Location: appearance.php');
    exit;
}

// Fetch Current Settings
$admin_url_path = getSetting($conn, 'admin_url_path', 'admin');
$theme_primary = getSetting($conn, 'theme_primary', '#6366f1');
$theme_accent = getSetting($conn, 'theme_accent', '#8b5cf6');
$theme_sidebar_bg = getSetting($conn, 'theme_sidebar_bg', '#1e1e2e');
$theme_sidebar_text = getSetting($conn, 'theme_sidebar_text', '#b8b8d0');
$theme_bg_primary = getSetting($conn, 'theme_bg_primary', '');
$theme_btn_radius = getSetting($conn, 'theme_btn_radius', '10px');
$theme_card_radius = getSetting($conn, 'theme_card_radius', '16px');
$theme_font = getSetting($conn, 'theme_font', 'system');
$custom_fonts_json = getSetting($conn, 'custom_fonts', '[]');
$custom_fonts = json_decode($custom_fonts_json, true) ?: [];

// Session Messages
$url_msg = $_SESSION['url_msg'] ?? '';
$url_type = $_SESSION['url_type'] ?? '';
$theme_msg = $_SESSION['theme_msg'] ?? '';
$theme_type = $_SESSION['theme_type'] ?? '';

unset($_SESSION['url_msg'], $_SESSION['url_type'], $_SESSION['theme_msg'], $_SESSION['theme_type']);

require_once __DIR__ . '/../../app/Views/admin/settings/appearance.php';
