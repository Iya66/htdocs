<?php
/**
 * Modern Enterprise Footer Component
 * 4-Column Responsive Layout with Live Status & WhatsApp Float
 */

// Fallbacks for site settings
$site_name = $site_name ?? ($settings['site_name'] ?? 'Cloud Aspire');
$site_logo = $site_logo ?? ($settings['site_logo'] ?? '');
$contact_email = $contact_email ?? ($settings['contact_email'] ?? 'cloudaspire2025@gmail.com');
$contact_phone = $contact_phone ?? ($settings['contact_phone'] ?? '8098830937');
$contact_whatsapp = $contact_whatsapp ?? ($settings['contact_whatsapp'] ?? '8098830937');
$contact_hours = $contact_hours ?? ($settings['contact_hours'] ?? 'Mon - Sat: 9:00 AM - 7:00 PM');
$clean_wa = preg_replace('/[^0-9]/', '', $contact_whatsapp);
if (str_starts_with($clean_wa, '91') && strlen($clean_wa) > 10) {
    $clean_wa = substr($clean_wa, 2);
}
$base_url = $base_url ?? '';
?>

<style>
/* ═══════════════════════════════════════════════════════════════
   PREMIUM ENTERPRISE FOOTER
   ═══════════════════════════════════════════════════════════════ */
.site-footer {
    background: linear-gradient(180deg, #0f172a 0%, #080d1a 100%);
    color: #94a3b8;
    position: relative;
    overflow: hidden;
    padding-top: 80px;
    padding-bottom: 30px;
    font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
    border-top: 1px solid rgba(99, 102, 241, 0.15);
}

.site-footer::before {
    content: '';
    position: absolute;
    top: 0;
    left: 20%;
    width: 600px;
    height: 300px;
    background: radial-gradient(circle, rgba(99, 102, 241, 0.12) 0%, rgba(15, 23, 42, 0) 70%);
    pointer-events: none;
}

.footer-container {
    max-width: 1240px;
    margin: 0 auto;
    padding: 0 24px;
    position: relative;
    z-index: 2;
}

.footer-main-grid {
    display: grid;
    grid-template-columns: 1.4fr 1fr 1fr 1.2fr;
    gap: 48px;
    margin-bottom: 64px;
}

.footer-brand .footer-logo {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    font-size: 1.5rem;
    font-weight: 800;
    color: #ffffff;
    text-decoration: none;
    margin-bottom: 20px;
    letter-spacing: -0.02em;
}

.footer-brand .footer-logo span {
    background: linear-gradient(135deg, #818cf8 0%, #c084fc 100%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
}

.footer-bio {
    font-size: 0.94rem;
    line-height: 1.7;
    color: #94a3b8;
    margin-bottom: 24px;
}

.footer-status-pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 6px 14px;
    background: rgba(16, 185, 129, 0.12);
    border: 1px solid rgba(16, 185, 129, 0.25);
    border-radius: 100px;
    font-size: 0.82rem;
    font-weight: 600;
    color: #34d399;
    margin-bottom: 24px;
}

.footer-status-pill .pulse-dot {
    width: 8px;
    height: 8px;
    background: #10b981;
    border-radius: 50%;
    box-shadow: 0 0 8px #10b981;
    animation: footerPulse 2s infinite;
}

@keyframes footerPulse {
    0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
    70% { transform: scale(1); box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); }
    100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
}

.footer-heading {
    font-size: 1.05rem;
    font-weight: 700;
    color: #ffffff;
    letter-spacing: -0.01em;
    margin-bottom: 22px;
    position: relative;
    display: inline-block;
}

.footer-heading::after {
    content: '';
    position: absolute;
    bottom: -6px;
    left: 0;
    width: 24px;
    height: 2px;
    background: linear-gradient(90deg, #6366f1, #a855f7);
    border-radius: 2px;
}

.footer-links {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.footer-links a {
    color: #94a3b8;
    text-decoration: none;
    font-size: 0.92rem;
    transition: all 0.25s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.footer-links a:hover {
    color: #ffffff;
    transform: translateX(4px);
}

.footer-links a i {
    font-size: 0.75rem;
    color: #6366f1;
    transition: transform 0.25s ease;
}

.footer-links a:hover i {
    transform: translateX(2px);
    color: #a855f7;
}

.footer-contact-list {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 16px;
}

.footer-contact-item {
    display: flex;
    align-items: flex-start;
    gap: 14px;
    font-size: 0.92rem;
}

.footer-contact-icon {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    background: rgba(99, 102, 241, 0.12);
    border: 1px solid rgba(99, 102, 241, 0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #818cf8;
    flex-shrink: 0;
    font-size: 0.9rem;
    transition: all 0.3s ease;
}

.footer-contact-item:hover .footer-contact-icon {
    background: #6366f1;
    color: #ffffff;
    transform: scale(1.05);
}

.footer-contact-text strong {
    display: block;
    color: #f1f5f9;
    font-size: 0.85rem;
    margin-bottom: 2px;
}

.footer-contact-text a {
    color: #94a3b8;
    text-decoration: none;
    transition: color 0.2s ease;
}

.footer-contact-text a:hover {
    color: #ffffff;
}

.footer-bottom-bar {
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    padding-top: 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 20px;
    font-size: 0.88rem;
}

.footer-copyright {
    color: #64748b;
}

.footer-legal-nav {
    display: flex;
    gap: 24px;
    flex-wrap: wrap;
}

.footer-legal-nav a {
    color: #64748b;
    text-decoration: none;
    transition: color 0.2s ease;
}

.footer-legal-nav a:hover {
    color: #cbd5e1;
}

/* Floating WhatsApp Button */
.floating-whatsapp {
    position: fixed;
    bottom: 28px;
    right: 28px;
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #25D366, #128C7E);
    color: #ffffff !important;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    box-shadow: 0 10px 25px rgba(37, 211, 102, 0.4);
    z-index: 9999;
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    text-decoration: none;
}

.floating-whatsapp:hover {
    transform: scale(1.1) translateY(-3px);
    box-shadow: 0 15px 35px rgba(37, 211, 102, 0.55);
}

.floating-whatsapp::after {
    content: '';
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background: inherit;
    opacity: 0.6;
    animation: waPulse 2s cubic-bezier(0, 0, 0.2, 1) infinite;
    z-index: -1;
}

@keyframes waPulse {
    0% { transform: scale(1); opacity: 0.8; }
    100% { transform: scale(1.6); opacity: 0; }
}

@media (max-width: 992px) {
    .footer-main-grid {
        grid-template-columns: 1fr 1fr;
        gap: 40px;
    }
}

@media (max-width: 640px) {
    .footer-main-grid {
        grid-template-columns: 1fr;
        gap: 36px;
    }
    .footer-bottom-bar {
        flex-direction: column;
        text-align: center;
        justify-content: center;
    }
    .footer-legal-nav {
        justify-content: center;
    }
}
</style>

<footer class="site-footer">
    <div class="footer-container">
        <div class="footer-main-grid">
            
            <!-- Column 1: Brand & Status -->
            <div class="footer-brand">
                <a href="<?= $base_url ?>/" class="footer-logo">
                    <?php if (!empty($site_logo)): ?>
                        <img src="<?= $base_url ?>/<?= htmlspecialchars(ltrim($site_logo, '/')) ?>" alt="<?= htmlspecialchars($site_name) ?>" style="max-height: 48px; width: auto;">
                    <?php else: ?>
                        <span><?= htmlspecialchars(explode(' ', $site_name)[0]) ?></span> <?= htmlspecialchars(trim(substr($site_name, strpos($site_name, ' ')))) ?>
                    <?php endif; ?>
                </a>
                <p class="footer-bio">
                    Pioneering high-impact digital marketing, technical SEO, and high-performance custom web architecture to scale brands and maximize ROI.
                </p>
                <div class="footer-status-pill">
                    <span class="pulse-dot"></span>
                    <span>Accepting New Client Projects</span>
                </div>
            </div>

            <!-- Column 2: Solutions / Services -->
            <div class="footer-col">
                <h4 class="footer-heading">Services</h4>
                <ul class="footer-links">
                    <li><a href="<?= $base_url ?>/services"><i class="fas fa-chevron-right"></i> SEO Optimization</a></li>
                    <li><a href="<?= $base_url ?>/services"><i class="fas fa-chevron-right"></i> Google & Meta Ads</a></li>
                    <li><a href="<?= $base_url ?>/services"><i class="fas fa-chevron-right"></i> Social Media Growth</a></li>
                    <li><a href="<?= $base_url ?>/services"><i class="fas fa-chevron-right"></i> Custom Web & Apps</a></li>
                    <li><a href="<?= $base_url ?>/services"><i class="fas fa-chevron-right"></i> Brand Identity Design</a></li>
                    <li><a href="<?= $base_url ?>/services"><i class="fas fa-chevron-right"></i> Content Marketing</a></li>
                </ul>
            </div>

            <!-- Column 3: Company & Trust -->
            <div class="footer-col">
                <h4 class="footer-heading">Company</h4>
                <ul class="footer-links">
                    <li><a href="<?= $base_url ?>/projects"><i class="fas fa-chevron-right"></i> Case Studies & Portfolio</a></li>
                    <li><a href="<?= $base_url ?>/why-choose-us"><i class="fas fa-chevron-right"></i> Why Choose Us</a></li>
                    <li><a href="<?= $base_url ?>/testimonials"><i class="fas fa-chevron-right"></i> Client Testimonials</a></li>
                    <li><a href="<?= $base_url ?>/reviews"><i class="fas fa-chevron-right"></i> Customer Reviews</a></li>
                    <li><a href="<?= $base_url ?>/contact"><i class="fas fa-chevron-right"></i> Free Consultation</a></li>
                </ul>
            </div>

            <!-- Column 4: Contact & Office -->
            <div class="footer-col">
                <h4 class="footer-heading">Contact Us</h4>
                <ul class="footer-contact-list">
                    <li class="footer-contact-item">
                        <div class="footer-contact-icon"><i class="fas fa-phone-alt"></i></div>
                        <div class="footer-contact-text">
                            <strong>Call Directly</strong>
                            <a href="tel:<?= htmlspecialchars($contact_phone) ?>">+91 <?= htmlspecialchars($contact_phone) ?></a>
                        </div>
                    </li>
                    <li class="footer-contact-item">
                        <div class="footer-contact-icon"><i class="fab fa-whatsapp"></i></div>
                        <div class="footer-contact-text">
                            <strong>WhatsApp Chat</strong>
                            <a href="https://wa.me/91<?= $clean_wa ?>?text=Hello%20Cloud%20Aspire,%20I%20would%20like%20to%20discuss%20a%20project." target="_blank" rel="noopener">Chat with Strategist</a>
                        </div>
                    </li>
                    <li class="footer-contact-item">
                        <div class="footer-contact-icon"><i class="fas fa-envelope"></i></div>
                        <div class="footer-contact-text">
                            <strong>Official Email</strong>
                            <a href="mailto:<?= htmlspecialchars($contact_email) ?>"><?= htmlspecialchars($contact_email) ?></a>
                        </div>
                    </li>
                    <li class="footer-contact-item">
                        <div class="footer-contact-icon"><i class="fas fa-clock"></i></div>
                        <div class="footer-contact-text">
                            <strong>Working Hours</strong>
                            <span><?= htmlspecialchars($contact_hours) ?></span>
                        </div>
                    </li>
                </ul>
            </div>

        </div>

        <!-- Footer Bottom Bar -->
        <div class="footer-bottom-bar">
            <div class="footer-copyright">
                &copy; <?= date('Y') ?> <strong><?= htmlspecialchars($site_name) ?></strong>. All rights reserved.
            </div>
            <div class="footer-legal-nav">
                <a href="<?= $base_url ?>/privacy-policy">Privacy Policy</a>
                <a href="<?= $base_url ?>/terms">Terms & Conditions</a>
                <a href="<?= $base_url ?>/refund-policy">Refund Policy</a>
                <a href="<?= $base_url ?>/sitemap.xml">Sitemap</a>
            </div>
        </div>
    </div>
</footer>

<!-- Floating WhatsApp Action -->
<a href="https://wa.me/91<?= $clean_wa ?>?text=Hello%20Cloud%20Aspire,%20I%20am%20interested%20in%20scaling%20my%20business%20with%20your%20services." 
   class="floating-whatsapp" 
   target="_blank" 
   rel="noopener" 
   aria-label="Chat on WhatsApp"
   title="Chat with Us on WhatsApp">
    <i class="fab fa-whatsapp"></i>
</a>

<!-- Header Scroll & Drawer Script -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const header = document.getElementById('header');
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const sidebarClose = document.getElementById('sidebarClose');

    // Header scroll background toggle
    window.addEventListener('scroll', () => {
        if (window.scrollY > 20) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Mobile menu toggle
    if (menuToggle && sidebar && sidebarOverlay) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.add('active');
            sidebarOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        });

        const closeSidebar = () => {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
            document.body.style.overflow = '';
        };

        if (sidebarClose) sidebarClose.addEventListener('click', closeSidebar);
        sidebarOverlay.addEventListener('click', closeSidebar);
    }
});
</script>
</body>
</html>